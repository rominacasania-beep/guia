# Pendientes de aprobar

Acá las rutinas dejan lo que prepararon. Lo más nuevo va arriba.

Para resolver uno, abrí un chat y escribí: «Revisemos mis pendientes». Claude te los muestra de a uno y hace solo lo que apruebes.

---
