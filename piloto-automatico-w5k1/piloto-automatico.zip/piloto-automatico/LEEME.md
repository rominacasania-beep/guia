# Piloto automático

Hasta ahora Claude trabaja cuando vos le escribís. Con esto trabaja solo: cada mañana te espera con el parte hecho, vigila que nada se rompa y te deja las propuestas listas para aprobar.

## Qué necesitás
- El kit «De 0 a 100» instalado.
- Las llaves de Meta Ads y de tu tienda conectadas (paso 0.3 de la guía). Sin ellas las rutinas corren, pero te dicen «no pude leer».
- Estar por lo menos en el escalón 8: tiene que haber una campaña prendida para que haya algo que vigilar.

## Qué hacer
Dejá el zip en Descargas y pegale esto a Claude:

> Tengo en Descargas el zip piloto-automatico.zip. Descomprimilo, abrí INSTALAR.md y seguilo. Preguntame los horarios antes de programar nada.

## Las 6 rutinas
| Rutina | Cuándo | Qué te deja |
|---|---|---|
| Parte de la mañana | Todos los días, 9:00 | Qué gastó y qué vendió cada anuncio, y tus 3 prioridades |
| Vigía | Todos los días, 14:00 | Un aviso solo si algo está roto |
| Plan de escala | Todos los días, 17:00 | País por país: subir, mantener, bajar o apagar |
| Cierre del día | Todos los días, 21:30 | Los números del día anotados en tu tablero |
| Tanda nueva | Cada 2 días, 10:00 | Los textos y pedidos de imagen de la próxima tanda |
| Repaso semanal | Lunes, 9:30 | Qué funcionó, qué no, y el cerebro ordenado |

## Lo que tenés que saber
- **Ninguna rutina gasta, prende, apaga ni envía nada.** Leen, preparan y proponen. Aprobar sigue siendo tuyo.
- **Corren mientras la app de Claude está abierta.** Si la cerrás, la rutina corre cuando la volvés a abrir.
- **Usan parte del uso de tu plan.** Si te quedás corta, apagá «Tanda nueva» y «Plan de escala» y dejá las otras.
- Podés cambiar los horarios o apagar cualquiera diciéndole a Claude «mostrame mis rutinas».
