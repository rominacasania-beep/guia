# Instalación (la sigue Claude)

Quien te pide esto no sabe programar. Hablale simple y no programes nada sin que confirme.

## 1. Comprobar
- Buscá su carpeta `cerebro` y anotá la ruta completa. Si no existe, frená: primero se instala el kit.
- Leé `cerebro/HOT.md`. Si el escalón actual es menor a 8, avisale que todavía no hay campaña para vigilar y preguntale si quiere instalar igual.
- Fijate si tenés acceso a Meta Ads y a su tienda con una lectura simple. Decile cuál anda y cuál no.
- Comprobá que podés crear tareas programadas. Si no tenés esa herramienta, decíselo: las rutinas se pueden correr a mano pegando el texto de cada archivo de `rutinas/`.

## 2. Preguntar (un solo mensaje)
- ¿A qué hora empezás a trabajar? (para el parte de la mañana)
- ¿A qué hora terminás? (para el cierre)
- ¿Querés las 6 rutinas o empezamos por 3: parte, vigía y cierre?

## 3. Copiar
- Copiá `pendientes-de-aprobar.md` y `tablero-semanal.md` a su carpeta `cerebro`, solo si no existen.

## 4. Programar
Por cada rutina elegida, tomá el archivo de `rutinas/`, reemplazá `<RUTA_CEREBRO>` por la ruta completa real y creá una tarea programada con ese texto como instrucción, el horario acordado (hora local) y un título en español.

| Archivo | Identificador | Horario por defecto |
|---|---|---|
| `parte-de-la-manana.md` | `parte-de-la-manana` | todos los días 9:00 |
| `vigia.md` | `vigia` | todos los días 14:00 |
| `plan-de-escala.md` | `plan-de-escala` | todos los días 17:00 |
| `cierre-del-dia.md` | `cierre-del-dia` | todos los días 21:30 |
| `tanda-nueva.md` | `tanda-nueva` | cada 2 días 10:00 |
| `repaso-semanal.md` | `repaso-semanal` | lunes 9:30 |

Si ya existe una tarea con ese identificador, no la pises: mostrásela y preguntá.

## 5. Probar
Corré ahora el «Parte de la mañana» una vez y mostrale el resultado. Si dice «no pude leer», ayudala a conectar la llave que falta.

## 6. Cerrar
Mostrale la lista de rutinas con su horario y recordale tres cosas: ninguna gasta ni prende nada, corren con la app abierta, y se apagan diciéndote «mostrame mis rutinas».

## Lo que nunca hacés
- Programar una rutina que cambie presupuestos, prenda, apague, publique o envíe algo.
- Guardar las tareas en un modo que salte los permisos sin que ella lo pida de forma expresa.
