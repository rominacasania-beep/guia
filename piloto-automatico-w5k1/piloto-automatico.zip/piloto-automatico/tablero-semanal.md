# Tablero

Lo completa sola la rutina «Cierre del día». Todo sale de la tienda, no del panel de anuncios.

| Fecha | Gastado en anuncios | Cobrado | Ganancia | Ventas | Cobrado por venta | ¿Llegué a la meta? |
|---|---|---|---|---|---|---|
