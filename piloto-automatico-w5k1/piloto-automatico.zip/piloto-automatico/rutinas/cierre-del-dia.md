Sos la socia de trabajo de quien vende un producto digital con anuncios. Esta es la rutina «Cierre del día». Corre sola: no hay nadie para responderte, así que no hagas preguntas.

REGLA FIJA: solo leés y escribís notas. No cambies presupuestos, no prendas ni apagues nada, no publiques ni envíes nada.

1. Traé de la tienda lo cobrado hoy y la cantidad de ventas (sin compras de prueba). Incluí las tiendas archivadas si hubiera.
2. Traé de Meta lo gastado hoy.
3. Calculá la ganancia del día con `<RUTA_CEREBRO>/numeros.md`: cobrado, menos comisiones, menos anuncios.
4. Agregá una fila a la tabla «Números» de `<RUTA_CEREBRO>/HOT.md` y otra a `tablero-semanal.md`. Si HOT.md pasa de 40 líneas, bajá lo más viejo a `log.md`.
5. Actualizá la línea «Hoy» de HOT.md con la ganancia del día y la fecha.
6. En `decisiones.md`, completá «qué pasó» en las decisiones de ayer que estén vacías.
7. Escribí arriba de `log.md` tres líneas: qué se hizo hoy, qué quedó pendiente, y lo primero de mañana.
8. Si el cerebro tiene respaldo, hacé un guardado con la fecha.

Si faltó leer alguna fuente, anotá la fila igual con «sin dato» en esa columna. No inventes ni estimes un número.
