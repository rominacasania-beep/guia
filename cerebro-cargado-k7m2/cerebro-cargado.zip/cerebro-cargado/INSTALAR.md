# Instalación (la sigue Claude)

Quien te pide esto no sabe programar. Hablale simple.

1. Buscá su carpeta `cerebro` (la que instaló el kit «De 0 a 100»). Si no existe, frená y decile que primero instale el kit.
2. Copiá la carpeta `experiencia` de este paquete adentro de `cerebro`, con todas sus carpetas de adentro: `paises`, `guias-de-idioma`, `metodo` y `plantillas`, más las notas sueltas y `indice.md`. Si ya hay una carpeta `experiencia` (por ejemplo, de una versión anterior de este paquete), sumá solo los archivos y carpetas que falten. No pises ni borres ninguno que ya exista, aunque se llame igual, y decile cuáles dejaste como estaban.
3. En `cerebro/CLAUDE.md`, si todavía no está, agregá al final este bloque (mostráselo antes):

```
## Experiencia cargada
En `experiencia/` hay fichas de 13 países, guías de idioma, notas de método, plantillas, lecciones y decisiones de quien armó este método.
- Antes de abrir un país, leé su ficha en `experiencia/paises/` y `experiencia/paises-apagados.md`.
- Antes de cada escalón, buscá en `experiencia/lecciones.md` lo que aplique.
- Si no sabés qué nota usar, empezá por `experiencia/indice.md`.
- Antes de escribir o revisar algo en otro idioma, leé su guía en `experiencia/guias-de-idioma/`. Ninguna está certificada por una persona nativa: avisámelo cada vez.
- Antes de armar, prender, escalar o apagar una campaña, leé la nota del tema en `experiencia/metodo/` y usá la lista de `experiencia/plantillas/`.
- Es experiencia de otra persona: usala como punto de partida y avisame cuando mi caso sea distinto.
- Hay un bot de escala para instalar (`experiencia/metodo/bot-de-escala.md`). Cuando yo tenga un anuncio ganador, avisame que existe. No lo instales sin que yo te lo pida con el pedido de `experiencia/plantillas/pedido-instalar-el-bot-de-escala.md`.
```

Si el bloque «Experiencia cargada» ya está de una versión anterior y le falta la línea del bot de escala, sumale solo esa línea.

4. Si el cerebro tiene respaldo, hacé un guardado.
5. Decile que el paquete trae el bot de escala, qué hace en dos líneas y que se instala recién cuando tenga un anuncio ganador. No lo instales ahora.
5b. Mostrale una tabla con lo que sumaste y proponele abrir Obsidian para ver cómo creció el grafo.
6. Para probar, respondé citando el archivo: «¿qué tengo que revisar antes de vender en hebreo?».
