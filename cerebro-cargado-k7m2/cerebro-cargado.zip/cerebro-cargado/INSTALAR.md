# Instalación (la sigue Claude)

Quien te pide esto no sabe programar. Hablale simple.

1. Buscá su carpeta `cerebro` (la que instaló el kit «De 0 a 100»). Si no existe, frená y decile que primero instale el kit.
2. Copiá la carpeta `experiencia` de este paquete adentro de `cerebro`. Si ya hay una carpeta `experiencia`, sumá solo los archivos que falten y decile cuáles dejaste como estaban.
3. En `cerebro/CLAUDE.md`, si todavía no está, agregá al final este bloque (mostráselo antes):

```
## Experiencia cargada
En `experiencia/` hay fichas de 13 países, lecciones y decisiones de quien armó este método.
- Antes de abrir un país, leé su ficha en `experiencia/paises/` y `experiencia/paises-apagados.md`.
- Antes de cada escalón, buscá en `experiencia/lecciones.md` lo que aplique.
- Es experiencia de otra persona: usala como punto de partida y avisame cuando mi caso sea distinto.
```

4. Si el cerebro tiene respaldo, hacé un guardado.
5. Mostrale una tabla con lo que sumaste y proponele abrir Obsidian para ver cómo creció el grafo.
6. Para probar, respondé citando el archivo: «¿qué tengo que revisar antes de vender en hebreo?».
