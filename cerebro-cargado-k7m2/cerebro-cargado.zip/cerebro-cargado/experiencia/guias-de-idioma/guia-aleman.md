# Guía de estilo · alemán (Alemania, Austria y Suiza)

> Aviso: es una guía de trabajo. Salió de leer revistas y sitios de salud alemanes y de revisiones con IA. No la certificó una persona nativa. Casi no pude leer reseñas de compradoras.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[alemania-y-suiza]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | «du», en minúscula dentro de la frase. Las empresas serias usan «Sie»: no las imites en eso |
| Tono | Sobrio. Punto final, cero urgencia. Sin «Jetzt zugreifen!» ni «Nur heute!» |
| Verbos | De todos los días: aufschreiben, sortieren, loslassen, durchatmen |
| Largo | El alemán se alarga. Elegí la palabra corta. Rótulos: de una a tres palabras |
| Un freno propio | Para muchas, el diario guiado «suena a autoexigencia». Nada de «la mejor versión de vos» |

## Formatos y ortografía
| Tema | Cómo va |
|---|---|
| Comillas | „así“ |
| Raya | Raya corta con espacios: « – ». Nunca la raya larga pegada del español |
| Fecha | Día con punto, mes en letras, año. Días y meses llevan mayúscula |
| Mayúsculas | Los sustantivos llevan mayúscula siempre: es regla del idioma, no un estilo |
| Suiza | Allá no se usa la ß. Si escribís todo sin ß, el mismo texto sirve para los tres países |
| Moneda | Un precio en euros y otro en francos suizos |
| Lo que les da miedo | La suscripción escondida. Decí clarito: «Einmal zahlen, kein Abo» |

## Cómo lo dice ella (rubro bienestar)
| Alemán | Qué quiere decir |
|---|---|
| Gedankenkarussell | la calesita de pensamientos. Es la palabra reina |
| grübeln | darle vueltas a algo. Cotidiano y neutro |
| den Kopf voll haben | tener la cabeza llena |
| Kopfchaos · Chaos im Kopf | lío en la cabeza |
| nicht abschalten können | no poder desconectar |
| zur Ruhe kommen | aquietarse |
| Mental Load | carga mental. Se usa en inglés, tal cual |
| sich etwas von der Seele schreiben | sacarse algo de adentro escribiendo |
| den Kopf freibekommen | despejar la cabeza |
| Gedanken sortieren | ordenar los pensamientos. El beneficio más repetido |
| einfach losschreiben | arrancar a escribir sin más |
| dranbleiben | sostenerlo en el tiempo |
| Kopfkino | película mental. No es «cabeza llena»: usala poco y solo con ese sentido |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| weißes Blatt | leeres Blatt · leere Seite | Calco de «hoja en blanco» |
| mentaler Lärm | Gedankenkarussell · Kopfchaos | Calco de «ruido mental» |
| Leere deinen Geist | den Kopf freibekommen · raus aus dem Kopf | «Geist» suena a esoterismo o a fantasma |
| Benenne deine Emotionen | in Worte fassen, was in dir los ist | Suena a manual clínico |
| wissen, wie man schreibt | schreiben können | Calco de «saber escribir» |
| einmalige Bezahlung | Einmalzahlung · einmal zahlen, kein Abo | Fórmula del comercio alemán |
| Garantie von X Tagen | X Tage Geld-zurück-Garantie | Fórmula fija |
| wir geben dir das Geld zurück | du bekommst dein Geld zurück | Fórmula fija |
| zum Drucken | zum Ausdrucken | Lo que una hace en casa es «ausdrucken» |
| Tagebuch (para nombrar el producto) | Journal · geführtes Journal | «Tagebuch» es contar el día. Como verbo sí va: «Tagebuch schreiben» |
| Aufgabe | Übung · Impuls | «Aufgabe» suena a tarea escolar |
| Mindset · Heilungsreise · Overthinking | grübeln · Gedanken, o nada | Registro de otra edad |
| heilt · Heilung · Therapie für zu Hause | hilft · unterstützt · tut gut | Promesa de cura |
| Leidest du unter…? · Du hast Angst | «Abends im Bett springt das Gedankenkarussell an.» | Diagnostica |

## Glosario del rubro (cuaderno imprimible)
| Español | Alemán |
|---|---|
| diario guiado | geführtes Journal |
| cuaderno de trabajo | Arbeitsbuch |
| escritura terapéutica | therapeutisches Schreiben (como nombre del método, nunca como promesa) |
| escritura creativa | kreatives Schreiben |
| consigna | Impuls · Frage · Übung |
| hoja en blanco | leeres Blatt |
| calma | Ruhe |
| creencia · creencia limitante | Glaubenssatz · limitierender Glaubenssatz |
| gratitud · diario de gratitud | Dankbarkeit · Dankbarkeitstagebuch |
| afirmación | Affirmation |
| emoción | Gefühl |
| límites | Grenzen |
| autoconocimiento | Selbsterkenntnis |
| autocuidado | Selbstfürsorge |
| tarjetas | Karten (sacar una: «eine Karte ziehen») |
| para colorear | zum Ausmalen |
| respiración · cuerpo | Atmung · Körper |
| PDF para imprimir | PDF zum Ausdrucken |
| día · semana · páginas | Tag · Woche · Seiten |

## Trampas que me pasaron
- Reusé una tienda de otro idioma y quedaron restos por todos lados. Ver [[lista-al-reusar-una-tienda]].
- Si el original estaba en mayúsculas sostenidas, no las copies: en alemán cansan más.

## Lista de control antes de publicar
- [ ] ¿«du» en todo, sin «Sie» de cortesía?
- [ ] ¿Sin exclamaciones ni urgencia?
- [ ] ¿«leeres Blatt», «zum Ausdrucken», «kein Abo»?
- [ ] ¿La garantía con su fórmula fija?
- [ ] ¿Comillas „ “ y raya corta con espacios?
- [ ] ¿Texto sin ß si también va a Suiza?
- [ ] ¿«hilft» y «tut gut», nunca «heilt»?
- [ ] ¿Ningún texto se sale de su caja por el largo?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
