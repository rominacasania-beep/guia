# Guía de estilo · húngaro (Hungría)

> Aviso: es una guía de trabajo. Salió de leer revistas, foros y fichas de librería húngaras y de revisiones con IA. No la certificó una persona nativa.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[hungria]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | Tuteo siempre. Nunca «Ön», «Önnek» ni «Kérjük». Los medios serios tratan de usted; las revistas que lee este público, no |
| Órdenes | Cortas y suaves: «Írd le…», «Nyisd ki…», «Gondolj arra…» |
| Tono | Frase corta con punto. Sin «Ne maradj le!» ni superlativos de coaching |
| Mayúsculas | Solo la primera palabra del título |
| Largo | El húngaro arma palabras largas. Apuntá al mismo largo que el español o menos. Rótulos: de una a tres palabras |

## Formatos y ortografía
| Tema | Cómo va |
|---|---|
| Comillas | „así” (abre abajo, cierra arriba) |
| Signos | No existen ¡ ni ¿. Una sola exclamación por bloque, si hace falta |
| Letras | ő y ű llevan doble acento largo. Nunca õ, û ni ô |
| Fecha | Año primero con punto, mes en letras y en minúscula, día con punto |
| Hora | Reloj de veinticuatro horas |
| Rangos | Raya corta sin espacios, y punto después del número cuando es un ordinal |
| Moneda | Moneda local sin decimales, con precio fijo para el país. La abreviatura va después del número |
| Semana | Empieza en lunes |

## Cómo lo dice ella (rubro bienestar)
| Húngaro | Qué quiere decir |
|---|---|
| pörög az agyam | la cabeza me da vueltas. La más usada |
| jár az agyam | la cabeza no me para. Más suave |
| nem tudok kikapcsolni | no puedo desconectar |
| agyalás · túlagyalás | darle vueltas, con algo de humor |
| túlgondolás | pensar de más. Es la etiqueta de revista |
| rágódás | rumiar algo |
| kavarognak a gondolatok | los pensamientos se arremolinan |
| belső lista | la lista interna de pendientes |
| kiírni magamból | sacármelo escribiendo |
| papírra vetni | ponerlo en el papel. Más cuidado |
| megkönnyebbülés · megnyugodva | alivio · tranquila. Así cuentan el resultado: alivio, no curación |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| Vedd ki a fejedből… | Írd ki magadból… | Calco de «sacá de tu cabeza» |
| journal | napló · naplóírás | No es lo que escriben las revistas |
| üres oldal | üres lap | La combinación real es otra |
| Nem kell tudnod, hogyan kell írni | Nem kell hozzá „tudni írni”. | Calco largo |
| hogy lélegezhess | fellélegezni · megkönnyebbülni | En húngaro eso es respirar de verdad, no alivio |
| Egyetlen fizetés · egyszeri kifizetés | Egyszeri fizetés | Calco, o suena contable |
| pénzvisszatérítés garantálva! | X napos pénzvisszafizetési garancia | Tono de teletienda |
| rumináció · kognitív | rágódás · agyalás | Técnico |
| mentális teher (como gancho) | belső lista · «minden az én fejemben van» | Registro de artículo |
| Túlgondolod? · Szorongsz? | Escena o primera persona: «Pörög az agyam…» | Diagnostica |
| gyógyít · megszünteti · megszabadít | segít · könnyebb · megkönnyebbülés | Promesa de cura |
| Tegyél egy mély lélegzetet | Vegyél egy mély levegőt! | Calco del inglés |
| Érezd magad szabadnak, hogy… | Nyugodtan… | Calco del inglés |
| Ez okés | Ez rendben van. · Semmi baj. | Calco del inglés |

## Glosario del rubro (cuaderno imprimible)
| Español | Húngaro |
|---|---|
| diario | napló |
| llevar un diario | naplóírás |
| diario con preguntas guiadas | kérdésekkel vezetett napló |
| diario de autoconocimiento | önismereti napló |
| cuaderno de trabajo | munkafüzet |
| escritura terapéutica | terápiás írás |
| escritura creativa | kreatív írás |
| consigna, ejercicio | feladat (siempre la misma palabra; no la mezcles con «gyakorlat») |
| hoja en blanco | üres lap |
| calma | nyugalom |
| gratitud · diario de gratitud | hála · hálanapló |
| afirmación | megerősítés |
| emoción | érzelem |
| límites | határok |
| autoconocimiento | önismeret |
| tarjetas | kártyák (sacar una: «húzz egy kártyát») |
| para colorear | színező |
| respiración · cuerpo | légzés · test |
| PDF para imprimir | Nyomtatható PDF |
| pago único | Egyszeri fizetés |
| día · semana · página | nap · hét · oldal |

## Trampas que me pasaron
- Los originales traían marcas escondidas (logo, iniciales, fotos, usuario) que nadie había visto antes.
- El control de «restos de español» marcaba una palabra que también existe en húngaro. Hay que sacarla del filtro.

## Lista de control antes de publicar
- [ ] ¿Tuteo en todo, sin «Ön»?
- [ ] ¿Ninguna frase le dice a la lectora que «tiene» algo?
- [ ] ¿Ninguna promesa de cura? Solo «segít», «könnyebb», «megnyugodva»
- [ ] ¿Las mismas palabras siempre: «napló», «feladat», «üres lap»?
- [ ] ¿Comillas „…”, sin ¡ ¿, sin mayúsculas en cada palabra?
- [ ] ¿ő y ű bien escritas?
- [ ] ¿Leído en voz alta suena a revista o a foro, y no a subtítulo traducido?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
