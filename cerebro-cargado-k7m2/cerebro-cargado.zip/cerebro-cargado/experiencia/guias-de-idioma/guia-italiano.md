# Guía de estilo · italiano (Italia)

> Aviso: es una guía de trabajo. Salió de leer revistas, blogs y reseñas italianas y de revisiones con IA. No la certificó una persona nativa.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[italia]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | «tu», en femenino («rimasta», «fermata»). Las revistas usan «voi»; la venta directa a mujeres usa «tu». Nunca «Lei» |
| Tono | Frase llana, con punto. Sin exclamaciones, sin «Scopri ora», sin «incredibile» |
| Mayúsculas | Solo la primera palabra del título |
| Persona | Ella dice «testa» cuando habla de sí misma. «Mente» es palabra de artículo |

## Formatos
| Tema | Cómo va |
|---|---|
| Moneda | Precio fijo en euros para el país, no convertido desde otra moneda |
| Plazo diario | «X minuti al giorno». Nunca «per giorno» |
| Plan con días | «Il tuo percorso di X giorni», no «Piano X giorni» |
| Fecha y semana | Dato general, confirmalo: día/mes/año y semana que empieza en lunes |
| Decimales | Dato general, confirmalo: con coma |

## Cómo lo dice ella (rubro bienestar)
| Italiano | Qué quiere decir |
|---|---|
| la testa piena di pensieri | la cabeza llena de pensamientos |
| non riuscire a staccare | no lograr desconectar |
| svuotare la testa | vaciar la cabeza |
| fare ordine · fare chiarezza | ordenar · aclarar |
| mettere nero su bianco | ponerlo por escrito |
| lasciar andare | soltar |
| rimuginare | darle vueltas a algo |
| tenere tutto in testa · devo pensare a tutto io | cargar con todo |
| tirare il fiato | darse un respiro |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| Togliti dalla testa… | Svuota la testa · metti su carta | «Togliersi dalla testa» es renunciar a una idea |
| foglio in bianco · foglio bianco | pagina bianca | Calco del español |
| mettere un nome a ciò che senti | dare un nome a quello che senti | Calco; «ciò» es libresco |
| X minuti per giorno | X minuti al giorno | Preposición calcada |
| ti restituiamo il denaro | ti rimborsiamo | Es la fórmula normal de las tiendas italianas |
| non c'è bisogno di sapere come scrivere | non serve saper scrivere | Más corto y más hablado |
| respirare (como alivio) | tirare il fiato | Así se dice «darse un respiro» |
| journal · prompt | diario · traccia · spunto | «Journaling» se entiende; «journal» no |
| sovraccarico mentale (en un titular) | testa piena · mille pensieri | Registro de artículo |
| Soffri d'ansia? · guarirai · elimina l'ansia | Una escena o la primera persona | Diagnostica y promete cura |

## Glosario del rubro (cuaderno imprimible)
| Español | Italiano |
|---|---|
| diario guiado | diario guidato |
| escritura terapéutica | scrittura terapeutica |
| llevar un diario | tenere un diario |
| hoja en blanco | pagina bianca |
| consigna | traccia · spunto |
| ejercicio | esercizio |
| tarjetas | carte (sacar una: «pesca una carta») |
| PDF para imprimir | PDF stampabile · PDF da stampare |
| pago único | Paghi una volta sola · Pagamento unico |
| garantía con devolución | Garanzia di X giorni: se senti che non fa per te, ti rimborsiamo |
| día · semana · páginas | giorno · settimana · pagine |

## Trampas que me pasaron
- Una misma pieza del producto terminó llamándose de dos formas, una en la web y otra en el PDF. Elegí la palabra antes de empezar.
- Hay palabras que parecen iguales al español y significan otra cosa.

## Lista de control antes de publicar
- [ ] ¿«tu» y femenino en todo, sin «voi» ni «Lei»?
- [ ] ¿«testa» y no «mente» cuando habla ella?
- [ ] ¿«al giorno», «pagina bianca», «ti rimborsiamo»?
- [ ] ¿Ningún signo de exclamación ni mayúsculas en cada palabra?
- [ ] ¿Ninguna frase le dice a la lectora lo que tiene, ni promete cura?
- [ ] ¿Cada pieza se llama igual en la web, el checkout y el PDF?
- [ ] ¿Precio fijo en euros, visto en el checkout real?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
