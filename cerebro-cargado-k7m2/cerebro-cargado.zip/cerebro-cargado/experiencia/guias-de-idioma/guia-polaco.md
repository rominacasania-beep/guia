# Guía de estilo · polaco (Polonia)

> Aviso: es una guía de trabajo. Salió de leer revistas, portales, reseñas y un foro polacos y de revisiones con IA. No la certificó una persona nativa.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[polonia]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | Tuteo en femenino: los verbos marcan el género («odłożyłaś», «zmęczona») |
| «ty» o «Ty» | En minúscula suena a revista moderna. En mayúscula suena a blog. Las dos valen. No se mezclan |
| Tono | Lenguaje de revista: «zmęczona», «przebodźcowana», «ogarnąć». Nada espiritual |
| Persona | Ella dice «głowa» (cabeza). «Umysł» (mente) en exceso suena raro |

## Formatos y puntuación
| Tema | Cómo va |
|---|---|
| Comillas | „así” |
| Raya | Raya corta con espacios |
| Plazo | Con «przez»: «X minut dziennie przez X dni». Sin «przez» queda telegráfico |
| Devolución | «X dni na zwrot». La palabra «gwarancja» sola suena a electrodoméstico |
| Plazo de devolución | Averiguá el plazo que la gente espera allá antes de escribir el tuyo. Uno más corto puede leerse como poco |
| Fecha, semana y moneda | Dato general, confirmalo: día, mes y año con puntos; semana que empieza en lunes; la abreviatura de la moneda va después del número |

## Cómo lo dice ella (rubro bienestar)
| Polaco | Qué quiere decir |
|---|---|
| natłok myśli | aluvión de pensamientos |
| gonitwa myśli | carrera de pensamientos |
| mam za dużo na głowie | tengo demasiado encima |
| nie daję rady wszystkiego ogarnąć | no doy abasto con todo |
| przemęczona i przebodźcowana | agotada y sobreestimulada |
| przelać na papier | volcar al papel |
| wyrzucić z głowy | sacar de la cabeza |
| uporządkować w głowie · poukładać | ordenar en la cabeza |
| nabrać dystansu | tomar distancia |
| odpuścić | soltar |
| przestrzeń tylko dla mnie | un espacio solo para mí |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| prowadzony dziennik | dziennik z ćwiczeniami · dziennik z pytaniami | Calco de «diario guiado». En polaco se entiende «un diario que alguien lleva» |
| Nigdy pustej strony | Żadnych pustych stron · Koniec z pustą kartką | Sin verbo no es polaco |
| Puść (a secas) | Odpuść | El primero pide un objeto |
| …które do ciebie mówią | …które do ciebie przemawiają | Calco de «que te hablan» |
| zrzut mózgu · bałagan umysłowy · przestrzeń mentalna | wyrzucić z głowy · bałagan w głowie · mieć za dużo na głowie | Traducción automática a la vista |
| Cadenas de sustantivos pegados | Partir la frase con «z» | Pesado, de oficina |
| X dni gwarancji | X dni na zwrot · gwarancja zwrotu pieniędzy | Suena a garantía de aparato |
| wskazane (por «indicadas») | podane | Palabra de oficina |
| Vocabulario espiritual (energia, dusza) | Lenguaje de revista | Existe, pero es de nicho y aleja a la mujer común |
| Masz lęki? · wyleczysz · pozbądź się lęku | Escena: «Leżysz, a głowa dalej pracuje.» | Diagnostica y promete cura |

## Glosario del rubro (cuaderno imprimible)
| Español | Polaco |
|---|---|
| diario | dziennik (el más neutro) |
| diario íntimo | pamiętnik (más íntimo, algo adolescente) |
| cuaderno con ejercicios | notes rozwojowy · dziennik z ćwiczeniami |
| journaling | journaling (se acepta, casi siempre explicado en polaco) |
| escritura expresiva | pisanie ekspresywne (término de psicólogos) |
| ejercicio | ćwiczenie |
| hoja en blanco | pusta strona · pusta kartka |
| cada página te sugiere qué escribir | każda strona podpowiada, co napisać |
| PDF para imprimir | PDF do wydruku |
| pago único | Płatność jednorazowa |
| día · páginas | dzień · strony |

Ojo: «pisanie terapeutyczne» no apareció tal cual en lo que leí. Sí aparecen «efekt terapeutyczny» y «autoterapia». Las mismas lectoras aclaran que un diario no reemplaza la terapia: usalo como nombre del método, nunca como promesa.

## Trampas que me pasaron
- Un anuncio que funcionaba traía un error de ortografía, y el generador de imágenes lo copió en todas las versiones nuevas.
- Mezclar formato y dispositivo en una misma lista («A4 o tablet») quedó raro. Mejor: «para imprimir (A4) o para tablet».

## Lista de control antes de publicar
- [ ] ¿Femenino en todos los verbos?
- [ ] ¿«ty» o «Ty», una sola en todo el texto?
- [ ] ¿«głowa» y no «umysł»?
- [ ] ¿Ningún «prowadzony dziennik» ni frases sin verbo?
- [ ] ¿«na zwrot» y no «gwarancji»?
- [ ] ¿Comillas „ ”?
- [ ] ¿Revisaste también el texto que «ya estaba bien»?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
