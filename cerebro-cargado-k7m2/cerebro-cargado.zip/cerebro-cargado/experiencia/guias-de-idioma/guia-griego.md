# Guía de estilo · griego (Grecia y Chipre)

> Aviso: es una guía de trabajo. Salió de leer revistas y blogs griegos y de revisiones con IA. Ninguna persona griega la revisó. No pude leer reseñas de compradoras.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[grecia-y-chipre]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | «εσύ» (tuteo singular) siempre: «Γράψε», «Σκέψου». El «εσείς» de cortesía es de formularios |
| Género | Todo en femenino: «έτοιμη», «κουρασμένη», «μόνη» |
| Dos excepciones | «ευγνώμων» es igual para los dos géneros. «εαυτός» es masculino siempre: «ο εαυτός σου» |
| Variante | Griego estándar, sin giros de Chipre |
| Sentir | «νιώθω» (cotidiano) antes que «αισθάνομαι» (formal) |
| Frases | Cortas. La orden va al principio |
| Largo | El griego ocupa más lugar que el español: dejá aire en el diseño |
| Tono | Como una amiga que sabe del tema. Sin «Ξεκίνα τώρα!!» ni «Μόνο σήμερα!» |

## Ortografía que no perdona
| Tema | Cómo va |
|---|---|
| Acento | Uno solo (´). Toda palabra de dos sílabas o más lo lleva |
| Monosílabos | Sin acento, salvo «ή» (o) y «πού / πώς» cuando preguntan |
| Diéresis | Separa dos vocales que si no se leerían juntas: «αϋπνία» |
| MAYÚSCULAS | En una palabra toda en mayúsculas se quitan los acentos, pero la diéresis queda: «ΗΜΕΡΟΛΟΓΙΟ», «ΜΑΪΟΣ» |
| Mayúscula inicial | Si la palabra empieza con vocal acentuada, el acento va arriba a la izquierda: «Έλα», «Άδειασε» |
| Sigma | «ς» solo al final de la palabra, «σ» en el resto. En mayúsculas siempre «Σ» |
| Títulos | Mayúscula solo en la primera palabra |

Ojo con los programas de diseño: al pasar un texto a mayúsculas suelen dejar los acentos. Escribí el título ya en mayúsculas y sin acentos.

## Puntuación y formatos
| Tema | Cómo va |
|---|---|
| Pregunta | Se cierra con «;». Nunca «?» ni «¿» |
| Punto alto «·» | Hace de punto y coma |
| Comillas | « » |
| Apóstrofo | Sin espacio antes y con espacio después: «Βγάλ’ τα», «σ’ αγαπώ» |
| «ό,τι» | Con coma, es «lo que sea». Sin coma («ότι») es «que» |
| Fecha | Día, mes en genitivo y año. En números: día/mes/año |
| Hora | Reloj de veinticuatro horas |
| Días y meses | Con mayúscula inicial |
| Semana | Empieza en lunes |
| Números | Decimales con coma, miles con punto |
| Moneda | El símbolo del euro va después del número, con espacio |
| Fiestas | La Pascua ortodoxa cae en otra fecha. Se festeja mucho el día del santo |
| «ημερολόγιο» | Significa diario y también calendario. Sola confunde: ponele apellido |

## Cómo lo dice ella (rubro bienestar)
| Griego | Qué quiere decir |
|---|---|
| το μυαλό μου δεν σταματά | mi cabeza no para. La forma de todos los días |
| το πολυσκέφτομαι | lo pienso de más |
| υπερανάλυση | sobreanálisis. Palabra de título de revista |
| ατελείωτη λίστα | la lista interminable |
| κουρασμένη | cansada |
| αδειάζω το μυαλό | vaciar la cabeza. La más útil |
| βάζω σε τάξη | poner en orden |
| βγάζω από το μυαλό, στο χαρτί | sacar de la cabeza, al papel |
| χαλαρώνω · ηρεμώ | aflojar · calmarme |
| ξαλαφρώνω | sentirme más liviana |
| παίρνω μια ανάσα | tomar aire |
| δεν πειράζει | no pasa nada |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| Αποσυνδέσου | άδειασε το μυαλό σου · χαλάρωσε | Calco de «desconectar»: no lo vi usado así |
| Νοητικός θόρυβος | το μυαλό σου δεν σταματά · φασαρία στο κεφάλι | Calco de «ruido mental» |
| μηρυκασμός · γνωστικό φορτίο | το πολυσκέφτομαι · τα κουβαλάω όλα | Técnico |
| prompts · υπομνήσεις | ερωτήσεις · ασκήσεις | No se usa |
| Ημερολόγιο (solo) | καθοδηγούμενο ημερολόγιο · ημερολόγιο με ασκήσεις | Solo, es calendario o diario de adolescente |
| Γράψτε · το ημερολόγιό σας | Γράψε · το ημερολόγιό σου | Las revistas femeninas tutean |
| συγκίνηση (por «emoción») | συναίσθημα | La primera es «conmoverse» |
| ισχυρές ερωτήσεις | ερωτήσεις που σε ξεκλειδώνουν | Calco de «preguntas poderosas» |
| Η καλύτερη εκδοχή σου · mindset | Nada | Registro de otra edad |
| θα αλλάξει τη ζωή σου | Un gesto concreto | Promesa grande |
| θεραπεύει · γιατρεύει | σε βοηθά · σου κάνει καλό | Promesa de cura |
| Έχεις άγχος; · Υποφέρεις από… | Escena: «Το βράδυ, μόλις ξαπλώσεις…» | Diagnostica |

## Glosario del rubro (cuaderno imprimible)
| Español | Griego |
|---|---|
| diario guiado | καθοδηγούμενο ημερολόγιο |
| cuaderno de ejercicios | τετράδιο ασκήσεων |
| escritura terapéutica | θεραπευτική γραφή (en la venta prefiero «γραφή που σε ξαλαφρώνει») |
| escritura creativa | δημιουργική γραφή |
| journaling | το journaling (en letras latinas) · γράψιμο |
| ejercicio · pregunta | άσκηση · ερώτηση |
| hoja en blanco | λευκή σελίδα |
| calma | ηρεμία · γαλήνη |
| creencia · creencia limitante | πεποίθηση · περιοριστική πεποίθηση |
| gratitud · diario de gratitud | ευγνωμοσύνη · ημερολόγιο ευγνωμοσύνης |
| afirmación | θετική επιβεβαίωση |
| emoción | συναίσθημα |
| límites | όρια |
| autoconocimiento | αυτογνωσία |
| autocuidado | αυτοφροντίδα |
| tarjetas | κάρτες |
| para colorear | για ζωγράφισμα · για χρωμάτισμα |
| respiración · cuerpo | αναπνοή · σώμα |
| agenda | ατζέντα |
| PDF para imprimir | Εκτυπώσιμο PDF |
| pago único, sin suscripción | Μία πληρωμή, χωρίς συνδρομή |
| garantía de X días | Εγγύηση X ημερών |
| día · semana · páginas | μέρα · εβδομάδα · σελίδες |

## Trampas que me pasaron
- La tipografía de los títulos no tenía letras griegas, ni la del PDF ni la de la web.
- Al pasar a mayúsculas por programa quedaban los acentos.
- Una portada generada traía una palabra con letras inventadas.
- Hubo que rearmar todos los calendarios para que la semana empezara en lunes.

## Lista de control antes de publicar
- [ ] ¿«εσύ» y femenino en todo?
- [ ] ¿Las preguntas cierran con «;»?
- [ ] ¿Mayúsculas sin acentos y con diéresis donde va?
- [ ] ¿«ς» solo al final de palabra?
- [ ] ¿La tipografía tiene todas las letras griegas, en la web y en el PDF?
- [ ] ¿La semana empieza en lunes?
- [ ] ¿«ημερολόγιο» siempre con apellido?
- [ ] ¿Cada imagen leída letra por letra?
- [ ] ¿«σε βοηθά», nunca «θεραπεύει»?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
