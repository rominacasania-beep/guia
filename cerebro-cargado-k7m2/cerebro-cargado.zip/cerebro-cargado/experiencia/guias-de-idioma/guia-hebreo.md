# Guía de estilo · hebreo (Israel)

> Aviso: es una guía de trabajo. Salió de leer revistas y portales israelíes y de revisiones con IA. Todo el hebreo lo escribió una IA: falta la lectura de una persona israelí. No pude leer reseñas de compradoras.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[israel]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | «את», femenino singular, siempre. El plural («אתם», «נסו», «כתבו») suena a formulario o a portal general |
| Verbos | Presente femenino para describir el uso («פותחת», «כותבת»). Imperativo femenino corto solo en instrucciones («כתבי», «נסי») |
| «Nosotras» | Se usa mucho y sirve para hablar de un problema sin acusar a la lectora |
| Registro | Oral, directo, con humor seco. Frases cortas. Nada solemne ni bíblico |
| Botones | En primera persona («quiero el mío») antes que una orden de venta, que suena agresiva |
| Qué no va | Referencias religiosas, la actualidad del país, marcas |

## Dirección, puntuación y formatos
| Tema | Cómo va |
|---|---|
| Dirección | De derecha a izquierda. Revisá la alineación de cada página y de cada bloque |
| Rangos de números | Se leen de izquierda a derecha aunque el texto sea hebreo. En la web hay que marcarlos aparte para que no se den vuelta |
| Prefijo y cifra | Prefijo hebreo, guion y cifra: «ל-14», «ב-10» |
| «Día» con números | De 11 para arriba va en singular: «14 יום» |
| «Para X días» | Con la preposición «ל-»: «תוכנית ל-14 יום» |
| Comillas | Rectas: " y ' |
| Vocales | Sin puntos de vocalización |
| Semana | De domingo a sábado |
| Moneda | Precio fijo en moneda local. El símbolo del séquel va pegado al número o con un espacio |
| «Sin» | «בלי» es como se habla. «ללא» es escrito y formal |

## Cómo lo dice ella (rubro bienestar)
| Hebreo | Qué quiere decir |
|---|---|
| הראש | la cabeza. Es la palabra: casi nunca «מוח» para lo cotidiano |
| הראש לא מפסיק | la cabeza no para |
| מחשבות רצות | pensamientos que corren |
| מוצפת | desbordada. El adjetivo para «no doy más» |
| עומס מנטלי | carga mental. Término de prensa |
| בלגן בראש · רעש בראש | lío en la cabeza · ruido en la cabeza |
| מתהפכת במיטה מצד לצד | dar vueltas en la cama |
| מהראש לנייר | de la cabeza al papel |
| להוציא | sacar |
| לשפוך על הדף | volcar todo en la hoja. Muy oral |
| לפרוק | descargar |
| הדף סופג הכול | el papel aguanta todo. Dicho hecho |
| לתת מילים לרגשות | ponerle palabras a las emociones |
| לעשות סדר | poner orden |
| בלי לשפוט | sin juzgar |
| לא מצליחה להתמיד | no logro sostenerlo |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| המוח שלך לא מפסיק | הראש לא מפסיק | «מוח» suena a clase de biología |
| רעש מנטלי | רעש בראש | Calco |
| לרוקן את המוח | לרוקן את הראש · להוציא מהראש | Calco |
| ג'ורנל · ג'ורנלינג (en titulares) | יומן · כתיבה | Anglicismo de nicho |
| הינך · אנא · על מנת | את · בבקשה (o nada) · כדי | Hebreo de formulario |
| «עוצמתי» · «מסע» · «טרנספורמציה» | תרגיל · דף · דרך | Jerga de coaching: cansa |
| ללא דף ריק | בלי דף ריק | Demasiado formal |
| 14 ימים | 14 יום | El singular es lo natural con esos números |
| Comillas « » y puntuación «a la española» | Comillas rectas | Tipografía habitual |
| מרפא · ריפוי | עוזר · מקל · נותן מקום | Promesa de cura |
| את סובלת מ…? | Escena, «nosotras» o primera persona | Diagnostica |

## Glosario del rubro (cuaderno imprimible)
| Español | Hebreo |
|---|---|
| diario | יומן |
| diario guiado | יומן מודרך |
| cuaderno de trabajo | חוברת עבודה |
| escritura terapéutica | כתיבה טיפולית |
| escritura creativa | כתיבה יוצרת |
| consigna | משימה |
| ejercicio | תרגיל |
| hoja | דף (no «נייר», salvo en el dicho «על הנייר») |
| hoja en blanco | דף ריק |
| calma | שקט · רוגע |
| creencia · creencia limitante | אמונה · אמונה מגבילה |
| gratitud | הכרת תודה |
| afirmación | אפירמציה |
| emoción | רגש |
| límites | גבולות |
| autoconocimiento | היכרות עצמית |
| tarjetas | קלפים |
| para colorear | לצביעה |
| día · semana · páginas | יום · שבוע · עמודים |
| no reemplaza la terapia | לא תחליף לטיפול |

## Trampas que me pasaron
- La alineación derecha/izquierda salió invertida y hubo que rehacer todos los PDF.
- Anuncios duplicados desde otro país quedaron con el enlace del país viejo.
- El generador de imágenes escribe bien el hebreo si le das el texto exacto, pero en una tapa se comió una palabra.
- Hay que revisar imágenes y símbolos que no correspondan al país.

## Lista de control antes de publicar
- [ ] ¿Femenino singular en todo, sin plurales?
- [ ] ¿Alineación a la derecha en cada página?
- [ ] ¿Los rangos de números se leen en el orden correcto?
- [ ] ¿«ראש», «דף», «יומן»?
- [ ] ¿«יום» en singular con números de 11 para arriba?
- [ ] ¿Comillas rectas?
- [ ] ¿Calendarios de domingo a sábado?
- [ ] ¿Sin referencias religiosas ni de actualidad?
- [ ] ¿Cada imagen leída letra por letra?
- [ ] ¿Aclara que no reemplaza la terapia?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
