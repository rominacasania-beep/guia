# Reglas que valen en todos los idiomas

Leela antes de abrir la guía de tu idioma. Son las reglas que repetí en los 9 y que más errores me ahorraron.

> Aviso: estas guías salieron de leer cómo escribe la gente de cada país y de revisiones hechas con IA. Ninguna persona nativa las certificó. Si podés, hacé revisar tu texto final por alguien del país.

## Las 10 reglas
| # | Regla | Por qué |
|---|---|---|
| 1 | Se reescribe, no se traduce | La traducción palabra por palabra se nota en la primera línea |
| 2 | Primero la guía, después el texto | Sin guía, cada página sale con palabras distintas para lo mismo |
| 3 | Un solo trato de punta a punta | Mezclar el «tú» y el «usted» del idioma delata la traducción |
| 4 | Una palabra para cada cosa | Si en la web se llama de una forma y en el PDF de otra, la clienta desconfía |
| 5 | Mayúscula solo en la primera palabra del título | Poner Mayúscula En Cada Palabra es costumbre del inglés |
| 6 | Sin signos de exclamación ni urgencia | En casi todos estos países suena a teletienda |
| 7 | No le digo a la lectora lo que «tiene» | Nada de «¿sufrís de…?». Cuento una escena o hablo en primera persona. Es mi regla para los anuncios de Meta |
| 8 | Ninguna promesa de cura | «Ayuda», «acompaña», «alivia». Nunca «cura», «elimina», «para siempre» |
| 9 | Las palabras de artículo no venden | Ella no dice «sobrecarga mental». Dice «tengo la cabeza llena» |
| 10 | Se avisa siempre: «revisado con IA, falta una persona nativa» | Para no creerme más segura de lo que estoy |

## Lo que no se traduce solo
- Fechas, moneda y primer día de la semana.
- Comillas y signos de pregunta.
- Tipografía: que la letra elegida tenga todas las letras del idioma.
- Largo del texto: algunos idiomas ocupan más lugar y hay que dejar aire.
- Referencias de mi país (comidas, fiestas, estaciones del año).
- Mi nombre, mi marca y mi usuario escondidos en las hojas.

## Cómo armé cada guía
1. Leí por lo menos 15 fuentes del país: revistas, blogs, foros, reseñas de productos parecidos y anuncios locales.
2. Anoté cómo lo dicen ellas, con sus palabras.
3. Anoté lo que «suena a traducción» y su reemplazo.
4. Marqué qué está visto en una fuente y qué es criterio de redacción.
5. Con la guía lista, recién ahí se traduce. Después, dos revisiones en limpio.

El pedido para que tu Claude arme la guía de un idioma que no está acá: [[pedido-guia-de-estilo-para-un-idioma-nuevo]].

## Las guías
[[guia-italiano]] · [[guia-danes]] · [[guia-hungaro]] · [[guia-polaco]] · [[guia-aleman]] · [[guia-frances]] · [[guia-griego]] · [[guia-hebreo]] · [[guia-chino-taiwan]]

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]] · [[lecciones]]
