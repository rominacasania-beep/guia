# Guía de estilo · danés (Dinamarca)

> Aviso: es una guía de trabajo. Salió de leer revistas, blogs y páginas de venta danesas y de revisiones con IA. No la certificó una persona nativa. No pude leer reseñas de compradoras.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[dinamarca]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | «du» siempre. Nadie trata de usted («De / Dem») |
| Tono | Quedarse corta antes que exagerar: «få lidt luft», no «total ro». Frase corta con punto |
| Mayúsculas | Solo la primera palabra del título |
| Números | En cifras |
| Mensaje de fondo | «Es totalmente normal». Nunca alarma |

## Formatos y puntuación
| Tema | Cómo va |
|---|---|
| Moneda | Precio directo en moneda local |
| Raya | Raya corta con un espacio a cada lado: « – ». Nunca la raya larga pegada a la palabra |
| Comas | Coma antes de «der», «hvad», «så»: «det, der fylder», «står der, hvad du …». Si falta, se nota la traducción |
| Por día | «om dagen». «pr. dag» y «per dag» suenan a oficina |
| Fecha y semana | Dato general, confirmalo: día, mes y año separados por puntos; la semana empieza en lunes |

## Cómo lo dice ella (rubro bienestar)
| Danés | Qué quiere decir |
|---|---|
| tankemylder | hormiguero de pensamientos. Es la palabra número uno |
| tankerne kører i ring | los pensamientos dan vueltas |
| larm i hovedet | ruido en la cabeza |
| få ro i hovedet · falde til ro | tener calma en la cabeza · aquietarse |
| give slip | soltar |
| skrive tankerne ned | escribir los pensamientos |
| tømme hjernen | vaciar la cabeza |
| sætte ord på | ponerle palabras |
| få styr på tanker og følelser | ordenar pensamientos y sentimientos |
| i dit eget tempo | a tu ritmo |
| det usynlige arbejde | el trabajo invisible |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| Hver side fortæller dig … | På hver side står der, hvad du skal skrive | Las páginas no «hablan»: es un calco |
| blankt ark · blank side | tom side | La primera forma es de un idioma vecino. En danés la hoja está «tom» |
| Download nu | Hent · Hent PDF'en | Anglicismo de botón |
| prompts · skriveprompts | øvelser · skriveøvelser · spørgsmål | Jerga inglesa |
| indre fred · heling · din rejse | ro i hovedet · falde til ro | Suena esotérico |
| du fortjener det · forkæl dig selv | Hablar del uso concreto | Suena a publicidad de cosmética |
| terapi (a secas) | terapeutisk skrivning · skriveøvelser | Promesa clínica |
| fantastisk · utrolig · forvandl dit liv | Frase corta con punto | Tono de vendedor: genera desconfianza |
| Tag kontrol over din angst | «Når tankerne kører i ring …» | Diagnostica y promete cura |

## Glosario del rubro (cuaderno imprimible)
| Español | Danés |
|---|---|
| diario | dagbog (la palabra principal; «journaling» solo como apoyo) |
| diario guiado | guidet dagbog |
| escritura terapéutica | terapeutisk skrivning · skriveterapi |
| ejercicios de escritura | skriveøvelser |
| hoja en blanco | tom side |
| tarjetas | kort (sacar una: «træk et kort») |
| PDF para imprimir | PDF til print |
| pago único | Engangsbetaling · Du betaler kun én gang |
| garantía con devolución | X dages garanti: Er den ikke noget for dig, får du pengene tilbage |
| día · semana · páginas | dag · uge · sider |
| botón para sumar un extra | JA! Tilføj til min ordre |

## Trampas que me pasaron
- El resumen del checkout siguió con rótulos en español (total, ahorro, pago seguro, garantía) aunque el resto estaba traducido.
- Algunas expresiones que parecían danesas eran de un idioma vecino.

## Lista de control antes de publicar
- [ ] ¿«du» en todo?
- [ ] ¿Frases cortas, con punto, sin exclamaciones?
- [ ] ¿Promete poco y concreto?
- [ ] ¿«tom side», «om dagen», «Hent»?
- [ ] ¿Coma antes de «der», «hvad», «så»?
- [ ] ¿Raya corta con espacios?
- [ ] ¿Los rótulos del checkout están en danés, mirados con la vista previa del país?

Ver también: [[revisar-el-checkout-como-otro-pais]] · [[lista-antes-de-publicar-una-traduccion]]
