# Guía de estilo · francés (Francia)

> Aviso: es una guía de trabajo. Salió de leer pódcasts, revistas, blogs y foros franceses y de revisiones con IA. No la certificó una persona nativa. No pude leer reseñas de compradoras.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[francia]].

## En una mirada
| Tema | Regla |
|---|---|
| Trato | Tuteo en femenino («arrêtée», «satisfaite»). Nunca mezclar «tu» y «vous» |
| Quién tutea | Los pódcasts y boletines para mujeres tutean. Los sitios de salud y las marcas tratan de «vous» |
| Tono | Íntimo. Frases cortas, con punto. Sin «Découvre», «Transforme ta vie» ni «incroyable» |
| Mayúsculas | Solo la primera palabra del título |
| Promesa | Chica: «poser», «mettre des mots», «souffler», «y voir plus clair». Nunca «adieu le stress» |

## Formatos y tipografía
| Tema | Cómo va |
|---|---|
| Espacios | Va un espacio antes de `: ? ! ;` |
| Comillas | « así », con espacio adentro. Nunca las comillas inglesas |
| Hora | «23 h 56», con espacios |
| Minutos | «X minutes» o «X min». Nunca «mins» |
| Ortografía | «tablette», «paiement» |
| Fecha, semana y moneda | Dato general, confirmalo: día/mes/año; semana que empieza en lunes; decimales con coma y el símbolo del euro después del número, con espacio |

## Cómo lo dice ella (rubro bienestar)
| Francés | Qué quiere decir |
|---|---|
| ça tourne en boucle | da vueltas sin parar. Es la fórmula |
| le hamster | la imagen del roedor que corre en la cabeza |
| ressasser · ruminer · cogiter | darle vueltas a lo mismo |
| charge mentale · penser à tout | carga mental · pensar en todo |
| lâcher prise | soltar |
| souffler (un peu) | tomarse un respiro |
| décompresser | aflojar |
| poser sur le papier | poner en el papel |
| vider ta tête | vaciar la cabeza |
| vider son sac | soltar todo lo guardado |
| mettre des mots sur ce que tu ressens | ponerle palabras a lo que sentís |
| y voir plus clair | ver más claro |
| faire le tri | ordenar, separar |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| le petit vélo dans la tête | ça tourne en boucle · le hamster | En el diccionario significa «estar medio loca» |
| feuille blanche | page blanche | Calco de «hoja en blanco» |
| journalisation | journaling · tenir un journal | Calco de sitios traducidos |
| ce qui te donne des tours | ce qui tourne (en boucle) dans ta tête | Calco de «lo que te da vueltas» |
| plan de X jours | parcours de X jours · programme de X jours | «Plan» suena a traducción |
| on te rend ton argent | on te rembourse · satisfaite ou remboursée | Calco |
| laisser aller · relâcher | lâcher prise | Calco |
| te soigner (por «cuidarte») | prendre soin de toi | Significa «curarte»: es promesa de salud |
| respirer (como alivio) | souffler (un peu) | Correcto, pero plano |
| nommer tes émotions | mettre des mots sur ce que tu ressens | Correcto, pero libresco |
| ton anxiété · tu es stressée · guérir | Una escena: «23 h 56, et ça tourne encore» | Diagnostica y promete cura |

Ojo con «écriture thérapeutique»: en Francia se usa en medios de salud, pero en un anuncio puede leerse como promesa de salud. En la web va bien. En anuncios prefiero «journal guidé» o «écriture introspective».

## Glosario del rubro (cuaderno imprimible)
| Español | Francés |
|---|---|
| diario guiado | journal guidé · carnet guidé |
| llevar un diario | tenir un journal |
| hoja en blanco | page blanche |
| consigna | consigne |
| ejercicio | exercice |
| tarjetas | cartes (sacar una: «pioche une carte») |
| PDF para imprimir | PDF à imprimer |
| pago único | Paiement unique · sans abonnement |
| garantía con devolución | Garantie X jours : si tu sens que ce n'est pas pour toi, on te rembourse |
| no hace falta saber escribir | pas besoin de « savoir écrire » |
| día · semana · páginas | jour · semaine · pages |

## Trampas que me pasaron
- Una expresión que parecía simpática significaba otra cosa. Cada frase hecha se busca antes de usarla.
- La oferta de después del pago quedó con el descuento en cero y mostraba el precio y el ahorro vacíos. Ver [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]].

## Lista de control antes de publicar
- [ ] ¿Tuteo y femenino en todo, sin un «vous» suelto?
- [ ] ¿Espacio antes de `: ? ! ;`?
- [ ] ¿Comillas « »?
- [ ] ¿«page blanche», «tablette», «paiement»?
- [ ] ¿«on te rembourse»?
- [ ] ¿Sin exclamaciones ni mayúsculas en cada palabra?
- [ ] ¿Cada frase hecha buscada en un diccionario?
- [ ] ¿Ninguna promesa de salud en los anuncios?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
