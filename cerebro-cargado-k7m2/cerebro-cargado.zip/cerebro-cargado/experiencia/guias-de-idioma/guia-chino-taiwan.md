# Guía de estilo · chino tradicional (Taiwán)

> Aviso: es una guía de trabajo. Salió de leer sitios y un foro taiwaneses y de revisiones con IA. No la revisó una persona taiwanesa. La lista de palabras «de China continental» es criterio propio.

Antes de usarla, leé [[reglas-comunes-a-todos-los-idiomas]]. La ficha del país está en [[taiwan]].

## En una mirada
| Tema | Regla |
|---|---|
| Escritura | Chino tradicional con vocabulario de Taiwán. Nunca simplificado |
| Trato | «妳» (tú femenino) siempre. Nunca mezclado con «你» ni con el formal «您» |
| Tono | Promesa chica y suave. Verbos «陪» (acompañar), «讓» (dejar), «放下» (soltar) |
| Estructura que usan | «明明…卻…»: «aunque… igual…» |
| Largo | El chino es compacto. Títulos cortos. Rótulos de dos a seis caracteres |

## Puntuación y tipografía
| Tema | Cómo va |
|---|---|
| Signos | De ancho completo: ，。、！？：； |
| Comillas | 「así」. Adentro, 『así』. Nunca " " |
| Separadores | ｜ o ・ |
| Suspensivos | ⋯⋯ |
| Cursiva y mayúsculas | No existen. Tampoco se separan las letras |
| Números | Arábigos en los titulares. En caracteres chinos solo dentro de la prosa |

## Formatos
| Tema | Cómo va |
|---|---|
| Moneda | El símbolo de la moneda local va adelante y sin decimales |
| Descuentos | Los locales se dicen al revés: nombran lo que pagás, no lo que ahorrás. Para no confundir, escribí «ahorrás tanto» (現省) o «precio original → hoy» (原價 → 今天只要) |
| Garantía | «X天滿意保證，不滿意全額退款». No la llames «鑑賞期»: esa figura legal no cubre lo digital |
| Terapia | «心理諮商». Nunca «心理咨詢» |
| Dónde imprimen | En la copistería o en la tienda de la esquina: sirve nombrarlo |

## Cultura
| Tema | Qué hacer |
|---|---|
| Número 4 | Evitalo en packs y valores: suena a «muerte» |
| Colores | Evitá el blanco y negro puros: es de luto. El rubro usa crema, té con leche y rosa viejo |
| Anunciar | Meta pide una declaración especial para anunciar en Taiwán |

## Cómo lo dice ella (rubro bienestar)
| Chino | Qué quiere decir |
|---|---|
| 腦袋停不下來 | la cabeza no para. La frase reina |
| 想太多 · 胡思亂想 | pensar de más. Lo cotidiano |
| 內心小劇場 | el teatrito mental. Muy taiwanés |
| 累到不行 | cansada a más no poder |
| 把想法寫下來 | escribir lo que pienso |
| 從腦袋移到紙上 | de la cabeza al papel |
| 整理思緒 · 釐清想法 | ordenar las ideas. El beneficio más repetido |
| 情緒有一個出口 | una salida para la emoción |
| 心情會輕鬆起來 | el ánimo se afloja. Suave, sin promesa |
| 不知道要寫什麼 | no sé qué escribir. El freno número uno |
| 滑手機 | pasar el dedo por el celular |

## Qué palabra para el producto
| Palabra | Cuándo |
|---|---|
| 日記 · 書寫日記 | La natural para un cuaderno guiado |
| 手帳 | Es la agenda decorable. No es lo mismo |
| 練習本 | Suena escolar |
| 筆記本 | Cuaderno en blanco o computadora portátil: evitar |
| «Journal» en inglés | Solo en nichos de papelería: evitar |
| 療癒 | La palabra del rubro en Taiwán. Nunca 治癒 ni 治愈 |

## Suena a China continental → se dice en Taiwán
| Evitar | Usar |
|---|---|
| 視頻 | 影片 |
| 信息 | 訊息 · 資訊 |
| 質量 | 品質 |
| 打印 | 列印 |
| 文件 (archivo) | 檔案 |
| 鏈接 | 連結 |
| 郵箱 | 信箱 |
| 網絡 | 網路 |
| 軟件 | 軟體 |
| 屏幕 | 螢幕 |
| 點擊 | 點一下 · 點選 |
| 計劃 | 計畫 |
| 心理咨詢 | 心理諮商 |
| 精神內耗 | 想太多 · 胡思亂想 |
| 性價比 · 高質量 | CP值 · 高品質 |

## Suena a traducción → suena local
| Evitar | Usar | Por qué |
|---|---|---|
| 這本日記將幫助妳… | Frase corta con 陪 o 讓 | «Este diario te ayudará a…» es calco |
| 妳的頭腦 | 腦袋 · 腦中 · 腦海 | Calco de «tu mente» |
| 過度思考 | 想太多 · 胡思亂想 | Suena a manual |
| 妳的療癒之旅 (en cada línea) | Una vez como mucho | Cansa |
| 立刻行動！不要錯過！ | 今天就開始寫 | Urgencia en cadena |
| Puntuación occidental (, . " ") | Ancho completo y 「」 | Se nota en la primera línea |
| 治好 · 根治 · 保證 | 輕一點 · 喘一口氣 · 整理 | Promesa de cura |
| 妳有焦慮嗎？ | Escena: «關了燈躺在床上…» | Diagnostica |

## Glosario del rubro (cuaderno imprimible)
| Español | Chino de Taiwán |
|---|---|
| diario | 日記 |
| cuaderno de ejercicios | 練習本 |
| ejercicio | 練習 |
| hoja en blanco | 空白頁 |
| creencia · creencia limitante | 信念 · 限制性信念 |
| afirmación | 肯定語 |
| gratitud | 感恩 |
| emoción | 情緒 |
| hábito | 習慣 |
| respiración | 呼吸 |
| reflexión | 反思 |
| reto | 挑戰 |
| tarjetas con preguntas | 提問卡 |
| semana uno · día uno | 第1週 · 第1天 |
| PDF para imprimir | 可列印 PDF |
| tablet | 平板 |
| pago único, sin suscripción | 一次付費，不用訂閱 |
| devolución total | 全額退款 |
| pago seguro | 安全付款 |
| precio original · precio de oferta | 原價 · 優惠價 |
| regalo | 贈品 |

## Trampas que me pasaron
- El generador de imágenes dibujó mal un carácter. Cada imagen se lee a tamaño real.
- Anuncios duplicados de este país terminaron en la campaña de otro, con el enlace viejo.
- La tipografía tiene que ser una que cubra el chino tradicional, y hay que incrustar solo los caracteres usados o el PDF pesa muchísimo.

## Lista de control antes de publicar
- [ ] ¿Tradicional y con palabras de Taiwán?
- [ ] ¿«妳» en todo, sin «你» ni «您»?
- [ ] ¿Puntuación de ancho completo y comillas 「」?
- [ ] ¿Sin cursivas, sin letras separadas?
- [ ] ¿Símbolo de la moneda adelante y sin decimales?
- [ ] ¿Ningún 4 en packs ni valores?
- [ ] ¿Colores que no sean blanco y negro puros?
- [ ] ¿«療癒» y «心理諮商»?
- [ ] ¿Cada imagen revisada carácter por carácter?
- [ ] ¿La declaración para anunciar en el país está hecha?

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[pedido-revision-nativa-en-dos-pasadas]]
