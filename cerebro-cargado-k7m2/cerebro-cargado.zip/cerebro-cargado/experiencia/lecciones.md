# 28 lecciones que ya pagué

Cada una dice qué pasó y qué se hace ahora. Claude las revisa antes de cada escalón.

## Campañas
| # | Qué pasó | Qué se hace ahora |
|---|---|---|
| 1 | Una campaña se creó sin hora de inicio y empezó a gastar a mitad del día | Toda campaña nueva se programa para las 00:00 del día siguiente. Si salió sin hora, se borra y se hace de nuevo |
| 2 | Se programó a la medianoche del país destino | Siempre la medianoche de TU hora, la misma para todos. Así los días se pueden comparar |
| 3 | Al cambiar el presupuesto de un conjunto activo, quedó en pausa sin avisar | Después de cada cambio, reactivar y volver a leer el estado |
| 4 | La hora se leyó mal y se cerraron países antes de tiempo | Confirmar la hora con una segunda fuente antes de decidir algo por horario |
| 5 | Se recomendó escalar un país mirando los últimos 7 días del panel, y ese día no había vendido | Se escala solo si vendió hoy, mirando hoy y los 4 días anteriores en la tienda |
| 6 | Se filtró por edad y género «por las dudas» | Conjuntos nuevos solo con país e idioma. Los que ya corren no se tocan |
| 7 | En la cuenta había borradores viejos y casi se publican todos juntos | Nunca «publicar todo». Se tilda uno por uno, solo lo propio |
| 21 | Claude cambió un presupuesto desde la conexión con Meta y el cambio quedó guardado como borrador: nunca salió | Después de cada cambio, Claude lo publica y vuelve a leer el estado y el monto. Si no lo ve vivo, no está hecho |
| 22 | La página de Facebook de un país quedó desactivada y todos los anuncios de ese país se frenaron con el aviso «la página no está publicada». Parecía un problema de los anuncios | Si los anuncios de un país se frenan todos juntos, primero se mira la lista de páginas desactivadas y se la vuelve a activar |

## Anuncios
| # | Qué pasó | Qué se hace ahora |
|---|---|---|
| 8 | Se armó una tanda grande con un producto inventado por la IA y hubo que tirarla entera | Todo anuncio muestra el producto real (tapa y páginas) junto a un dolor concreto |
| 9 | El generador de imágenes se comió palabras, inventó letras y copió errores | Leer cada imagen a tamaño real, letra por letra. Si está mal, se genera de cero |
| 10 | Se copiaron anuncios de otro país con el enlace viejo | Al duplicar, revisar destino, idioma y píxel de cada anuncio |

## Producto y tienda
| # | Qué pasó | Qué se hace ahora |
|---|---|---|
| 11 | Las traducciones sonaban a traducción | Antes de traducir, guía de estilo con frases reales del país. Después, dos revisiones en limpio |
| 12 | Quedaron marcas de la autora y palabras del idioma original escondidas en los PDF | Control automático del PDF final, sacando del filtro las palabras que también existen en el idioma destino |
| 13 | El checkout se veía en español desde mi computadora | Mirarlo con la vista previa «como otro país». No se traducen solos: nombres, botones, bloques propios y título de la pestaña |
| 14 | Apareció un precio distinto del que se había pedido | Verificar el precio en el checkout real |
| 15 | La carpeta de entrega quedó cerrada, o el producto sin entregable | Abrir el enlace sin sesión iniciada antes de anunciar. Sin entregable no se prende nada |
| 16 | Una tienda archivada siguió vendiendo y el número del día salió mal | Al sumar ventas, incluir las archivadas y avisar si alguna tiene anuncios gastando |
| 23 | Las compradoras dudaban porque creían que era una suscripción | Al lado de cada precio y de cada botón de compra va «pago único, sin mensualidades», en el idioma del país. No alcanza con decirlo una vez al final |
| 24 | Sabía cuántas compraban, pero no en qué parte de la página se iba la gente | Toda página nueva lleva un grabador de visitas gratuito con una marca en cada paso → [[ver-donde-se-va-la-gente]] |

## Mercado y cobros
| # | Qué pasó | Qué se hace ahora |
|---|---|---|
| 17 | Se saltó la validación de mercado | Primero la Biblioteca de Anuncios. Si algo parecido no corre hace tiempo, en varios idiomas y con varios anunciantes, no se lanza |
| 18 | Se recomendó un país que ya se había probado y apagado | Lista de países apagados con el motivo. Se lee antes de elegir |
| 19 | El botón «reintentar» no sirvió en ningún pago fallido | Se recupera mandando el enlace de pago por mail |
| 20 | Casi la mitad de los «fallidos» ya habían pagado en otro intento | Antes de escribirles, cruzar por mail con los pagos exitosos |
| 25 | Apagué un país y sus mails automáticos siguieron mandando enlaces a una tienda cerrada | Apagar un país es apagar todo: anuncios, mails automáticos (desactivados, no pausados) y aviso a las compradoras → [[lista-al-apagar-un-pais]] |
| 26 | Dos países vendían todos los días, pero durante dos semanas lo cobrado apenas cubría lo gastado. Con las comisiones, perdía | Vender no alcanza. Si un país pasa dos semanas en empate, se apaga y su lugar va a otro → [[paises-apagados]] |
| 27 | Una clienta pidió su plata y la respuesta fue por mail, donde ella no la veía | Reclamos, devoluciones y disputas se miran y se responden primero en el centro de reclamos de la plataforma de pagos. El mail va después |
| 28 | Me ofrecieron instalar un programa hecho por otra persona, «que es seguro» | Antes de instalar cualquier programa, archivo o habilidad ajena, Claude lo lee entero: a dónde se conecta, qué hace con tus claves, si manda datos afuera. Si algo es raro, no se instala |

Ver también: [[decisiones-de-ejemplo]] · [[paises-apagados]] · [[cobros]]
