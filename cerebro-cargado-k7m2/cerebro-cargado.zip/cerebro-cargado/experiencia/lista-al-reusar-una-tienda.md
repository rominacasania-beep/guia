# Lista de limpieza al reusar una tienda

Reusar la tienda de un país apagado ahorra un lugar del plan, pero deja restos del idioma anterior en sitios que nadie mira. Esta lista salió de encontrarlos uno por uno.

## En la tienda
- [ ] Nombre de la tienda e idioma
- [ ] Moneda y precio fijo del país nuevo
- [ ] Nombre y descripción de cada producto
- [ ] Portadas de todos los productos
- [ ] Entregables: que cada producto apunte al archivo del idioma nuevo
- [ ] Extras del checkout y sus textos
- [ ] Botones y rótulos del checkout (total, ahorro, pago seguro, garantía)
- [ ] Ofertas de después del pago, una por una
- [ ] Página de gracias
- [ ] Mails automáticos
- [ ] **Título de la pestaña del navegador**

## Fuera de la tienda
- [ ] Dominio o subdominio
- [ ] Píxel: sacar el viejo, poner el nuevo y cargar su token
- [ ] Página de Facebook: nombre, presentación, fotos, publicaciones viejas
- [ ] Enlaces de los anuncios duplicados

## Para cerrar
- [ ] Mirar el checkout con la vista previa «como otro país»
- [ ] Hacer una compra de prueba y abrir el entregable
- [ ] Buscar palabras del idioma anterior en la página y en los PDF

Ver también: [[alemania-y-suiza]] · [[decisiones-de-ejemplo]]
