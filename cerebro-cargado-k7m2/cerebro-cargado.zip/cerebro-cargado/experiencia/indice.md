# Índice · qué leer para cada situación

El mapa de todo el paquete. Buscá tu situación en la primera columna.

## Estoy por abrir un país
| Situación | Leé | Después |
|---|---|---|
| No sé qué país elegir | [[antes-de-elegir-pais]] | [[paises-apagados]] |
| Quiero abrir Italia | [[italia]] | [[guia-italiano]] |
| Quiero abrir Dinamarca | [[dinamarca]] | [[guia-danes]] |
| Quiero abrir Hungría | [[hungria]] | [[guia-hungaro]] |
| Quiero abrir Polonia | [[polonia]] | [[guia-polaco]] |
| Quiero abrir Alemania o Suiza | [[alemania-y-suiza]] | [[guia-aleman]] |
| Quiero abrir Francia | [[francia]] | [[guia-frances]] |
| Quiero abrir Grecia o Chipre | [[grecia-y-chipre]] | [[guia-griego]] |
| Quiero abrir Israel | [[israel]] | [[guia-hebreo]] |
| Quiero abrir Taiwán | [[taiwan]] | [[guia-chino-taiwan]] |
| Quiero abrir Portugal, Corea, Países Bajos o vender en ruso | [[portugal]] · [[corea]] · [[paises-bajos-y-belgica]] · [[ruso-en-el-baltico]] | [[paises-apagados]] |
| Mi idioma no está en las guías | [[pedido-guia-de-estilo-para-un-idioma-nuevo]] | [[reglas-comunes-a-todos-los-idiomas]] |
| Quiero ver el recorrido completo | [[llevar-un-producto-a-otro-idioma]] | [[lista-antes-de-prender-una-campana]] |
| Voy a reusar una tienda vieja | [[lista-al-reusar-una-tienda]] | [[reusar-una-pagina-de-facebook]] |
| Facebook no me deja crear la página | [[reusar-una-pagina-de-facebook]] | |

## Estoy traduciendo
| Situación | Leé | Después |
|---|---|---|
| No sé por dónde empezar | [[reglas-comunes-a-todos-los-idiomas]] | La guía de tu idioma |
| Mi texto suena a traducción | La guía de tu idioma | [[pedido-revision-nativa-en-dos-pasadas]] |
| Quiero que Claude lo revise como nativa | [[pedido-revision-nativa-en-dos-pasadas]] | |
| Ya está, ¿lo publico? | [[lista-antes-de-publicar-una-traduccion]] | |
| El checkout se ve en español | [[revisar-el-checkout-como-otro-pais]] | [[pedido-revisar-mi-checkout-como-otro-pais]] |

## Estoy armando la campaña
| Situación | Leé | Después |
|---|---|---|
| No sé cómo nombrar la campaña | [[estructura-y-nombres-de-campana]] | [[etiquetas-de-seguimiento]] |
| No sé cuántos conjuntos ni cuánto poner | [[estructura-y-nombres-de-campana]] | |
| No sé a quién apuntar | [[segmentacion-abierta]] | |
| No sé a qué hora sale | [[salida-a-las-00]] | |
| No sé qué anuncio vende | [[etiquetas-de-seguimiento]] | |
| ¿Puedo prender? | [[lista-antes-de-prender-una-campana]] | |

## Ya está corriendo
| Situación | Leé | Después |
|---|---|---|
| Mi país gasta y no vende | [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]] (la pantalla rota) | [[revisar-el-checkout-como-otro-pais]] · [[lista-al-apagar-un-pais]] |
| Tengo un anuncio que gana | [[renovar-un-anuncio-ganador]] | [[pedido-renovaciones-del-dia]] |
| Quiero subir presupuesto | [[escalar-por-la-hora-en-que-compra-cada-pais]] | [[cobros]] |
| Meta dice cero ventas y la tienda cobró | [[etiquetas-de-seguimiento]] | [[hungria]] |
| Vendo, pero la plata no llega | [[cobros]] | [[italia]] |
| Tengo pagos fallados | [[recuperar-carritos-y-pagos-fallados]] | [[cobros]] |
| La gente llega al pago y se va | [[recuperar-carritos-y-pagos-fallados]] | [[revisar-el-checkout-como-otro-pais]] |
| Quiero que cada venta deje más | [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]] | [[decisiones-de-ejemplo]] |
| No sé qué hacer cada día | [[rutina-diaria]] | |
| Tengo que apagar un país | [[lista-al-apagar-un-pais]] | [[paises-apagados]] |
| Algo salió mal | [[lecciones]] | [[decisiones-de-ejemplo]] |

## Todo lo que hay
| Carpeta | Qué trae |
|---|---|
| `paises/` | 13 fichas: qué pasó en cada país o idioma |
| `guias-de-idioma/` | 9 guías de estilo completas + las reglas comunes |
| `metodo/` | 13 notas de cómo trabajo, una por tema |
| `plantillas/` | 3 listas de control y 4 pedidos listos para copiar |
| Sueltas | [[lecciones]] · [[decisiones-de-ejemplo]] · [[paises-apagados]] · [[cobros]] · [[lista-al-reusar-una-tienda]] |

## Recordá
Es mi experiencia, no una regla universal. Las guías de idioma no las certificó una persona nativa. Nada de esto promete un resultado: te ahorra errores que yo ya pagué.
