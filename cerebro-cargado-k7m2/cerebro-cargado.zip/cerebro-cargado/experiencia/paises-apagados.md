# Países que probé y apagué

Leelo antes de elegir un país nuevo. Un país apagado para mí no es un país malo: es un dato de lo que pasó con mi producto en ese momento.

| País | Por qué lo apagué | Qué haría distinto |
|---|---|---|
| [[paises-bajos-y-belgica]] | Gastó varios días sin ventas | Guardar las reglas de idioma aunque se apague |
| [[corea]] | Entraban pocas visitas y no compró nadie | Hacer la guía de estilo antes y conseguir una revisión de alguien del país |
| [[ruso-en-el-baltico]] | El público era muy chico y se repetía | Mirar el tamaño del público antes de traducir todo |
| [[portugal]] | Pocas ventas, y pocas visitantes pasaban de la página al pago | No entrar solo porque a otras les va bien |

## La regla
Si a los 4 días un país gastó y no vendió, se apaga y se abre el siguiente. Cortar rápido libera plata y un lugar para el próximo.

## Al apagar
1. Primero se apagan los anuncios.
2. Después se archiva la tienda.
3. Se revisa que nada siga gastando.
4. Se anota acá, con el motivo.

Ver también: [[lecciones]] · [[decisiones-de-ejemplo]]
