# Países que probé y apagué

Leelo antes de elegir un país nuevo. Un país apagado para mí no es un país malo: es un dato de lo que pasó con mi producto en ese momento.

| País | Por qué lo apagué | Qué haría distinto |
|---|---|---|
| [[paises-bajos-y-belgica]] | Gastó varios días sin ventas | Guardar las reglas de idioma aunque se apague |
| [[corea]] | Entraban pocas visitas y no compró nadie | Hacer la guía de estilo antes y conseguir una revisión de alguien del país |
| [[ruso-en-el-baltico]] | El público era muy chico y se repetía | Mirar el tamaño del público antes de traducir todo |
| [[portugal]] | Pocas ventas, y pocas visitantes pasaban de la página al pago | No entrar solo porque a otras les va bien |
| [[grecia-y-chipre]] | Pocas ventas y lo cobrado muy por debajo de lo gastado | Guardar la guía del idioma: sirve para otro producto |
| [[dinamarca]] | Vendía, pero quedó en empate. Necesitaba el lugar de la tienda para otro país | Avisar a las compradoras antes de archivar la tienda |
| [[francia]] | Dos semanas en empate: con las comisiones, perdía | Mirar la ganancia con las comisiones, no solo si vende |

## Las dos reglas
| Lo que pasa | Qué hago |
|---|---|
| A los 4 días gastó y no vendió | Se apaga y se abre el siguiente |
| Vende, pero dos semanas seguidas lo cobrado apenas cubre lo gastado | Se apaga igual: con las comisiones, perdés |

Cortar rápido libera plata y un lugar para el próximo. Un país que empata también ocupa una tienda.

## Al apagar
Apagar un país es apagar **todo**, no solo los anuncios. La lista completa, en orden: [[lista-al-apagar-un-pais]].

Ver también: [[lecciones]] · [[decisiones-de-ejemplo]]
