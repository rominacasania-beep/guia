# Cobros: qué mirar antes de escalar un país

Vender no es lo mismo que cobrar. Esto es lo que vi en mis propias tiendas.

## Semáforo por país
| País | Cómo me fue | Detalle |
|---|---|---|
| [[hungria]] | 🟢 | Cobró desde el primer día, sin trabas |
| [[israel]] | 🟢 | Cobra en moneda local sin problemas |
| [[italia]] | 🟡 | La plataforma de pagos retuvo cobros durante semanas por ser cuenta nueva |
| [[dinamarca]] | 🟡 | Hay que mirar cuántos pagos con tarjeta fallan. Lo apagué por empate, no por cobros |
| Turquía | 🔴 | No lo abrí: la plataforma de pagos rechaza demasiados pagos allá y no hay otro medio. Queda en espera hasta tener uno |
| [[alemania-y-suiza]] | 🟡 | Hasta la primera venta no sabés cuánto llega neto |
| El resto | Sin dato | No tengo observación propia |

## Lo que aprendí
- **Una cuenta nueva puede tener la plata retenida varias semanas.** Vendés hoy y cobrás después. No reinviertas plata que todavía no llegó.
- **Mirá los pagos fallados antes de subir presupuesto.** Si en un país fallan muchos, primero se arregla el cobro.
- **El botón «reintentar» no me sirvió nunca.** Lo que funciona es mandar el enlace de pago por mail.
- **Casi la mitad de los «fallidos» ya habían pagado en otro intento.** Cruzá por mail antes de escribirles.
- **Un mail mal escrito por la compradora = entrega que no sale.** Revisá las entregas que rebotan: terminan en reclamo.
- **Confirmá que tu plataforma de cobro funciona en el país antes de traducir.**
- **El precio se elige directo en la moneda local**, con un número que allá se vea normal.
- **Antes de elegir país, mirá dónde cobra tu plataforma.** Cada plataforma publica la lista de países donde no cobra. El mundo entero menos esa lista es mercado posible. Si en un país hay un solo medio de pago, tomalo como alerta.
- **Si la plataforma aprueba pocos pagos en un país, no lo abro.** Preguntale a su soporte cuántos pagos aprueba ahí. Si rebota uno de cada tres, espero a tener otro medio de cobro.
- **Los reclamos se responden donde está el reclamo.** Si una clienta pide su plata o abre una disputa, se mira y se le contesta en el centro de reclamos de la plataforma de pagos: ahí lo ve ella y ahí se resuelve. El mail va después, como complemento. Devolver la plata lo decidís vos.
- **«Pago único, sin mensualidades» al lado de cada precio.** Si la compradora cree que es una suscripción, no compra o reclama después.

Ver también: [[lecciones]]
