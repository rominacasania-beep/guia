# Cobros: qué mirar antes de escalar un país

Vender no es lo mismo que cobrar. Esto es lo que vi en mis propias tiendas.

## Semáforo por país
| País | Cómo me fue | Detalle |
|---|---|---|
| [[hungria]] | 🟢 | Cobró desde el primer día, sin trabas |
| [[israel]] | 🟢 | Cobra en moneda local sin problemas |
| [[italia]] | 🟡 | La plataforma de pagos retuvo cobros durante semanas por ser cuenta nueva |
| [[dinamarca]] | 🟡 | Hay que mirar cuántos pagos con tarjeta fallan |
| [[alemania-y-suiza]] | 🟡 | Hasta la primera venta no sabés cuánto llega neto |
| El resto | Sin dato | No tengo observación propia |

## Lo que aprendí
- **Una cuenta nueva puede tener la plata retenida varias semanas.** Vendés hoy y cobrás después. No reinviertas plata que todavía no llegó.
- **Mirá los pagos fallados antes de subir presupuesto.** Si en un país fallan muchos, primero se arregla el cobro.
- **El botón «reintentar» no me sirvió nunca.** Lo que funciona es mandar el enlace de pago por mail.
- **Casi la mitad de los «fallidos» ya habían pagado en otro intento.** Cruzá por mail antes de escribirles.
- **Un mail mal escrito por la compradora = entrega que no sale.** Revisá las entregas que rebotan: terminan en reclamo.
- **Confirmá que tu plataforma de cobro funciona en el país antes de traducir.**
- **El precio se elige directo en la moneda local**, con un número que allá se vea normal.

Ver también: [[lecciones]]
