# Alemania y Suiza · alemán

Estado: **sigue abierto**.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | De «du». Las empresas serias usan «Sie», pero este tipo de producto no. Tono sobrio: punto final y cero urgencia |
| Formatos | Un precio en euros y otro en francos suizos. En Suiza no se usa la ß: escribí todo sin ß para que sirva en los dos países |
| Lo que les da miedo | La suscripción escondida. Decí clarito «pago único, sin abono». La garantía se escribe con una fórmula fija |
| Trampas | Reusé una tienda de otro idioma y quedaron restos por todos lados: título de la pestaña, páginas de después del pago, página de gracias, píxel viejo |
| Cobro | 🟡 Hasta no tener la primera venta, no sabés cuánto te llega neto |

**La lección:** reusar una tienda ahorra un lugar, pero exige una limpieza con lista.

Ver también: [[lista-al-reusar-una-tienda]] · [[decisiones-de-ejemplo]]
