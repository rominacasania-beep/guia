# Países Bajos y Bélgica · holandés

Estado: **apagado**. Se probó, gastó sin ventas y se cerró.

No me quedaron guardadas las reglas de idioma de este país: la tienda ya no existe.

**La lección:** anotá el país apagado en una lista. Más adelante me lo volvieron a recomendar, porque nadie se acordaba de que ya lo había probado.

Ver también: [[paises-apagados]]
