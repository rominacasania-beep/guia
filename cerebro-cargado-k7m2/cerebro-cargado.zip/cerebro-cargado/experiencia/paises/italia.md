# Italia · italiano

Estado: **sigue abierto**. Es de los que sostienen.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | De «tu», en femenino. Mayúscula solo en la primera palabra del título. Sin signos de exclamación ni tono de vendedor |
| Formatos | Precio fijo en euros para el país, no convertido desde otra moneda |
| Trampas | Hay palabras que parecen iguales al español y significan otra cosa. Y una misma pieza del producto terminó llamándose de dos formas, una en la web y otra en el PDF |
| Cobro | 🟡 La plataforma de pagos retuvo cobros durante semanas por ser una cuenta nueva. Un mail de compradora mal escrito hizo que la entrega no saliera y terminó en reclamo |

**La lección:** un país puede vender bien y la plata igual tardar en llegar. Contá con eso antes de reinvertir.

Ver también: [[lecciones]] · [[cobros]]
