# Portugal · portugués

Estado: **apagado**. Hubo pocas ventas, no cubrían el gasto, y pocas visitantes pasaban de la página al pago.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Portugués de Portugal, no de Brasil. Los textos que sugería la IA de Meta venían en brasileño |
| Formatos | Precio fijo en euros |
| Trampas | La carpeta de entrega quedó restringida y la compradora no podía abrirla. Una portada generada salió con una palabra mal escrita. La tienda archivada siguió vendiendo porque la campaña había quedado activa, y el resumen de ventas no la contaba |
| Cobro | Sin observación destacada |

**La lección:** al apagar un país, primero se apagan los anuncios y después la tienda. Y se revisa que nada siga gastando.

Ver también: [[paises-apagados]] · [[decisiones-de-ejemplo]]
