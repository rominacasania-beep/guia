# Taiwán · chino tradicional

Estado: **sigue abierto**.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | «Tú» femenino (妳), nunca mezclado con el neutro ni con el formal. Vocabulario de Taiwán, no de China continental |
| Formatos | El símbolo de la moneda va adelante y sin decimales. Los descuentos locales se expresan al revés (lo que pagás, no lo que ahorrás): conviene escribir «ahorrás X %». Puntuación de ancho completo y comillas 「」. No existen la cursiva ni las mayúsculas |
| Trampas | Evitar el número 4 en packs y valores, y el blanco y negro puro (es de luto). Meta pide una declaración especial para anunciar en Taiwán. El generador de imágenes dibujó mal un carácter |
| Cobro | Cobra en varias monedas, sin precio fijo local. Sin observación propia sobre aprobación |

**La lección:** además de traducir, hay que revisar números, colores y símbolos.

Ver también: [[lecciones]]
