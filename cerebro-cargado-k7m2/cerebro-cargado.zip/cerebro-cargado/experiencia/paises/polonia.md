# Polonia · polaco

Estado: **sigue abierto**.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Tuteo en femenino: los verbos marcan el género. «ty» en minúscula suena a revista y «Ty» en mayúscula suena a blog. Las dos valen, pero no se mezclan |
| Formatos | Comillas „ ”. La palabra «garantía» sola suena a electrodoméstico: se dice «X días para devolver». Averiguá el plazo de devolución que la gente espera allá antes de escribir el tuyo |
| Trampas | Cadenas de sustantivos calcadas del español. Un anuncio que funcionaba traía un error de ortografía y el generador de imágenes lo copió en las versiones nuevas |
| Cobro | Sin datos propios |

**La lección:** revisá también lo que «ya estaba bien». Los errores viejos se heredan en cada copia.

Ver también: [[lecciones]]
