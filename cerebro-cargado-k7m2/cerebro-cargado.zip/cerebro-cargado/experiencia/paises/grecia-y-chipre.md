# Grecia y Chipre · griego

Estado: **apagado**. Vendió muy poco y lo cobrado quedó muy por debajo de lo gastado. La guía del idioma queda: sirve para cualquier producto.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Tuteo singular, todo en femenino. Griego estándar, sin giros de Chipre |
| Formatos | La semana va de lunes a domingo: hubo que rearmar todos los calendarios. Fecha día/mes/año. La pregunta se cierra con «;». Decimales con coma, y el euro va después del número. La Pascua cae en otra fecha |
| Mayúsculas | En MAYÚSCULAS se quitan los acentos, pero la diéresis queda. La letra sigma se escribe distinta al final de la palabra |
| Trampas | La tipografía de los títulos no tenía letras griegas, ni la del PDF ni la de la web. Al pasar a mayúsculas por programa quedaban los acentos. Una portada generada traía una palabra con letras inventadas. El texto ocupa más lugar: hay que dejar aire |
| Cobro | Sin observación todavía |

**Qué pasó:** salí con una campaña «todo junto», gastó sin vender y volví a la estructura de prueba de siempre.

**La lección:** elegí la tipografía y el primer día de la semana antes de traducir. Después cuesta el doble.

Ver también: [[decisiones-de-ejemplo]] · [[lecciones]]
