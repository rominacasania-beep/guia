# Dinamarca · danés

Estado: **sigue abierto**. La oferta con juego después del pago funcionó muy bien.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Siempre de «du»: nadie trata de usted. Mejor quedarse corta que exagerar. Sin exclamaciones ni mayúsculas en cada palabra |
| Formatos | Precio directo en moneda local. Números en cifras. Raya con espacio a los lados. Hay comas obligatorias antes de ciertas frases: si faltan, se nota la traducción |
| Trampas | El resumen del checkout siguió con rótulos en español (total, ahorro, pago seguro, garantía) aunque el resto estaba traducido. Algunas expresiones son de un idioma vecino, no danesas |
| Cobro | 🟡 Mirá cuántos pagos con tarjeta fallan antes de escalar |

**La lección:** en un país chico con buen poder de compra, la oferta de después del pago pesa tanto como la venta principal.

Ver también: [[cobros]] · [[lecciones]]
