# Hungría · húngaro

Estado: **sigue abierto**. Fue la página que mejor convertía.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Tuteo siempre. Los medios serios tratan de usted; las revistas que lee este público, no. Órdenes cortas y suaves |
| Formatos | Moneda local sin decimales, con precio fijo para el país. Comillas „…”. No existen ¡ ni ¿. Mayúscula solo en la primera palabra. La semana empieza en lunes |
| Trampas | Los originales traían marcas escondidas de la autora (logo, iniciales, fotos, usuario) que en dos países anteriores nadie había visto. El control de «restos de español» marcaba una palabra que también existe en húngaro |
| Cobro | 🟢 Cobró desde el primer día con tarjeta y con la plataforma de pagos, sin trabas |

**Qué pasó:** salí sin la clave de conversiones del servidor. Había ventas cobradas y Meta no registraba ninguna.

**La lección:** cargá la conexión de conversiones antes de prender los anuncios. Si no, Meta aprende a ciegas.

Ver también: [[decisiones-de-ejemplo]] · [[lecciones]]
