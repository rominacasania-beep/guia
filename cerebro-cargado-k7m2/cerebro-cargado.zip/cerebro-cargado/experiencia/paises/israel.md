# Israel · hebreo

Estado: **sigue abierto**. Es de los que sostienen. De acá salió el complemento de checkout más aceptado, que después llevé a todas las tiendas.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Femenino singular siempre: el plural suena a formulario. Se lee de derecha a izquierda. Comillas rectas |
| Formatos | Precio fijo en moneda local. La semana va de domingo a sábado. Los rangos de números se leen de izquierda a derecha aun dentro del texto hebreo. Con números de 11 para arriba, «día» va en singular |
| Trampas | La alineación derecha/izquierda salió invertida y hubo que rehacer todos los PDF. Anuncios duplicados desde otro país quedaron con el enlace del país viejo. Hay que revisar imágenes y símbolos que no correspondan al país. El generador de imágenes escribe bien el hebreo si le das el texto exacto, pero en una tapa se comió una palabra |
| Cobro | 🟢 Cobra en moneda local, con tarjeta y con la plataforma de pagos, sin problemas |

**La lección:** un alfabeto distinto no es una barrera si controlás la dirección, la alineación y cada imagen letra por letra.

Ver también: [[lecciones]] · [[decisiones-de-ejemplo]]
