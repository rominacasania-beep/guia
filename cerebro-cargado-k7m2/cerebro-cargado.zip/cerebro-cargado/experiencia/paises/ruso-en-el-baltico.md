# Ruso en el Báltico · ruso

Estado: **apagado**.

| Tema | Lo que aprendí |
|---|---|
| A quién | Personas que hablan ruso en países chicos. Regla fija: nunca apuntar a Rusia ni a Bielorrusia (anuncios bloqueados, sin tarjetas, sanciones) |
| Cómo se le habla | No armé guía de estilo. Revisado solo por IA |
| Trampas | La tipografía de los títulos no tenía alfabeto cirílico. El producto principal había quedado sin entregable propio, aunque el diagnóstico de la tienda lo daba por bueno |
| Cobro | Sin observación: no hubo ventas |

**Qué pasó:** el público era muy chico. Las mismas personas veían el anuncio varias veces, algunas llegaban al pago y ninguna compraba.

**La lección:** antes de traducir todo, mirá de qué tamaño es el público.

Ver también: [[paises-apagados]] · [[decisiones-de-ejemplo]]
