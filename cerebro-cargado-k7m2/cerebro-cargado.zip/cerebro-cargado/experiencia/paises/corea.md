# Corea · coreano

Estado: **apagado** a los pocos días. Entraban pocas visitas y no compró nadie.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | No armé guía de estilo. Lo revisó solo una IA, ninguna persona coreana. Hoy no lo haría así |
| Formatos | Calendario de domingo a sábado. Cobró en varias monedas, sin precio fijo local |
| Trampas | La tipografía coreana hace que los PDF pesen muchísimo si no se incrusta solo lo que se usa. La página de Facebook tuvo que sumarse a la cuenta del negocio para que salieran los anuncios |
| Cobro | Sin observación: no hubo ventas |

**La lección:** cortar rápido un país que no arranca libera plata y un lugar para el siguiente.

Ver también: [[paises-apagados]]
