# Francia · francés

Estado: **apagado**. Después de arreglar la pantalla rota vendió todos los días, pero dos semanas en empate: con las comisiones, perdía. El francés sigue vivo para Quebec.

| Tema | Lo que aprendí |
|---|---|
| Cómo se le habla | Tuteo en femenino, sin mezclar «tu» y «vous». Frases cortas, con punto |
| Formatos | Espacio antes de `: ? ! ;`. Comillas « ». La hora se escribe «23 h 56». «10 minutes», no «10 mins». Mayúscula solo inicial |
| Trampas | Una expresión que parecía simpática significaba «estar medio loca». La oferta de después del pago quedó con el descuento en cero y mostraba el precio y el ahorro vacíos |
| Cobro | Sin observación propia clara |

**Qué pasó:** la gente veía la oferta de después del pago y nadie la aceptaba, porque se mostraba rota.

**La lección:** antes de bajar el presupuesto, recorré todo el camino como si fueras la compradora. A veces el problema es una pantalla rota. Y si ya está todo sano y solo empata, se apaga: no se espera más.

Ver también: [[decisiones-de-ejemplo]] · [[lecciones]]
