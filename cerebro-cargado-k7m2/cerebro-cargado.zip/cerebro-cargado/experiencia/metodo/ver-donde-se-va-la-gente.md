# Ver dónde se va la gente

La tienda te dice cuántas compraron. No te dice **en qué parte** de la página se fue el resto. Para eso uso un grabador de visitas gratuito (Microsoft Clarity): muestra grabaciones de cada visita, por dónde tocan y hasta dónde bajan.

## Qué hago en cada página nueva
| Paso | Qué | Quién |
|---|---|---|
| 1 | Crear un proyecto en Clarity, uno por tienda o por página | Claude, con tu sesión iniciada |
| 2 | Pegar el código en la página. En la tienda, va en la configuración de seguimiento | Claude. Si la plataforma pide aprobar, el clic es tuyo |
| 3 | Poner una **marca en cada paso importante**: empezó, llegó a la mitad, vio el resultado, tocó comprar | Claude |
| 4 | Comprobar en vivo que carga y que las marcas salen | Claude |
| 5 | Armar el embudo con esas marcas, para ver cuántas pasan de un paso al otro | Claude |

## Cómo lo leo
| Lo que veo | Qué quiere decir | Qué arreglo |
|---|---|---|
| Se van en la portada, antes de empezar | El arranque no engancha | El titular y la primera imagen |
| Llegan al final y no tocan comprar | El precio o la oferta no convencen | Cómo presento el precio. «Pago único, sin mensualidades» al lado |
| Tocan comprar y no pagan | Falla el checkout o el cobro | [[revisar-el-checkout-como-otro-pais]] · [[recuperar-carritos-y-pagos-fallados]] |

## Cuidados
- El embudo solo deja elegir marcas que ya pasaron alguna vez. Si una todavía no ocurrió, se arma con lo que hay y se completa después.
- Mirá pocos días juntos, no una sola tarde: con pocas visitas, los porcentajes saltan.
- Es para saber **qué arreglar**, no para decidir si un anuncio es ganador. Eso lo deciden las ventas cobradas.

## El pedido
> Poné Clarity en mi página [DIRECCIÓN], con una marca en cada paso importante, y comprobá en vivo que carga. Después armá el embudo con esas marcas.

Ver también: [[lista-antes-de-prender-una-campana]] · [[lecciones]]
