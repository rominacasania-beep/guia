# Renovar un anuncio ganador con variantes

Un ganador se cansa. Antes de que se caiga, le saco variantes. Lo hago todos los días.

## Qué es un ganador
4 ventas cobradas o más y cobrado mayor al doble del gasto.

## Qué es una renovación
**No es un anuncio nuevo.** Es el mismo ganador con UN cambio.

| Si es imagen | Si es video |
|---|---|
| Otro gancho | Otro gancho en los primeros segundos |
| Otro titular | Otro orden de tomas |
| Otra primera imagen | Otra música |
| | Otros subtítulos |

## Las tres variantes
Mis renovaciones salían todas iguales al original. Ahora cada ganador lleva tres, bien distintas.

| Variante | Qué cambia | Para qué |
|---|---|---|
| R1 · gemela | Mismo estilo visual, otro gancho | Ver si el gancho tenía más para dar |
| R2 · otra familia | Misma promesa, otro estilo visual | Ver si la promesa aguanta otra cara |
| R3 · bien distinta | Un estilo que no se parece en nada | Buscar el próximo ganador |

Además de renovar, todos los días salen anuncios nuevos de prueba para cada país, cada uno de una familia visual distinta.

## Reglas que no se saltean
- Todo anuncio muestra el producto real (tapa y páginas) junto a un dolor concreto. Una tanda entera con un producto inventado por la IA hubo que tirarla.
- Cada imagen se lee a tamaño real, letra por letra. Si está mal, se genera de cero.
- Llevo un registro de qué estilo usé en cada tanda, para no repetir.
- El código del estilo va al final del nombre del archivo.

## Dónde queda cada cosa
| Carpeta | Qué va |
|---|---|
| Anuncios › Nuevos › «fecha PAÍS» | Los de prueba del día |
| Anuncios › Renovaciones › «fecha PAÍS» | Las variantes del día |
| Anuncios › Material de trabajo | Originales, referencias y descartes |

El archivo lleva idioma y país en el nombre. Se sube a Meta sin renombrarlo: así después puedo limpiar de mi compu lo que ya está subido.

## Cómo salen
Cada renovación entra a la campaña de prueba del país como un conjunto nuevo, con la fecha en el nombre. Ver [[estructura-y-nombres-de-campana]] y [[salida-a-las-00]].

El pedido listo para copiar: [[pedido-renovaciones-del-dia]].

Ver también: [[lecciones]] · [[rutina-diaria]]
