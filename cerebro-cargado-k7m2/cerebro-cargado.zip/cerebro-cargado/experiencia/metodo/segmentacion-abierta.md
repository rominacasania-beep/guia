# Segmentación abierta

En los conjuntos nuevos pongo solo dos cosas: **dónde** y **en qué idioma**. Nada más.

## Qué va y qué no
| Va | No va |
|---|---|
| País o región | Edad sugerida |
| Idioma | Género |
| Público automático prendido | Intereses «por las dudas» |

Mi producto lo compran mujeres. Igual no filtro por «mujeres»: dejo que Meta las encuentre.

## Por qué
Una vez se filtró por edad y género «por las dudas». Lo corregí y quedó como regla: los conjuntos nuevos salen abiertos.

## Cuidados
- **Los conjuntos que ya corren no se tocan.** Cambiarles el público les reinicia el aprendizaje. La regla vale para los próximos.
- En la identidad del anuncio, donde pide cuenta de Instagram, elijo «Usar la página de Facebook». Si no queda marcada, recargo la página y la vuelvo a elegir.
- Hay países que piden una declaración especial para anunciar. Se hace antes.

## Un caso distinto: el mismo idioma en muchos países
Con el español no uso «toda la región». Las campañas nuevas salen solo a los pocos países donde más vendí, con idioma español. Así el mismo presupuesto llega a más gente de la que compra. Sigue sin edad ni género.

Ver también: [[estructura-y-nombres-de-campana]] · [[lecciones]]
