# Segmentación abierta

En los conjuntos nuevos pongo solo dos cosas: **dónde** y **en qué idioma**. Nada más.

## Qué va y qué no
| Va | No va |
|---|---|
| País o región | Edad sugerida |
| Idioma | Género |
| Público automático prendido | Intereses «por las dudas» |

Mi producto lo compran mujeres. Igual no filtro por «mujeres»: dejo que Meta las encuentre.

## Por qué
Una vez se filtró por edad y género «por las dudas». Lo corregí y quedó como regla: los conjuntos nuevos salen abiertos.

## Cuidados
- **Los conjuntos que ya corren no se tocan.** Cambiarles el público les reinicia el aprendizaje. La regla vale para los próximos.
- En la identidad del anuncio, donde pide cuenta de Instagram, elijo «Usar la página de Facebook». Si no queda marcada, recargo la página y la vuelvo a elegir.
- Hay países que piden una declaración especial para anunciar. Se hace antes.

## El idioma manda, no el país
Una campaña nueva no va solo al país de la tienda: va a **todos los lugares donde se habla ese idioma**, con el idioma como filtro. Así, en un país con varios idiomas, solo la ven quienes usan Facebook en el tuyo.

| Idioma | A dónde va |
|---|---|
| Francés | Francia, Bélgica, Suiza, Luxemburgo, Mónaco y Quebec (Canadá) |
| Italiano | Italia, Suiza y San Marino |
| Alemán | Alemania, Austria, Suiza, Luxemburgo y Liechtenstein |
| Cualquier otro | Pedile a Claude la lista de países donde se habla, y cruzala con [[paises-apagados]] y con los países donde cobra tu plataforma → [[cobros]] |

Las campañas que ya corren no se tocan: vale para las próximas. Antes de sumar un lugar, revisá que tu checkout cobre ahí.

## Un caso distinto: el español
Con el español no uso «toda la región». Las campañas nuevas salen solo a los pocos países donde más vendí, con idioma español. Así el mismo presupuesto llega a más gente de la que compra. Sigue sin edad ni género.

Ver también: [[estructura-y-nombres-de-campana]] · [[lecciones]]
