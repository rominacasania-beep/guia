# Qué miro antes de elegir país

Elegir mal un país cuesta una traducción entera. Estas son las preguntas que me hago antes, en este orden.

## Las 8 preguntas
| # | Pregunta | Dónde miro | Si la respuesta es mala |
|---|---|---|---|
| 1 | ¿Ya lo probé y lo apagué? | [[paises-apagados]] | No vuelvo, salvo que haya cambiado algo |
| 2 | ¿Algo parecido se vende hace tiempo, en varios idiomas y con varios anunciantes? | Biblioteca de Anuncios | No se lanza. Este paso no se saltea |
| 3 | ¿Quién vende esto en ESE país? | Biblioteca de Anuncios del país y buscadores | Si está lleno, entro con otro ángulo o no entro |
| 4 | ¿Mi plataforma de cobro funciona en el país y en su moneda? | El panel de pagos | Primero se arregla el cobro |
| 5 | ¿Cómo paga la gente allá? | Tiendas locales | Si se paga distinto y no lo tengo, freno |
| 6 | ¿De qué tamaño es el público? | El estimado al armar el conjunto | Si es diminuto, el anuncio se repite y nadie compra |
| 7 | ¿El idioma me pide algo técnico? | La guía del idioma | Lo resuelvo ANTES de traducir |
| 8 | ¿Tengo una tienda y una página apagadas para reusar? | Mi lista de tiendas y páginas | Reviso si entra en el plan |

## Qué significa cada semáforo de competencia
| Semáforo | Qué vi | Qué hago |
|---|---|---|
| 🟢 Libre | Nadie vende algo así en ese idioma, pero sí en otros | Buen candidato |
| 🟡 Con rivales | Hay uno o dos, y ninguno ataca mi dolor | Entro con mi ángulo |
| 🔴 Saturado | Varios anunciantes instalados hace mucho | Necesito anuncios muy frescos, o lo dejo |

Ojo: «nadie lo vende en ningún idioma» no es libre. Es una idea sin probar.

## Lo técnico del idioma (pregunta 7)
- [ ] ¿Otro alfabeto? → tipografía que tenga todas las letras
- [ ] ¿Se escribe de derecha a izquierda? → alineación de todo
- [ ] ¿La semana empieza otro día? → rearmar calendarios
- [ ] ¿Fiestas en otra fecha?
- [ ] ¿El texto ocupa más lugar?
- [ ] ¿Hay que declarar algo especial para anunciar ahí?

## Lo que me pasó por saltear preguntas
| Salteé | Resultado |
|---|---|
| La 1 | Se recomendó un país que ya había apagado |
| La 2 | Lancé sin validar el mercado |
| La 6 | Un idioma con poca competencia tenía un público diminuto → [[ruso-en-el-baltico]] |
| «A otras les va bien» en lugar de la lista | Pocas ventas y lo cerré a los días → [[portugal]] |
| La 7 | La tipografía no tenía las letras, y hubo que rearmar los calendarios → [[grecia-y-chipre]] |

## Y después de abrirlo
Si a los 4 días gastó y no vendió, se apaga y pasa el siguiente. Ver [[lista-al-apagar-un-pais]].

Ver también: [[llevar-un-producto-a-otro-idioma]] · [[cobros]] · [[lecciones]]
