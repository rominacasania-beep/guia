# Salida a las 00:00

Nada sale «ahora». Todo conjunto nuevo arranca a las 00:00 del día siguiente, en MI hora.

## La regla
| Pregunta | Respuesta |
|---|---|
| ¿A qué hora arranca? | A las 00:00 del día siguiente |
| ¿Hora de quién? | La mía. No la del país destino |
| ¿Vale para todos los países? | Sí, la misma para todos |
| ¿Y si lo quiero ya? | Solo si lo decido yo, a propósito |

## Por qué
- Un conjunto que arranca a mitad del día gasta raro y ese día no se puede comparar con nada.
- Con la misma medianoche para todos, los días de todos los países se pueden comparar.

## Cómo se hace
1. Al **crear** el conjunto, se le pone la hora de inicio. Después ya no se puede: Meta lo da por «empezado» aunque esté en pausa.
2. Recién ahí se activan campaña, conjunto y anuncio. Queda activo, pero no gasta hasta esa hora.
3. El nombre del conjunto lleva esa fecha. Ver [[estructura-y-nombres-de-campana]].

## Lo que me pasó
| Qué pasó | Qué se hace ahora |
|---|---|
| Una campaña se creó sin hora y empezó a gastar a mitad del día | Si salió sin hora, se borra y se hace de nuevo |
| Se programó a la medianoche del país destino | Siempre mi medianoche |
| Al editar la hora de un conjunto activo, quedó en pausa | Se reactiva y se comprueba que quedó activo |
| Se pensó en una tarea que lo prendiera más tarde | No sirve: depende de que la compu esté abierta |

Ver también: [[lecciones]] · [[lista-antes-de-prender-una-campana]]
