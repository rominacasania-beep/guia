# Reusar una página de Facebook

Para un país nuevo no creo una página: primero miro si tengo una apagada y la reuso.

## Por qué
Una vez Facebook no me dejó crear la página de un país nuevo. Dos intentos y el botón no hacía nada. Reusé la de un país apagado y salió en el día. Quedó como regla.

## Paso a paso
1. Listar las páginas que no se usan (las de países apagados).
2. Confirmar que la elegida **no tenga anuncios activos**.
3. Cambiarle el nombre, en el idioma del país nuevo.
4. Borrar **todas** las publicaciones viejas.
5. Cargar lo nuevo: presentación, texto largo, foto de perfil, portada, botón y publicaciones.
6. Anotar en mi mapa de páginas a qué país pertenece ahora.

## Qué lleva la página nueva
| Pieza | Cómo |
|---|---|
| Nombre | En el idioma del país |
| Presentación y texto largo | Revisados como el resto de la traducción |
| Foto de perfil y portada | Dos imágenes distintas |
| Botón | Con el enlace a la web del país |
| Publicaciones | Unas pocas para que no se vea vacía |
| Cuenta del negocio | La página tiene que estar sumada, o los anuncios no salen |

## Cuidados
- Una página con restos del idioma anterior hace desconfiar. Mirala como la vería una clienta.
- Las imágenes generadas se leen letra por letra antes de subirlas.
- Si para Instagram elegís «Usar la página de Facebook», ese nombre es el que se ve en el anuncio.

Ver también: [[lista-al-reusar-una-tienda]] · [[paises-apagados]] · [[segmentacion-abierta]]
