# Etiquetas de seguimiento

Son unas palabras que se agregan al final del enlace del anuncio. Con ellas, la tienda me dice qué anuncio trajo cada venta. Sin ellas, decido a ciegas.

## Qué pongo en todo anuncio nuevo
| Etiqueta | Qué lleva | Para qué me sirve |
|---|---|---|
| utm_source | facebook | Saber que vino de un anuncio de Meta |
| utm_medium | paid | Saber que fue pago |
| utm_campaign | El nombre de la campaña | Qué país y qué campaña |
| utm_term | El nombre del conjunto | Qué conjunto vendió |
| utm_content | El nombre del anuncio | Qué anuncio vendió |
| utm_id | El identificador del anuncio | Desempatar si dos se llaman igual |

Los nombres no se escriben a mano. Se usan los **campos dinámicos** de Meta, que los completan solos: `{{campaign.name}}`, `{{adset.name}}`, `{{ad.name}}`, `{{ad.id}}`.

La línea completa, lista para pegar en «parámetros de URL»:

```
utm_source=facebook&utm_medium=paid&utm_campaign={{campaign.name}}&utm_term={{adset.name}}&utm_content={{ad.name}}&utm_id={{ad.id}}
```

## Reglas
- Nunca etiquetas fijas inventadas. Si copiás el anuncio, la etiqueta fija queda mintiendo.
- No se agregan etiquetas a anuncios que ya están prendidos.
- El botón del anuncio es «Ver más» y el destino es la web.
- Como las etiquetas llevan los nombres, los nombres tienen que decir algo. Por eso el conjunto lleva la fecha: [[estructura-y-nombres-de-campana]].

## Para qué las uso
- Para ver en la tienda qué conjunto vendió de verdad, aunque Meta no lo muestre.
- Para escalar el conjunto correcto: [[escalar-por-la-hora-en-que-compra-cada-pais]].
- Si una venta llega sin etiqueta, miro Meta como respaldo.

## Lo que me pasó
En el lanzamiento de un país se armó la campaña sin las etiquetas. Había ventas y no se sabía de qué anuncio. Ahora está en la lista de antes de prender.

Ver también: [[lista-antes-de-prender-una-campana]]
