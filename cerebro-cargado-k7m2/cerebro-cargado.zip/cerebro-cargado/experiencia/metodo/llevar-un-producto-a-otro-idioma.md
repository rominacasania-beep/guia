# Llevar un producto a otro idioma, de punta a punta

El recorrido completo que repetí en cada país. Lo hace casi todo Claude. Yo pongo contraseñas, claves, el precio, el nombre elegido y el OK para publicar y gastar.

## Lo que le paso a Claude al empezar (en un solo mensaje)
- Producto, idioma y país.
- Precio y precio tachado.
- Si hay extras de checkout y ofertas de después, y a qué precio.

## Las etapas
| # | Etapa | Qué queda listo |
|---|---|---|
| 0 | Arranque | Producto, idioma, país, precio local y nombre |
| 1 | Validar en la Biblioteca de Anuncios | Una lista de los mejores anuncios parecidos. Sin esto no se sigue |
| 2 | Cómo hablan allá | Guía de estilo con frases reales. Ver [[reglas-comunes-a-todos-los-idiomas]] |
| 3 | Clienta ideal | Ficha con 10 dolores en sus palabras. Cada dolor da un ángulo de anuncio |
| 4 | Traducción | Producto y regalos en el idioma, mismo diseño. Dos revisiones en limpio |
| 5 | Carpeta de entrega | Una carpeta por producto, con el enlace abierto y probado sin sesión |
| 6 | Tienda | Idioma, dominio, moneda local con precio fijo, cobros, checkout limpio, entregables |
| 7 | Extras y ofertas de después | Ver [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]] |
| 8 | Página de venta | Dolores arriba, sin testimonios inventados, mirada en el celular |
| 9 | Página de Facebook | Ver [[reusar-una-pagina-de-facebook]] |
| 10 | Píxel | El del país, conectado a la tienda, con la clave de conversiones cargada y una visita de prueba registrada |
| 11 | Anuncios | Un ángulo por dolor, con el producto real. Ver [[estructura-y-nombres-de-campana]] |
| 12 | Antes de prender | [[lista-antes-de-prender-una-campana]] completa y mi OK |

## Reglas fijas
1. **Idioma nativo, no traducción literal.** Y siempre el aviso: «revisado con IA, falta una persona nativa».
2. **Mi nombre no viaja.** Ni marca, ni fotos mías, ni usuario impreso en las hojas.
3. **Sacar lo que no viaja:** contenido religioso, marcas ajenas, billetes, frases en otro idioma.
4. **Soporte firma con un nombre de pila**, en el idioma de la clienta.
5. **La carpeta de trabajo se llama en español.** Los archivos de adentro, en su idioma.
6. **Fechas locales:** la semana como se usa allá.
7. **Nada se publica, se prende ni se gasta sin mi OK.**

## El checkout limpio
- Pide solo el correo.
- Sin barra de «tantas personas comprando».
- Resumen arriba, con la imagen del paquete completo.
- Todos los rótulos en el idioma.

## La página de venta
Dolores reales → por qué funciona → adelanto del interior → testimonios reales → el paquete → lista de lo que recibe → garantía → pasos → preguntas frecuentes → cierre.

**Prueba social honesta:** testimonios reales traducidos, sin nombres, aclarando que vienen de la versión original. Nada de «alguien acaba de comprar» ni contadores falsos.

## Traducir los PDF sin romper el diseño
- Se reusa el armado del idioma anterior: mismas cajas, cambia el texto.
- La letra tiene que cubrir el idioma. Y se incrustan solo las letras usadas, o el PDF pesa muchísimo.
- Al final, un control automático compara el PDF nuevo con el original y caza restos que el ojo no ve. Además, se mira página por página.
- Del control se sacan las palabras que existen en los dos idiomas.
- Siempre queda una tabla bilingüe para que yo pueda revisar.

## Errores que ya pagué en este recorrido
| Qué pasó | Qué se hace ahora |
|---|---|
| Cargué los regalos como productos sueltos | Van dentro de la carpeta del producto |
| El subdominio ya estaba usado | Revisar antes de elegir el nombre |
| Archivos de anuncios sin idioma ni país en el nombre | Idioma y país siempre en el nombre |
| El lector automático no vio palabras en adornos y portadas | Mirar todas las páginas, no solo el texto detectado |
| Salí sin la clave de conversiones | Va antes de prender |

Ver también: [[antes-de-elegir-pais]] · [[lista-antes-de-publicar-una-traduccion]] · [[lecciones]] · [[lista-al-reusar-una-tienda]]
