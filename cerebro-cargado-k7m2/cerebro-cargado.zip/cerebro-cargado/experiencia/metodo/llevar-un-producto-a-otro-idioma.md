# Llevar un producto a otro idioma, de punta a punta

El recorrido completo que repetí en cada país. Lo hace casi todo Claude. Yo pongo contraseñas, claves, el precio, el nombre elegido y el OK para publicar y gastar.

## Lo que le paso a Claude al empezar (en un solo mensaje)
- Producto, idioma y país.
- Precio y precio tachado.
- Si hay extras de checkout y ofertas de después, y a qué precio.

## Las etapas
| # | Etapa | Qué queda listo |
|---|---|---|
| 0 | Arranque | Producto, idioma, país, precio local y nombre |
| 1 | Validar en la Biblioteca de Anuncios | Una lista de los mejores anuncios parecidos. Sin esto no se sigue |
| 2 | Cómo hablan allá | Guía de estilo con frases reales. Ver [[reglas-comunes-a-todos-los-idiomas]] |
| 3 | Clienta ideal | Ficha con 10 dolores en sus palabras. Cada dolor da un ángulo de anuncio |
| 4 | Traducción | Producto y regalos en el idioma, mismo diseño. Dos revisiones en limpio |
| 5 | Carpeta de entrega | Una carpeta por producto, con el enlace abierto y probado sin sesión |
| 6 | Tienda | Idioma, dominio, moneda local con precio fijo, cobros, checkout limpio, entregables |
| 7 | Extras y ofertas de después | Ver [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]] |
| 8 | Página de venta | Dolores arriba, sin testimonios inventados, mirada en el celular |
| 9 | Página de Facebook | Ver [[reusar-una-pagina-de-facebook]] |
| 10 | Píxel | El del país, conectado a la tienda, con la clave de conversiones cargada y una visita de prueba registrada |
| 11 | Anuncios | Un ángulo por dolor, con el producto real. Ver [[estructura-y-nombres-de-campana]] |
| 12 | Antes de prender | [[lista-antes-de-prender-una-campana]] completa y mi OK |

## Reglas fijas
1. **Idioma nativo, no traducción literal.** Y siempre el aviso: «revisado con IA, falta una persona nativa».
2. **Mi nombre no viaja.** Ni marca, ni fotos mías, ni usuario impreso en las hojas.
3. **Sacar lo que no viaja:** contenido religioso, marcas ajenas, billetes, frases en otro idioma.
4. **Soporte firma con un nombre de pila**, en el idioma de la clienta.
5. **La carpeta de trabajo se llama en español.** Los archivos de adentro, en su idioma.
6. **Fechas locales:** la semana como se usa allá.
7. **Nada se publica, se prende ni se gasta sin mi OK.**

## El checkout limpio
- Pide solo el correo.
- Sin barra de «tantas personas comprando».
- Resumen arriba, con la imagen del paquete completo.
- Todos los rótulos en el idioma.

## La página de venta
Dolores reales → por qué funciona → adelanto del interior → testimonios reales → el paquete → lista de lo que recibe → garantía → pasos → preguntas frecuentes → cierre.

**Prueba social honesta:** testimonios reales traducidos, sin nombres, aclarando que vienen de la versión original. Nada de «alguien acaba de comprar» ni contadores falsos.

## Traducir los PDF sin romper el diseño
- Se reusa el armado del idioma anterior: mismas cajas, cambia el texto.
- La letra tiene que cubrir el idioma. Y se incrustan solo las letras usadas, o el PDF pesa muchísimo.
- Al final, un control automático compara el PDF nuevo con el original y caza restos que el ojo no ve. Además, se mira página por página.
- Del control se sacan las palabras que existen en los dos idiomas.
- Siempre queda una tabla bilingüe para que yo pueda revisar.

## Controles que sumé al recorrido
| Cuándo | Control |
|---|---|
| Antes de todo | Claude revisa los accesos solo leyendo (tienda, Meta, dominio, carpeta de entrega, correo) y me muestra una tabla ✅ / ❌. No se arranca a medias |
| Al arrancar | Una nota `ESTADO` en la carpeta del país: qué se hizo, qué se decidió, qué falló. Si la sesión se corta, se retoma desde ahí |
| Al arrancar | El país de origen es el que más vendió en los últimos 7 días. De ahí salen la oferta y los 5 anuncios que más venden |
| En la ficha del país | Medios de pago, garantía legal y lo que la ley pide en el pie, buscados en la web y con la fuente al lado. Nunca de memoria |
| En la tienda | Lo que sobra de la tienda copiada se borra: en borrador se sigue viendo. Un extra nunca queda visible sin su archivo cargado |
| En la tienda | Los textos legales (términos, privacidad, reembolsos, contacto) también van en el idioma. Los datos de mi empresa los pongo yo |
| En las imágenes | Zoom a cada texto. El generador cambia tildes y mete fechas que a tamaño celular no se ven |
| En las ofertas de después | Recorrer cada camino: todo «no», todo «sí» y mezclado |
| En los videos | Leer todos los cuadros: se cuelan subtítulos del idioma viejo por una fracción de segundo. Y escuchar la voz: el acento tiene que ser del país |
| En la revisión | La revisora nativa recorre TODO lo que ve la clienta (anuncios, página, checkout, legales, ofertas, PDF) y repite hasta que una pasada completa no encuentra nada |
| En Meta | Hay un cupo de cambios por hora y por cuenta. Cargar una tanda entera lo gasta casi todo: no hacer otros cambios en esa hora |
| En Europa | Meta pide declarar quién se beneficia y quién paga el anuncio. Sin eso da error |
| Al cerrar | Cada renglón de la lista final lleva su prueba: dónde se vio. Un renglón sin prueba no está hecho |

## Errores que ya pagué en este recorrido
| Qué pasó | Qué se hace ahora |
|---|---|
| Cargué los regalos como productos sueltos | Van dentro de la carpeta del producto |
| El subdominio ya estaba usado | Revisar antes de elegir el nombre |
| Archivos de anuncios sin idioma ni país en el nombre | Idioma y país siempre en el nombre |
| El lector automático no vio palabras en adornos y portadas | Mirar todas las páginas, no solo el texto detectado |
| Salí sin la clave de conversiones | Va antes de prender |

Ver también: [[antes-de-elegir-pais]] · [[lista-antes-de-publicar-una-traduccion]] · [[lecciones]] · [[lista-al-reusar-una-tienda]]
