# Revisar el checkout como si fueras de otro país

Desde mi computadora el checkout se ve en mi idioma y con mi moneda. La clienta ve otra cosa. Hay que mirarlo con sus ojos.

## El problema
El idioma y la moneda del checkout salen de la ubicación de quien entra. Si entro yo, veo mi país. Puedo creer que está todo bien y estar roto para ella.

## Cómo lo miro
| Forma | Sirve |
|---|---|
| Entrar a la dirección pública desde mi compu | No. Muestra mi país |
| La vista previa «como otro país» del panel de la tienda, con mi sesión abierta | Sí |
| Pedirle a Claude que lea el checkout público del país y me lo muestre | Sí, cuando la vista previa no existe para ese tipo de tienda |

Preguntá en el soporte de tu plataforma cómo se abre esa vista previa: en la mía es un agregado al final de la dirección, con el código del país.

## Lo que NO se traduce solo
- [ ] Nombres y descripciones de los productos
- [ ] Texto del botón de pagar
- [ ] Botón del extra del checkout
- [ ] Fila «agregar todas las ofertas»
- [ ] Bloques propios (los textos que escribí yo)
- [ ] Rótulos del resumen: total, ahorro, pago seguro, garantía
- [ ] **Título de la pestaña del navegador.** Si queda vacío, muestra el nombre interno de la tienda

## Además miro
- [ ] El precio: que sea el que pedí, en la moneda del país. Una vez apareció otro
- [ ] Las ofertas de después del pago, una por una
- [ ] La página de gracias
- [ ] El mail de entrega
- [ ] Que el entregable abra sin tener una sesión iniciada

## Un detalle del español
Si vendés a varios países que hablan español, escribí la tienda en español neutro, de «tú». El voseo se siente ajeno fuera del Río de la Plata.

El pedido listo para copiar: [[pedido-revisar-mi-checkout-como-otro-pais]].

Ver también: [[lecciones]] · [[lista-al-reusar-una-tienda]] · [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]]
