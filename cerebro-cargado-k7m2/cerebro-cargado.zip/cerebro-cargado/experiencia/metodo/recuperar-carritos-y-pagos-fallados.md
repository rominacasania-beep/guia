# Recuperar carritos y pagos fallados por mail

Quien llegó al checkout ya quería comprar. Si se fue o el pago falló, un mail con el enlace la trae de vuelta. Es plata que ya estaba en la puerta.

## Lo primero: qué NO sirve
El botón «reintentar» de la plataforma de pagos no me funcionó en ningún pago fallido. La tarjeta no queda guardada para volver a cobrarla. Lo que funciona es mandarle a la persona el enlace del checkout por mail.

## Cómo lo tengo armado
| Pieza | Cómo |
|---|---|
| Herramienta | Un servicio de mails conectado a cada tienda |
| Flujos por tienda | Dos: carrito abandonado y pago rechazado |
| Mails por flujo | Tres, separados en el tiempo |
| Idioma | El de cada tienda, con voz nativa. Ver [[reglas-comunes-a-todos-los-idiomas]] |
| Descuento | Sube de un mail al siguiente. Con fecha de vencimiento |
| Quién firma | Soporte, con un nombre de pila. Nunca mi nombre |
| Remitente | Una casilla con dominio propio, verificado |
| Qué lleva | El enlace directo al checkout |

## Antes de escribirle a nadie
**Cruzar por mail con los pagos exitosos.** Casi la mitad de mis «fallidos» ya habían pagado en otro intento. Si les escribo, las molesto y quedo mal.

## Paso a paso para arrancar
1. Conectar el servicio de mails a cada tienda. La clave la pego yo: Claude nunca escribe claves.
2. Poner cada tienda en modo «mails propios», para que salgan en su idioma.
3. Armar los dos flujos por tienda.
4. Mandarme una prueba y confirmar que llega a la bandeja de entrada, no a spam.
5. Decidir qué hacer con los carritos viejos. Yo les mandé un solo aviso, por país, a la mañana de allá.
6. Poner fecha para apagar los cupones.

## Cuidados
- **El tope de contactos del plan.** Cada carrito nuevo suma un contacto. Si te pasás, el plan sube de precio solo. Limpiá a quienes ya compraron o ya recibieron todos los mails.
- No importes listas grandes por el mismo motivo.
- Nada de «más barato». El mail recuerda y ayuda, no remata.
- Un mail mal escrito por la compradora es una entrega que no sale. Revisá las entregas que rebotan.
- Yo no entro a la herramienta de mails. Claude la vigila y me avisa: una tabla de «avisos» y un reporte por día.

Ver también: [[cobros]] · [[rutina-diaria]] · [[lecciones]]
