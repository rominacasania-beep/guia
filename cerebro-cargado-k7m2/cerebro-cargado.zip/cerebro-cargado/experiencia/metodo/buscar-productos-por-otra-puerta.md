---
tema: método
para: elegir qué vender (escalón 1)
---

# Buscar productos por otra puerta

**La idea:** si busco «ebook» o «journal» en la Biblioteca de Anuncios como todo el mundo, me aparecen los mismos diez productos que a miles de personas. Todas los copian y en pocas semanas ese mercado se llena. No es que el producto sea malo: la búsqueda fue igual a la de todas.

Por eso no busco más horas: busco **cruzando cosas que casi nadie cruza**. Cada capa que sumo deja menos gente peleando por lo mismo que yo.

## Las 6 palancas

| Palanca | Qué elijo | Ejemplos |
|---|---|---|
| 1 · Puerta | Por dónde entro al tema | Un dolor que quita el sueño · un deseo grande · un oficio o hobby · algo que hoy se vende en papel · una fecha del año · un problema de la casa |
| 2 · Nicho | Uno o dos, cruzados | Crianza + cocina · espiritualidad + orden de la casa |
| 3 · Palabras | Lo que escribo en el buscador, como lo diría una página de venta de ese país | «para imprimir», «paso a paso», «en 21 días», «sin experiencia», «descarga inmediata» |
| 4 · A quién | La persona que compra | Abuelas · maestras · mamás de chicos chicos · mujeres de 40 a 60 |
| 5 · Formato | Qué recibe | Diario guiado · plan de días · recetario · planos o patrones · plantillas · kit para imprimir |
| 6 · Idioma | Dónde lo busco | Lo lleno en español puede estar vacío en polaco, húngaro o danés |

Si una combinación no trae nada, cambio **una sola** palanca y vuelvo a buscar. Si cambio todas a la vez, no sé cuál fue la que abrió la puerta.

## Las 5 reglas antes de enamorarme de un producto

1. **Dos números juntos.** Días del anuncio más viejo y cantidad de anuncios prendidos. Un anuncio viejo solo, o muchos anuncios nuevos, no prueban nada.
2. **Tres anunciantes o más.** Si lo venden tres páginas distintas desde hace semanas, está probado. Si lo vende una sola, puede ser suerte.
3. **Vacío no es oportunidad.** La Biblioteca no muestra lo que fracasó. Si no lo vende nadie, puede ser porque nadie lo compra.
4. **Modelo al original.** El que tiene más días y más anuncios es el que lo inventó. Las copias suelen copiar también sus errores.
5. **Entro a la página real.** Abro el anuncio y llego hasta donde se paga. A veces lo que se ve de afuera no es lo que se vende.

## El pedido que le paso a Claude

> Quiero buscar un producto digital por otra puerta. Puerta: […]. Nicho: […] + […]. Palabras: […]. A quién: […]. Formato: […]. Idioma y países: […].
> Traducí las palabras al idioma como las escribiría una página de venta de ese país y buscá en la Biblioteca de Anuncios, en mi navegador.
> Dame 5 ofertas en una tabla: qué vende, a quién, precio, anuncios activos, días del más viejo, anunciantes distintos, link al anuncio y link a la página de venta. Aplicá las 5 reglas. Si no aparece nada, cambiá una sola palanca. Solo lectura.

En la guía «De 0 a 100 por día» (escalón 1) está el generador: tocás una opción por palanca, o «Sortear», y te arma este pedido solo.

Relacionado: [[antes-de-elegir-pais]] · [[llevar-un-producto-a-otro-idioma]]
