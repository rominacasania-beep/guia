# El extra del checkout y las ofertas de después de la compra

La venta principal paga el anuncio. Lo que deja ganancia muchas veces viene después: el extra que se suma con un clic y la oferta que aparece al terminar de pagar.

## Las dos piezas
| Pieza | Dónde aparece | Qué es |
|---|---|---|
| Extra del checkout | En la página de pago, antes de pagar | Un producto chico y barato que se suma con un tilde |
| Oferta de después | Al terminar de pagar, antes de la página de gracias | Otro producto, con descuento, que se acepta con un clic |

## El extra del checkout
- Son productos chicos. Varios por tienda, y una fila «llevar todos».
- **Lo que mejor funciona en un país se prueba en los demás.** Encontré un extra que en un país se lo llevaba una gran parte de las compradoras. Lo traduje y lo puse en todas las tiendas.
- El plan de la tienda tiene un tope de lugares. Para sumar uno, reuso el lugar del más flojo: archivo, portada, nombre y precio, todo junto.
- El botón del extra y la fila «llevar todos» se traducen a mano. No salen solos.

### La portada manda
| No funciona | Funciona |
|---|---|
| Portada clara con letra chica | Una escena fuerte con un objeto protagonista |
| Varias portadas parecidas | Cada una se distingue de lejos |
| Título largo | Título enorme, que se lea en el celular |

En el checkout la portada se ve muy chica. Si no se entiende en un segundo, se confunde con las demás. Cada portada generada se lee letra por letra a tamaño real.

### Cómo cargo uno nuevo sin que se vea vacío
1. Lo creo oculto (marcado «solo para después de la compra»).
2. Le cargo el entregable y la portada.
3. Recién ahí lo paso a visible en el checkout.

## Las ofertas de después de la compra
Mi escalera, sin números:

1. Oferta A con descuento.
2. Si la rechaza → la misma oferta A con más descuento.
3. Acepte o rechace → oferta B, otro producto.
4. Si rechaza la B → la misma B con más descuento.

- En un país chico con buen poder de compra, una oferta con un juego después del pago funcionó muy bien.
- El embudo arranca **pausado** hasta que todos los archivos estén cargados.
- Si la plataforma crea rebajas automáticas que no pedí, Claude me avisa.

## La pantalla rota que me costó un país
Un país perdía y yo no quería bajarle el presupuesto. Recorrí el camino entero: la oferta de después se mostraba, pero nadie la aceptaba. Tenía el descuento en cero, y donde iban el precio normal y el ahorro salían espacios vacíos.

**Qué reviso ahora en cada oferta:**
- [ ] ¿Se ve el precio normal?
- [ ] ¿Se ve cuánto ahorra?
- [ ] ¿El descuento que dice la página es el que está cargado?
- [ ] ¿Está en el idioma del país?
- [ ] ¿El entregable abre?

## Cómo lo mido
Cada cambio se mide una semana. Anoto qué puse, dónde y desde cuándo, en `decisiones.md`.

Ver también: [[revisar-el-checkout-como-otro-pais]] · [[decisiones-de-ejemplo]] · [[francia]] · [[dinamarca]] · [[israel]]
