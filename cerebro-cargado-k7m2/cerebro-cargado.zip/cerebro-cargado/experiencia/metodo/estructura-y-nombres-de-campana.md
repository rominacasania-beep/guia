# Estructura y nombres de campaña

Una campaña de prueba por país, siempre igual. Y nombres que me dejen saber, sin abrir nada, de qué tanda es cada anuncio.

## La campaña de prueba
| Pieza | Cómo va |
|---|---|
| Campaña | Una por país. Es la campaña madre: no se cierra, se le va sumando |
| Presupuesto | Por conjunto, no por campaña |
| Conjuntos | 5 |
| Anuncios | 1 por conjunto |
| Gasto | 7 dólares por día cada conjunto |
| Evento | Compra |
| Píxel | El del país |
| Público | Abierto. Ver [[segmentacion-abierta]] |
| Salida | A las 00:00 del día siguiente. Ver [[salida-a-las-00]] |

## Cuándo se corta y cuándo es ganador
| Señal | Qué hago |
|---|---|
| Gastó la mitad del precio sin vender | Se apaga ese conjunto |
| 4 ventas cobradas o más y cobrado mayor al doble del gasto | Es ganador: se renueva y se escala |
| A los 4 días el país gastó y no vendió | Se apaga el país |

## Los nombres
| Qué | Cómo se llama | Ejemplo |
|---|---|---|
| Campaña madre | País y tipo. Sin fecha | «PAÍS prueba» |
| Conjunto | Letra y número + fecha de salida (día-mes) | «A1 6-11» |
| Anuncio | Igual que su conjunto | «A1 6-11» |
| Archivo del anuncio | Idioma, país, número, tema y formato | «IDIOMA País - ANUNCIO 1 [TEMA - IMAGEN]» |

La fecha es el día en que el conjunto **empieza a gastar**, no el día en que lo armé.

## Por qué la fecha en el nombre
- La campaña madre junta tandas de muchos días. La fecha deja ver de cuál es cada conjunto.
- Los nombres viajan en las [[etiquetas-de-seguimiento]]. Si el nombre dice la tanda, la tienda me dice qué tanda vendió.

## Lo que aprendí
- Salí una vez con una campaña única con los mejores anuncios de todos los países. Gastó sin vender. Volví a esta estructura.
- La campaña de prueba no se frena entera: se analiza y se corta conjunto por conjunto.
- Antes de un cambio en muchos conjuntos, lo pruebo en UNO y miro cómo quedó.
- Nunca «publicar todo». Se tilda uno por uno, solo lo propio.
- Al duplicar un anuncio de otro país, reviso destino, idioma y píxel. Traen el enlace del país viejo.
- El enlace de destino se verifica antes de publicar: que sea el del país correcto.

Ver también: [[lista-antes-de-prender-una-campana]] · [[renovar-un-anuncio-ganador]] · [[decisiones-de-ejemplo]]
