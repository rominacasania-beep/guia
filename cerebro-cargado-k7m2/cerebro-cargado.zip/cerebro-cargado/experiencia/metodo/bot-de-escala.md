# El bot de escala

Es Claude mirando mis conjuntos cada media hora y subiendo el presupuesto **solo** cuando uno vende, dentro de la hora en que compra ese país. A la noche deja todo como estaba. Yo no estoy despierta a las 4 de la mañana; el bot sí.

Antes lo hacía a mano y llegaba tarde: la venta entraba, yo la veía dos horas después y la franja ya había pasado.

## Antes de instalarlo
| Tenés que tener | Por qué |
|---|---|
| Una campaña de prueba con presupuesto por conjunto | El bot trabaja conjunto por conjunto |
| Al menos un ganador: 4 ventas cobradas o más y cobrado mayor al doble del gasto | Sin ganador no hay nada que escalar |
| [[etiquetas-de-seguimiento]] en todos los anuncios | Así sabe qué conjunto vendió |
| Claude con acceso a Meta Ads y a tu tienda | Lee el gasto en uno y lo cobrado en la otra |
| La compu prendida y Claude abierto en las horas en que escala | Si está cerrado, no corre |

Si todavía no tenés ganador, esto no es para hoy. Seguí con [[estructura-y-nombres-de-campana]].

## Los cuatro estados
Cada país, a cada hora, está en uno de estos estados.

| Estado | Cuándo sube | Cuánto |
|---|---|---|
| 🔴 Agresivo | 1 venta nueva cobrada y lo cobrado es el doble del gasto o más | ×2 |
| 🟡 Normal | 2 ventas nuevas cobradas y lo cobrado es el doble del gasto o más | ×2 |
| 🟠 Exigente | 2 ventas nuevas cobradas y lo cobrado es 2,5 veces el gasto o más | ×2 |
| ⚪ Apagado | No sube nada. Si quedó alto, vuelve a la base | — |

«Venta nueva» es la que entró después de la última subida de ese conjunto.

## Qué estado va a cada hora
- **Si todavía no tenés dos semanas de ventas en el país:** de 00 a 03 Apagado y el resto Normal. Es prudente y alcanza para empezar.
- **Cuando ya tenés dos semanas:** Claude divide lo cobrado por lo gastado en cada franja de 4 horas. La franja que más devuelve es Agresivo, la que sigue Normal, la floja Exigente y la que pierde, Apagado.
- La franja se elige por **cuánto devuelve**, no por cuántas ventas tiene. A mí me pasó que la hora con más ventas era también la que más gastaba, y perdía.
- Las franjas se vuelven a calcular cada tanto: se mueven.

## El freno
| Pasa esto desde la última subida | El bot hace |
|---|---|
| Gastó lo que te cuesta una venta y no vendió | Baja un escalón |
| Gastó eso mismo y lo cobrado no llega a 1,5 veces el gasto, aunque venda | Baja un escalón |
| Sigue sin vender | Baja otro, hasta la base |

Nunca baja de la base. La base es el presupuesto que tenía el conjunto antes de que el bot lo tocara.

## El cierre
A las 23:00 todo vuelve a la base. Al otro día arranca de cero.

## Lo que lo cuida
| Cuidado | Por qué |
|---|---|
| Una subida por conjunto por hora, como mucho | Para ver qué pasó antes de volver a subir |
| Tope por conjunto, que elegís vos al instalar | No se improvisa a la madrugada |
| Meta informa el gasto con media hora de atraso | Por eso exige el doble y no menos. Si Meta todavía no muestra gasto, no sube |
| Primero frena y cierra, después sube | La plata se cuida antes de arriesgarla |
| Después de cada cambio vuelve a leer el conjunto | A veces queda en pausa solo: lo reactiva |
| Si Meta rechaza un cambio, lo anota y prueba en la vuelta siguiente | No insiste en el momento |
| Manda la tienda, no el píxel | Si la tienda cobró y Meta no lo muestra, la venta existe |

## Lo que nunca hace
- No prende, no apaga y no crea campañas, conjuntos ni anuncios.
- No toca campañas con presupuesto por campaña. Esas se miran aparte.
- No toca ningún conjunto que no esté en la lista que aprobaste.
- No deja un conjunto por debajo de su base.

## El día de prueba
El primer día el bot **no toca nada**: solo anota lo que hubiera hecho. Al otro día leés ese parte con Claude. Si te cierra, le decís «pasalo a real». Sin esa frase, sigue en prueba.

## Cómo se instala
Con el pedido de [[pedido-instalar-el-bot-de-escala]]. Claude te hace cuatro preguntas, te muestra la lista de conjuntos y el tope, y recién ahí lo programa.

## Cómo lo ves, lo pausás y lo sacás
| Querés | Le decís a Claude |
|---|---|
| Ver qué hizo | «Mostrame el parte del bot de escala» |
| Pausarlo hoy | «Pausá el bot de escala hasta mañana» |
| Cambiar el tope o la lista | «Cambiá el tope del bot» / «Sumá este conjunto al bot» |
| Sacarlo | «Desinstalá el bot de escala y dejá todos los presupuestos en su base» |

## Importante
Este es el único lugar del método donde Claude cambia presupuestos sin preguntarte cada vez. Por eso tiene lista cerrada, tope, día de prueba y cierre a las 23. Escalar es poner más plata en lo que ya vendió, y esa plata se puede perder. Así lo hago yo; no te garantiza un resultado.

Ver también: [[escalar-por-la-hora-en-que-compra-cada-pais]] · [[cobros]] · [[rutina-bot-de-escala]] · [[lecciones]]
