# El bot de escala

Es Claude mirando mis conjuntos cada media hora y subiendo el presupuesto **solo** cuando uno vende, dentro de la hora en que compra ese país. A las 23 vuelve todo a su presupuesto de siempre.

**Antes que nada:** escalar es poner más plata en lo que ya vendió, y esa plata se puede perder. Así lo hago yo; no te garantiza un resultado.

Antes lo hacía a mano y llegaba tarde: la venta entraba, yo la veía dos horas después y la franja ya había pasado.

## Seis palabras
| Palabra | Qué es |
|---|---|
| Conjunto | Un grupo de anuncios dentro de una campaña. En este método, cada conjunto tiene un solo anuncio |
| Presupuesto diario | Lo máximo que Meta gasta por día en ese conjunto |
| Base | El presupuesto diario que vos le pusiste. El bot vuelve siempre ahí |
| Escalón | Cada subida. De 7 a 14 es un escalón; de 14 a 28, otro |
| Tope | El presupuesto diario más alto al que el bot puede llegar en un conjunto |
| Cuánto devuelve | Lo cobrado en la tienda dividido lo gastado en anuncios. 2 quiere decir que por cada dólar volvieron 2 |

## Antes de instalarlo
| Tenés que tener | Por qué |
|---|---|
| Una campaña de prueba donde cada conjunto tiene su propio presupuesto | El bot trabaja conjunto por conjunto |
| Al menos un ganador: 4 ventas cobradas o más y cobrado mayor al doble del gasto | Sin ganador no hay nada que escalar |
| [[etiquetas-de-seguimiento]] en todos los anuncios, y una tienda que muestre las ventas por etiqueta | Así sabe qué conjunto vendió. Sin esto no se instala |
| Claude con la llave de Meta Ads y la de tu tienda (paso 0.7 de la guía) | Lee el gasto en uno y lo cobrado en la otra |
| La compu prendida y la app de Claude abierta en las horas en que escala | Si está cerrada, no corre |
| Lugar en tu plan de Claude | Corre unas 40 veces por día. Si tu plan viene justo, pedí que corra cada hora |

Si todavía no tenés ganador, esto no es para hoy. Seguí con [[estructura-y-nombres-de-campana]].

## Los cuatro estados
Cada país, a cada hora, está en uno de estos estados.

| Estado | Para qué franja | Cuándo sube | Cuánto |
|---|---|---|---|
| 🟢 Agresivo | La que más devuelve | 1 venta nueva cobrada y devuelve 2 o más | El doble |
| 🟡 Normal | Una buena | 2 ventas nuevas cobradas y devuelve 2 o más | El doble |
| 🟠 Exigente | Una floja | 2 ventas nuevas cobradas y devuelve 2,5 o más | El doble |
| ⚪ Apagado | La que pierde | No sube nada. Si quedó alto, vuelve a la base | — |

«Venta nueva» es la que entró después de la última subida de ese conjunto. «El doble» es el doble del presupuesto que tiene en ese momento.

## Qué estado va a cada hora
El día se parte en bloques: 00–03, 03–07, 07–12, 12–16, 16–20 y 20–23, en tu hora.

- **De 00 a 03, siempre Apagado.** A mí ahí me perdió en todos los países.
- **Con menos de dos semanas de ventas en el país:** el resto del día en Normal.
- **Con dos semanas o más,** Claude divide lo cobrado por lo gastado en cada bloque:

| El bloque, en dos semanas | Estado |
|---|---|
| Tuvo menos de 5 ventas | 🟡 Normal (no hay dato para decidir) |
| Devuelve menos de 1,5 | ⚪ Apagado |
| Devuelve entre 1,5 y 2 | 🟠 Exigente |
| Devuelve 2 o más | 🟡 Normal |
| Es el que más devuelve, y pasa de 2 | 🟢 Agresivo |

El bloque se elige por **cuánto devuelve**, no por cuántas ventas tiene. A mí me pasó que la hora con más ventas era también la que más gastaba, y perdía. Y las franjas se mueven: se recalculan una vez por semana.

## El freno
| Pasa esto desde la última subida | El bot hace |
|---|---|
| Gastó lo que te cuesta una venta y no vendió | Baja un escalón |
| Gastó eso mismo y devuelve menos de 1,5, aunque venda | Baja un escalón |
| Vuelve a gastar lo que cuesta una venta sin vender | Baja otro, hasta la base |

El bot no baja de la base. La base es el presupuesto que tenía el conjunto el día que lo instalaste.

## El cierre
A las 23:00 todo vuelve a la base. Al otro día arranca de cero. Si a las 23 la compu estaba apagada, lo primero que hace al volver a correr es bajar lo que quedó alto.

## Un día de ejemplo
Conjunto de Italia, base 7, tope 28.

| Hora | Pasa | El bot |
|---|---|---|
| 05:00 | 2 ventas cobradas, 36 cobrados, 4 gastados | Sube a 14 |
| 06:30 | Gastó 10 más y no vendió | Vuelve a 7 |
| 23:00 | Cierre | Todo en 7 |

## Lo máximo que puede gastar
Tope × cantidad de conjuntos en la lista. Con tope 28 y 3 conjuntos, lo máximo en un día es 84. Si esa cifra te asusta, bajá el tope antes de instalar.

## Los cuidados que tiene
| Cuidado | Por qué |
|---|---|
| Una subida por conjunto por hora, como mucho | Para ver qué pasó antes de volver a subir |
| Tope por conjunto, que elegís vos al instalar | No se improvisa a la madrugada |
| Meta informa el gasto con media hora de atraso | Por eso exige el doble y no menos. Si Meta todavía no muestra gasto, no sube |
| Primero cierra y frena, después sube | La plata se cuida antes de arriesgarla |
| Una venta sin etiqueta no alcanza para subir | No se sabe de qué conjunto vino. Queda anotada en el parte |
| Si cambiaste un presupuesto a mano, ese día no toca ese conjunto | Te pregunta si esa es la base nueva |
| Si un conjunto queda en pausa por el cambio, lo reactiva. Si lo pausaste vos, no lo toca | El bot no prende lo que vos apagaste |
| Si Meta rechaza un cambio, lo anota y prueba en la vuelta siguiente | No insiste en el momento |
| No renombres un conjunto que está en la lista | La venta se reconoce por el nombre que viaja en la etiqueta |
| Manda la tienda, no el píxel | Si la tienda cobró y Meta no lo muestra, la venta existe |

Son cuidados, no un seguro: un conjunto puede subir y dejar de vender.

## Lo que nunca hace
- No prende, no apaga y no crea campañas, conjuntos ni anuncios.
- No toca campañas donde el presupuesto es de la campaña entera. Esas se miran aparte.
- No toca ningún conjunto que no esté en la lista que aprobaste.
- No pasa el tope ni baja de la base.

## El día de prueba
El primer día el bot **no toca nada**: anota lo que hubiera hecho, como si lo hubiera hecho. Al otro día leés ese parte con Claude. Si te cierra, le decís «pasalo a real». Sin esa frase, sigue en prueba.

En prueba los frenos se ven de menos: como el presupuesto no subió de verdad, el conjunto gasta menos de lo que hubiera gastado.

## Cómo se instala
Con el pedido de [[pedido-instalar-el-bot-de-escala]]. Claude revisa tus llaves, te muestra tus ganadores, te hace cuatro preguntas y recién ahí deja la tarea programada (una tarea es un pedido que Claude repite solo, a la hora que le digas).

## Cómo lo ves, lo pausás y lo sacás
El «parte» es la nota donde el bot escribe qué hizo en cada vuelta.

| Querés | Le decís a Claude |
|---|---|
| Ver qué hizo | «Mostrame el parte del bot de escala» |
| Pausarlo hoy | «Pausá el bot de escala hasta mañana» (antes baja todo a la base) |
| Cambiar el tope o la lista | «Cambiá el tope del bot» / «Sumá este conjunto al bot» |
| Sacarlo | «Desinstalá el bot de escala y dejá todos los presupuestos en su base» |

## Importante
Este es el único lugar del método donde Claude cambia presupuestos sin preguntarte cada vez. En el resto del método se sube de a poco y con tu OK; acá se duplica, pero solo dentro de la franja, con una venta nueva cobrada, hasta el tope, y a las 23 vuelve a la base. Por eso tiene lista cerrada, tope, día de prueba y cierre.

Ver también: [[escalar-por-la-hora-en-que-compra-cada-pais]] · [[cobros]] · [[rutina-bot-de-escala]] · [[lecciones]]
