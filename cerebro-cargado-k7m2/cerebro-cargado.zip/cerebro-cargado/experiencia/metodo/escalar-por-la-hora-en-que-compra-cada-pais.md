# Escalar por la hora en que compra cada país

Cada país compra a su hora. Yo tenía un horario único para subir presupuesto y se pisaba: subía un país justo cuando no compraba. Ahora cada país tiene su franja.

## La idea
| Antes | Ahora |
|---|---|
| Un horario único para todos | Una franja por país |
| Subía mirando el panel de anuncios | Subo mirando lo cobrado en la tienda |
| El presupuesto quedaba alto | Al cerrar la franja vuelve a la base |

## Cómo encuentro la franja de un país
1. Bajo las ventas cobradas de la tienda de ese país, con su hora.
2. Paso todo a MI hora. Siempre la misma para todos los países.
3. Miro en qué horas se juntan las ventas. Esa es la franja.
4. Lo vuelvo a mirar cada tanto: las franjas se mueven.

## Qué se puede escalar
| Condición | Detalle |
|---|---|
| Es un ganador | 4 ventas cobradas o más y cobrado mayor al doble del gasto |
| Vendió hoy | Si hoy no vendió, no se escala. Aunque la semana se vea linda |
| Viene vendiendo | Miro hoy y los 4 días anteriores, en la tienda |
| Estoy dentro de su franja | Fuera de la franja no se sube |

## Cómo se sube
- Se sube el conjunto que vendió, no la campaña entera.
- Se sube por pasos, cuando entra una venta nueva cobrada y lo cobrado sigue arriba del doble del gasto.
- Hay un tope fijado de antemano. No se improvisa a la madrugada.
- Al cerrar la franja, el presupuesto vuelve a la base.
- Si un país no tiene ganador hoy, ese día no se escala.

## Quién manda
**Manda la tienda, no el píxel.** Si la tienda cobró y Meta no lo muestra, la venta existe igual. Para saber qué conjunto vendió uso las [[etiquetas-de-seguimiento]].

## Cuidados
- Después de cambiar un presupuesto, el conjunto puede quedar en pausa sin avisar. Se reactiva y se vuelve a leer el estado.
- La hora se confirma con una segunda fuente antes de decidir algo por horario. Una vez se leyó mal y se cerraron países antes de tiempo.
- La campaña de prueba no se toca: se mira conjunto por conjunto.
- Claude puede vigilar y subir o bajar con estas reglas y avisarme. Prender una campaña nueva sigue necesitando mi OK.

## Para no hacerlo a mano
Todo esto lo puede hacer Claude solo, cada media hora, con el [[bot-de-escala]]. Se instala con el [[pedido-instalar-el-bot-de-escala]].

Ver también: [[lecciones]] · [[rutina-diaria]] · [[cobros]]
