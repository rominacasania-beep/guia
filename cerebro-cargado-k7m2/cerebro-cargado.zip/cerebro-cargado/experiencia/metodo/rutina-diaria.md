# Mi rutina diaria

Lo que se hace todos los días, en orden. Casi todo lo hace Claude con tareas programadas. Yo miro, decido y doy el OK.

## El día
| Momento | Qué se hace | Dónde está explicado |
|---|---|---|
| Mañana | Mirar lo **cobrado** de ayer, tienda por tienda. Incluye las tiendas archivadas | [[cobros]] |
| Mañana | Leer los avisos de mails: carritos, pagos fallados, cupones por vencer | [[recuperar-carritos-y-pagos-fallados]] |
| Mañana (a las 9) | Renovaciones de cada ganador y anuncios nuevos de prueba, en la carpeta del día | [[renovar-un-anuncio-ganador]] |
| Mañana | Cortar lo que gastó la mitad del precio sin vender | [[estructura-y-nombres-de-campana]] |
| Durante el día | Escalar solo dentro de la franja de cada país, y solo lo que vendió hoy | [[escalar-por-la-hora-en-que-compra-cada-pais]] |
| Tarde | Dejar programado lo nuevo para las 00:00 | [[salida-a-las-00]] |
| Noche | Anotar lo decidido y lo aprendido | `decisiones.md` y `lecciones.md` |

## La semana
| Cuándo | Qué |
|---|---|
| Lunes | Limpiar de la compu los anuncios que ya están subidos |
| Cada país nuevo, día 4 | Si gastó y no vendió, se apaga. Ver [[paises-apagados]] |
| Cada cambio en la tienda | Se mide una semana y se anota el resultado |

## Reglas de fondo
- **Lo cobrado manda.** El número del día sale de la tienda, no del panel de anuncios.
- **Una sola hora para todo:** la mía. Días, reportes y programaciones.
- **Lo prendido queda prendido.** Si un cambio pausa algo, se vuelve a prender y se revisa.
- **Verificar antes de afirmar.** Antes de decir «falta» o «no funciona», se mira en el panel. Si no se puede ver, se dice «no lo puedo ver».
- **Gastar y publicar los decido yo.** Claude prepara todo y espera mi OK.
- **No consultar la tienda a cada rato.** Las lecturas se espacian.

## Cómo le hablo a Claude
Yo soy visual. Le pido tablas, semáforos y poco texto. Y que cada error quede escrito como regla, con fecha y motivo, para no repetirlo.

Ver también: [[lecciones]] · [[indice]]
