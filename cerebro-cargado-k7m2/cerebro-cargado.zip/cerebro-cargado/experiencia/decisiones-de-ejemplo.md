# 8 decisiones, con lo que pasó

Así se llena tu `decisiones.md`: qué decidiste, por qué, qué esperabas y qué pasó. Estas son mías, para que veas el molde.

## 1 · Vender en ruso sin tocar Rusia
- **Qué decidí:** apuntar a personas que hablan ruso en países chicos.
- **Por qué:** era un idioma con poca competencia y el producto ya estaba probado.
- **Qué esperaba:** un público desatendido y barato.
- **Qué pasó:** el público era diminuto. Las mismas personas veían el anuncio repetido, algunas llegaron al pago y nadie compró. Lo apagué a los pocos días. → [[ruso-en-el-baltico]]

## 2 · Reusar la tienda de un país apagado
- **Qué decidí:** usar esa tienda para el país siguiente en vez de pagar un lugar más.
- **Por qué:** el plan tenía tope de tiendas y los cobros ya estaban conectados.
- **Qué esperaba:** ahorrar tiempo y plata.
- **Qué pasó:** salió en el día, pero aparecieron restos del idioma anterior en lugares que nadie mira. Ahora hay una lista. → [[lista-al-reusar-una-tienda]]

## 3 · Abrir un país porque a otras les iba bien
- **Qué decidí:** entrar por referencias ajenas.
- **Por qué:** buenas referencias y ningún dato propio en contra.
- **Qué esperaba:** ventas desde la primera noche.
- **Qué pasó:** pocas ventas, pocas visitantes pasaban al pago, y lo cerré a los pocos días. Lo que le funciona a otra no garantiza nada. → [[portugal]]

## 4 · No bajar el presupuesto del país que perdía
- **Qué decidí:** buscar la causa antes de recortar.
- **Por qué:** tenía visitas y ventas; algo en el medio fallaba.
- **Qué esperaba:** encontrar dónde se trababa.
- **Qué pasó:** la oferta de después del pago mostraba el precio vacío y nadie la aceptaba. Se arregló; el resultado todavía se está midiendo. → [[francia]]

## 5 · Salir con una campaña única
- **Qué decidí:** lanzar un país nuevo con una sola campaña con los mejores anuncios de todos los países.
- **Por qué:** quería probar una estructura más simple.
- **Qué esperaba:** que encontrara sola al ganador.
- **Qué pasó:** gastó sin ventas. La pausé y volví a la estructura de siempre: varios conjuntos chicos, un anuncio cada uno. → [[grecia-y-chipre]]

## 6 · Lanzar sin la clave de conversiones
- **Qué decidí:** «después la cargo».
- **Por qué:** todo lo demás estaba listo.
- **Qué esperaba:** que el píxel del navegador alcanzara.
- **Qué pasó:** entraron ventas reales y Meta mostraba cero. La cargué al mediodía y empezó a registrar. Ahora va antes de prender. → [[hungria]]

## 7 · Llevar a todas las tiendas el complemento que más se aceptaba
- **Qué decidí:** copiar a todos los países el extra de checkout que mejor funcionaba en uno.
- **Por qué:** ahí se lo llevaba una gran parte de las compradoras.
- **Qué esperaba:** que cada venta dejara más en todos lados.
- **Qué pasó:** quedó cargado reemplazando al más flojo de cada tienda. La medición está en curso. → [[israel]]

## 8 · Probar un «truco» para liberar plata retenida
- **Qué decidí:** probarlo con un solo pago antes de hacerlo con todos.
- **Por qué:** cada intento le manda un mail a la compradora.
- **Qué esperaba:** que la plata se liberara en una semana.
- **Qué pasó:** no adelantó nada. Me ahorré molestar a decenas de clientas. → [[cobros]]
