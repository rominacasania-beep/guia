# Lista al apagar un país

La regla: si a los 4 días gastó y no vendió, se apaga. El orden importa.

## 1 · Primero los anuncios
- [ ] Pausar todas las campañas del país
- [ ] Mirar en **todas** las cuentas publicitarias: que no quede ninguna campaña suelta
- [ ] Volver a leer el estado: nada gastando

## 2 · Después la tienda
- [ ] Archivar la tienda
- [ ] Al otro día, confirmar que no entró gasto ni venta nueva
- [ ] Recordar: una tienda archivada puede seguir vendiendo si quedó un anuncio vivo. Y el resumen de ventas puede no contarla

## 3 · Los mails
- [ ] Apagar los flujos de carrito y de pago fallado de esa tienda
- [ ] Limpiar sus contactos, para no gastar lugar del plan

## 4 · Lo que se guarda
- [ ] La guía de estilo del idioma, aunque el país se apague
- [ ] Los PDF traducidos y las portadas
- [ ] La página de Facebook, anotada como «libre para reusar» → [[reusar-una-pagina-de-facebook]]
- [ ] La tienda, anotada como «libre para reusar» → [[lista-al-reusar-una-tienda]]

## 5 · Anotarlo
En [[paises-apagados]], una fila:

| País | Por qué lo apagué | Qué haría distinto |
|---|---|---|
| | | |

Y en `decisiones.md`: qué decidí, por qué, qué esperaba y qué pasó.

## Antes de apagar, una sola pregunta
¿Recorrí el camino entero como si fuera la compradora? A veces el problema es una pantalla rota y no el país. Ver [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]].

Ver también: [[portugal]] · [[lecciones]]
