# Lista al apagar un país

Se apaga si a los 4 días gastó y no vendió, o si vende pero pasa dos semanas en empate. Apagar es apagar **todo**: si queda algo prendido, sigue mandando gente a una tienda cerrada. El orden importa.

## 1 · Primero los anuncios
- [ ] Pausar todas las campañas del país
- [ ] Mirar en **todas** las cuentas publicitarias: que no quede ninguna campaña suelta
- [ ] Volver a leer el estado: nada gastando

## 2 · Antes de archivar, las compradoras
- [ ] Mandarles un mail con el acceso a lo que compraron, para que no lo pierdan cuando la tienda se cierre
- [ ] Incluir a las que compraron en los últimos días
- [ ] Si la entrega tiene enlaces a la tienda (botones de «comprar lo que te falta»), saber que van a quedar muertos

## 3 · Después la tienda
- [ ] Archivar la tienda
- [ ] Al otro día, confirmar que no entró gasto ni venta nueva
- [ ] Recordar: una tienda archivada puede seguir vendiendo si quedó un anuncio vivo. Y el resumen de ventas puede no contarla

## 4 · Los mails
- [ ] **Desactivar** (no pausar) los mails automáticos de carrito abandonado y de pago fallado de esa tienda. Pausar deja terminar a las que ya estaban adentro, y les llega un enlace a una tienda cerrada
- [ ] Sacar el país de cualquier reporte o rutina que lo mire
- [ ] Ya avisadas las compradoras, borrar sus contactos para no gastar lugar del plan

## 5 · Lo que se guarda
- [ ] La guía de estilo del idioma, aunque el país se apague
- [ ] Los PDF traducidos y las portadas
- [ ] La página de Facebook, anotada como «libre para reusar» → [[reusar-una-pagina-de-facebook]]
- [ ] La tienda, anotada como «libre para reusar» → [[lista-al-reusar-una-tienda]]

## 6 · Anotarlo
En [[paises-apagados]], una fila:

| País | Por qué lo apagué | Qué haría distinto |
|---|---|---|
| | | |

Y en `decisiones.md`: qué decidí, por qué, qué esperaba y qué pasó.

## Antes de apagar, una sola pregunta
¿Recorrí el camino entero como si fuera la compradora? A veces el problema es una pantalla rota y no el país. Ver [[extra-de-checkout-y-ofertas-de-despues-de-la-compra]].

Ver también: [[portugal]] · [[lecciones]]
