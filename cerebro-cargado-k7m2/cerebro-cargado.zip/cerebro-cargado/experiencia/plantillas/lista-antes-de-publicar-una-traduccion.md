# Lista antes de publicar una traducción

Vale para la web, el checkout, los PDF, los mails y los anuncios.

## Antes de traducir
- [ ] Hay guía de estilo del idioma, hecha con fuentes del país → [[reglas-comunes-a-todos-los-idiomas]]
- [ ] Está elegido el trato (el «tú» del idioma) y el género
- [ ] Hay glosario: una palabra para cada cosa
- [ ] Está decidido el primer día de la semana y el formato de fecha
- [ ] La tipografía tiene todas las letras del idioma

## El texto
- [ ] Un solo trato de punta a punta
- [ ] Las mismas palabras en la web, el checkout y el PDF
- [ ] Mayúscula solo en la primera palabra de cada título
- [ ] Comillas y signos del idioma
- [ ] Sin signos de exclamación ni urgencia
- [ ] Ninguna frase le dice a la lectora lo que «tiene»
- [ ] Ninguna promesa de cura
- [ ] Cada frase hecha, buscada en un diccionario del idioma
- [ ] Moneda, decimales y fechas como se usan allá
- [ ] Sin referencias de mi país

## Los PDF
- [ ] Control automático contra el original: cero palabras del idioma viejo
- [ ] Del control se sacaron las palabras que existen en los dos idiomas
- [ ] Mirado página por página: nada pisado, nada fuera de su caja
- [ ] Sin mi nombre, mi marca, mis fotos ni mi usuario
- [ ] Calendarios con la semana del país
- [ ] Alineación correcta si el idioma va de derecha a izquierda
- [ ] El archivo no pesa de más

## Las imágenes
- [ ] Cada imagen con texto, leída a tamaño real, letra por letra
- [ ] Mayúsculas y acentos como manda el idioma
- [ ] Colores, números y símbolos que no choquen en el país

## La tienda
- [ ] Vista previa del país: botones, rótulos, extras y título de la pestaña → [[revisar-el-checkout-como-otro-pais]]
- [ ] Ofertas de después, página de gracias y mails
- [ ] Web mirada en el celular: sin deslizamiento al costado, sin imágenes rotas

## Revisión
- [ ] Dos pasadas en limpio → [[pedido-revision-nativa-en-dos-pasadas]]
- [ ] Queda escrito: «revisado con IA, falta una persona nativa»
- [ ] Si conseguís a alguien del país, que lea al menos la web y el checkout

Ver también: [[lecciones]] · [[llevar-un-producto-a-otro-idioma]]
