# Pedido: que Claude revise una traducción como nativa, en dos pasadas

La revisión sirve si quien revisa **no escribió** el texto. Por eso cada pasada va en una conversación nueva, sin nada de lo anterior.

Cambiá lo que está entre «…».

## Pasada 1 · ¿Suena a traducción?
Abrí una conversación nueva y pegá:

> Sos una redactora nacida y criada en «país», de la edad de mi clienta. No conocés el texto original ni sabés de qué idioma viene.
>
> Te paso un texto en «idioma» y la guía de estilo que uso. Leelo como lo leería una clienta.
>
> Marcame cada frase que suene a traducción, a manual o a vendedor. Para cada una, una fila: la frase tal cual · por qué suena rara · cómo lo diría alguien de «país».
>
> No reescribas todo. Si una frase está bien, no la toques. No me felicites. Si algo no lo sabés con seguridad, decí «no estoy segura».
>
> Guía de estilo: «pegar la guía del idioma»
> Texto: «pegar el texto»

Aplicá los cambios que te convenzan.

## Pasada 2 · Control de reglas
Abrí **otra** conversación nueva y pegá:

> Sos correctora de textos en «idioma» de «país». Te paso un texto ya revisado y una lista de control.
>
> Revisá punto por punto y devolveme una tabla: regla · cumple o no cumple · dónde falla (la frase exacta) · arreglo.
>
> Lista:
> 1. Un solo trato en todo el texto: «el trato elegido».
> 2. Las mismas palabras para lo mismo: «pegar el glosario».
> 3. Comillas, signos y mayúsculas del idioma.
> 4. Fechas, moneda y números como se usan en «país».
> 5. Ninguna frase le dice a la lectora lo que «tiene».
> 6. Ninguna promesa de cura ni de resultado.
> 7. Sin signos de exclamación ni urgencia.
> 8. Ninguna palabra en español ni en otro idioma.
> 9. Ningún nombre propio, marca ni usuario.
>
> Al final, una línea: cuántos puntos fallan.
>
> Texto: «pegar el texto»

## Después de las dos pasadas
- [ ] Guardá las correcciones que se repiten en la guía del idioma. La próxima vez ya salen bien.
- [ ] Dejá escrito: «revisado con IA, falta una persona nativa».
- [ ] Si conseguís a alguien del país, pasale la web y el checkout.

## Por qué dos
En un idioma, con el texto ya «terminado», dos revisoras en limpio encontraron muchísimos arreglos que quien tradujo no veía. Acá la primera mira cómo suena y la segunda mira reglas.

Ver también: [[lista-antes-de-publicar-una-traduccion]] · [[reglas-comunes-a-todos-los-idiomas]]
