# Pedido: las renovaciones del día

Para sacarle variantes a un anuncio que ya gana. Primero leé [[renovar-un-anuncio-ganador]].

Cambiá lo que está entre «…».

> Tengo un anuncio ganador en «país». Te paso la imagen (o el guion), el texto y la foto real de mi producto.
>
> Armame tres renovaciones. Cada una es el MISMO anuncio con un solo cambio:
> - R1: mismo estilo visual, otro gancho.
> - R2: misma promesa, otro estilo visual.
> - R3: un estilo bien distinto de los dos anteriores.
>
> Reglas:
> - El producto es exactamente el de la foto. No inventes otro. El título de la tapa se copia letra por letra.
> - Cada una toca un dolor concreto, contado como escena o en primera persona.
> - No le digas a la persona lo que «tiene». No prometas cura ni resultado.
> - Texto en «idioma», con esta guía: «pegar la guía del idioma».
> - Dame el texto en el idioma y al lado en español, para que yo lo pueda leer.
> - Nombre de cada archivo: «IDIOMA País - RENOVACIÓN número [TEMA - IMAGEN o VIDEO]».
>
> Antes de darme algo por terminado, leé cada imagen a tamaño real, letra por letra. Si hay un error, generala de nuevo desde cero.

## Después
- [ ] Guardar en Anuncios › Renovaciones › «fecha PAÍS».
- [ ] Anotar qué estilo usó cada una, para no repetir mañana.
- [ ] Subir sin renombrar los archivos.
- [ ] Cada una sale en un conjunto nuevo, con fecha, a las 00:00 → [[lista-antes-de-prender-una-campana]].

Ver también: [[estructura-y-nombres-de-campana]] · [[rutina-diaria]]
