# Pedido: instalar el bot de escala

Primero leé [[bot-de-escala]]. Si todavía no tenés un ganador, no lo instales.

Copiá esto y pegáselo a Claude, tal cual:

> Quiero instalar el bot de escala. Leé `experiencia/metodo/bot-de-escala.md` y `experiencia/plantillas/rutina-bot-de-escala.md` de mi cerebro y seguí estos pasos. Hablame simple, no sé programar.
>
> 1. **Comprobá, solo leyendo:** que podés leer mis campañas en Meta Ads, que podés leer lo cobrado en mi tienda **separado por etiqueta de conjunto**, y que tenés una herramienta para crear tareas programadas (no crees ninguna todavía). Mostrame una tabla con ✅ o ❌. Si falta la llave de Meta Ads o la de la tienda, mandame al paso 0.7 de la guía. Si mi tienda no te deja ver las ventas por etiqueta, frená: sin eso el bot no se instala. Decime también la zona horaria de mi cuenta publicitaria y la de mi tienda, y avisame si no coinciden con la mía.
> 2. **Buscá mis ganadores:** conjuntos con presupuesto propio, activos, con 4 ventas cobradas o más y lo cobrado mayor al doble del gasto en los últimos 7 días, y con venta hoy o ayer. Mostrámelos en una tabla con su presupuesto de hoy. Si no hay ninguno, decímelo y no instales nada.
> 3. **Preguntame en un solo mensaje:** cuáles de esos conjuntos entran; el tope por conjunto (proponeme cuatro veces la base y decime cuánto es lo máximo que podría gastar en un día: tope × cantidad de conjuntos); y en qué ciudad vivo, para saber mi zona horaria. La base de cada conjunto es el presupuesto que tiene hoy. El costo por venta de cada país calculalo vos: gasto del país en 7 días ÷ ventas cobradas del país en esos 7 días, y mostrámelo.
> 4. **Armá las franjas de cada país** con la tabla de la nota («Qué estado va a cada hora»). Mostrámelas en una tabla con colores.
> 5. **Creá la carpeta `bot-de-escala` en mi cerebro** con `config.md`, `estado.json` y `parte.md`, con el formato exacto que está al final de `rutina-bot-de-escala.md`. Modo: PRUEBA.
> 6. **Programá una sola tarea** «Bot de escala» que corra a las :00 y a las :30 de cada hora, de 03:00 a 23:30 de mi hora, con el texto de `rutina-bot-de-escala.md` (desde la línea que dice «Sos el bot de escala» hasta «Formato de los archivos», sin incluirlo) y la ruta real de mi cerebro. Si ya existe una tarea con ese nombre, no la pises: mostrámela.
> 7. **Arrancá en modo PRUEBA.** No cambies ningún presupuesto hasta que yo te diga «pasalo a real». Cuando te lo diga, cambiá el modo a REAL en `config.md` y vaciá `estado.json`.
> 8. **Sumá a mi `CLAUDE.md`** esta línea, mostrándomela antes: «Única excepción a "nunca cambiás un presupuesto sin mi OK": la tarea "Bot de escala", solo en modo REAL, solo en los conjuntos de `bot-de-escala/config.md` y solo entre su base y su tope.»
> 9. Al terminar explicame en pocas líneas cómo veo el parte, cómo lo pauso, cómo cambio el tope y cómo lo desinstalo. Decime que la primera vuelta en real puede frenarse pidiéndome permiso en la app, y que ese día la miremos juntas.
>
> No prendas, no apagues y no crees nada. No toques conjuntos fuera de la lista que yo apruebe.

## Al día siguiente
- [ ] Pedí «mostrame el parte del bot de escala».
- [ ] Mirá cada «hubiera subido» y cada «hubiera frenado». ¿Lo hubieras hecho vos?
- [ ] Si te cierra: «pasalo a real». Quedate cerca la primera vuelta, por si la app pide permiso.
- [ ] Si no: «cambiá esto» y otro día de prueba.

## Cada semana
- [ ] «Recalculá las franjas del bot con las últimas dos semanas.»
- [ ] Sacá de la lista el conjunto que dejó de ser ganador (lleva 4 días sin vender).

Ver también: [[bot-de-escala]] · [[rutina-bot-de-escala]] · [[escalar-por-la-hora-en-que-compra-cada-pais]]
