# Pedido: instalar el bot de escala

Primero leé [[bot-de-escala]]. Si todavía no tenés un ganador, no lo instales.

Copiá esto y pegáselo a Claude, tal cual:

> Quiero instalar el bot de escala. Leé `experiencia/metodo/bot-de-escala.md` y `experiencia/plantillas/rutina-bot-de-escala.md` de mi cerebro y seguí estos pasos. Hablame simple, no sé programar.
>
> 1. **Comprobá, solo leyendo:** que podés leer mis campañas en Meta Ads, que podés leer lo cobrado en mi tienda y que podés crear tareas programadas. Mostrame una tabla con ✅ o ❌. Si falta algo, frená y decime cómo conseguirlo.
> 2. **Buscá mis ganadores:** conjuntos con presupuesto propio, activos, con 4 ventas cobradas o más y lo cobrado mayor al doble del gasto en los últimos 7 días. Mostrámelos en una tabla con su presupuesto de hoy. Si no hay ninguno, decímelo y no instales nada.
> 3. **Preguntame en un solo mensaje:** cuáles de esos conjuntos entran, el tope por conjunto (proponeme cuatro veces la base), cuánto me cuesta una venta en cada país (si no lo sé, calculalo vos con los últimos 7 días) y cuál es mi hora.
> 4. **Armá las franjas de cada país** como dice la nota: si tengo menos de dos semanas de ventas, de 00 a 03 Apagado y el resto Normal. Si tengo más, calculalas por lo que devuelve cada franja de 4 horas. Mostrámelas en una tabla con colores.
> 5. **Creá la carpeta `bot-de-escala` en mi cerebro** con `config.md` (conjuntos, base, tope, costo por venta, franjas, modo PRUEBA), `estado.json` y `parte.md`.
> 6. **Programá la tarea** «Bot de escala» cada 30 minutos, de 03:00 a 23:05 de mi hora, con el texto de `rutina-bot-de-escala.md` y la ruta real de mi cerebro. Si ya existe una tarea con ese nombre, no la pises: mostrámela.
> 7. **Arrancá en modo PRUEBA.** No cambies ningún presupuesto hasta que yo te diga «pasalo a real».
> 8. Al terminar explicame en pocas líneas cómo veo el parte, cómo lo pauso, cómo cambio el tope y cómo lo desinstalo. Y avisame si la tarea necesita que le dé permiso en la app para poder cambiar presupuestos sola.
>
> No prendas, no apagues y no crees nada. No toques conjuntos fuera de la lista que yo apruebe.

## Al día siguiente
- [ ] Pedí «mostrame el parte del bot de escala».
- [ ] Mirá cada «hubiera subido» y cada «hubiera frenado». ¿Lo hubieras hecho vos?
- [ ] Si te cierra: «pasalo a real».
- [ ] Si no: «cambiá esto» y otro día de prueba.

## Cada semana
- [ ] «Recalculá las franjas del bot con las últimas dos semanas.»
- [ ] Sacá de la lista el conjunto que dejó de ser ganador.

Ver también: [[bot-de-escala]] · [[rutina-bot-de-escala]] · [[escalar-por-la-hora-en-que-compra-cada-pais]]
