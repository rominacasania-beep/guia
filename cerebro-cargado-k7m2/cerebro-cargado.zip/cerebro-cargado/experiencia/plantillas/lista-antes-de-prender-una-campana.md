# Lista antes de prender una campaña

Copiala y tildala. Si falta un tilde, no se prende.

## La tienda
- [ ] El entregable está cargado y abre **sin sesión iniciada**
- [ ] El precio del checkout real es el que pedí, en la moneda del país
- [ ] El checkout se ve bien con la vista previa del país → [[revisar-el-checkout-como-otro-pais]]
- [ ] Los cobros funcionan en esa moneda
- [ ] Los extras del checkout tienen archivo, portada y botón traducido
- [ ] Las ofertas de después muestran precio normal y ahorro
- [ ] El dominio abre con candado
- [ ] Si la tienda es nueva: una compra de prueba de punta a punta
- [ ] Al lado de cada precio y cada botón de compra dice «pago único, sin mensualidades» en el idioma del país
- [ ] El grabador de visitas carga y marca cada paso → [[ver-donde-se-va-la-gente]]

## El seguimiento
- [ ] El píxel es el del país, no el de otra tienda
- [ ] La clave de conversiones está cargada
- [ ] Se registró una visita de prueba en la web
- [ ] Cada anuncio lleva las [[etiquetas-de-seguimiento]]

## La página de Facebook
- [ ] Está sumada a la cuenta del negocio
- [ ] Está activa: no figura en la lista de páginas desactivadas
- [ ] Nombre, fotos y publicaciones del país. Sin restos de otro idioma

## La campaña
- [ ] 5 conjuntos, 1 anuncio por conjunto, 7 dólares por día
- [ ] Todos los países donde se habla el idioma, con el idioma como filtro. Sin edad ni género → [[segmentacion-abierta]]
- [ ] Hora de inicio: 00:00 del día siguiente, en mi hora → [[salida-a-las-00]]
- [ ] Nombres con la fecha de salida → [[estructura-y-nombres-de-campana]]
- [ ] Evento: compra
- [ ] Botón «Ver más» y destino la web del país correcto
- [ ] Si dupliqué anuncios de otro país: revisé destino, idioma y píxel de cada uno
- [ ] Si el país pide una declaración para anunciar, está hecha

## Los anuncios
- [ ] Muestran el producto real, con un dolor concreto
- [ ] Cada imagen leída a tamaño real, letra por letra
- [ ] Texto revisado con la guía del idioma
- [ ] Ninguno le dice a la persona lo que «tiene» ni promete cura

## Al publicar
- [ ] Tildé uno por uno, solo lo mío. Nunca «publicar todo»
- [ ] Después de activar, volví a leer el estado: activo y con la hora bien
- [ ] Si Claude hizo cambios desde la conexión con Meta, los publicó: un borrador no corre

Ver también: [[lecciones]] · [[llevar-un-producto-a-otro-idioma]]
