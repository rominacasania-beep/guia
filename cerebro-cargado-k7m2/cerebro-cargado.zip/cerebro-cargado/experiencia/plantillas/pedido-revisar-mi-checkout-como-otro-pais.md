# Pedido: que Claude revise mi checkout como si fuera de otro país

Usalo antes de prender un país y cada vez que cambies algo en la tienda.

Cambiá lo que está entre «…».

> Revisá el checkout de mi tienda de «país» como lo ve una compradora de allá, no como lo veo yo. Usá la vista previa por país del panel. Si no la podés abrir, decímelo: no supongas.
>
> Recorré todo el camino y devolveme una tabla: pantalla · qué viste · bien o mal · qué hay que cambiar.
>
> 1. Página de pago: nombre y descripción del producto, precio y moneda, botón de pagar, rótulos del resumen.
> 2. Extras del checkout: nombre, portada, botón y la fila de «llevar todos».
> 3. Título de la pestaña del navegador.
> 4. Ofertas de después del pago, una por una: ¿se ve el precio normal y el ahorro?
> 5. Página de gracias.
> 6. Mail de entrega y enlace del entregable, abierto sin sesión.
>
> Marcá cualquier palabra en un idioma que no sea «idioma».
> El precio tiene que ser «precio y moneda». Si ves otro, avisame primero.
> No cambies nada: solo mostrame. Yo decido.

## Qué hago con la respuesta
- [ ] Lo que está mal se arregla y se vuelve a mirar.
- [ ] Si algo no se pudo ver, lo miro yo en el panel.
- [ ] Si apareció un error nuevo, lo sumo a [[lecciones]].

Ver también: [[revisar-el-checkout-como-otro-pais]] · [[lista-antes-de-prender-una-campana]]
