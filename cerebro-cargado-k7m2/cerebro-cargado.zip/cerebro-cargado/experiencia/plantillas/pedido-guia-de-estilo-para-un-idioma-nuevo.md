# Pedido: que Claude arme la guía de estilo de un idioma nuevo

Para un idioma que no está en mis guías. Se hace ANTES de traducir una sola línea.

Cambiá lo que está entre «…».

> Voy a vender «qué producto» a «a quién» en «país», en «idioma». Antes de traducir necesito una guía de estilo.
>
> Buscá y leé por lo menos 15 fuentes del país, de al menos 5 tipos distintos: revistas y blogs del tema, foros, reseñas de productos parecidos, comentarios en redes, y anuncios de quienes venden algo parecido allá. Quiero ver cómo escribe la gente, no cómo escriben los diccionarios.
>
> Armame un archivo con estas partes, en tablas:
> 1. **Fuentes:** cuáles pudiste leer y cuáles no.
> 2. **Trato:** cómo se le habla a mi clienta (tú o usted, género) y quién usa cada forma.
> 3. **Cómo lo dice ella:** las palabras reales para su problema y para lo que busca. Frases cortas.
> 4. **Suena a traducción → suena local:** qué evitar, qué usar y por qué.
> 5. **Ortografía y formatos:** comillas, signos, mayúsculas, fechas, moneda, decimales y primer día de la semana.
> 6. **Glosario:** las palabras de mi producto, una sola traducción para cada una.
> 7. **Cultura:** números, colores, fiestas o temas que conviene evitar.
> 8. **Lista de control** de 8 a 10 puntos para revisar cada texto.
>
> Reglas:
> - Marcá cada dato como «visto en una fuente» o «criterio tuyo». No mezcles.
> - Decime con claridad lo que no pudiste comprobar.
> - No copies frases largas de nadie: giros cortos de uso común.
> - Arriba de todo escribí: «Guía de trabajo. No la certificó una persona nativa».

## Qué hago después
- [ ] La leo entera. Si una parte quedó floja, le pido más fuentes de ese tipo.
- [ ] Recién ahí se traduce, con la guía pegada en el pedido.
- [ ] Cada corrección que aparezca después se suma a la guía.
- [ ] La guardo aunque el país se apague.

Ver también: [[reglas-comunes-a-todos-los-idiomas]] · [[pedido-revision-nativa-en-dos-pasadas]] · [[antes-de-elegir-pais]]
