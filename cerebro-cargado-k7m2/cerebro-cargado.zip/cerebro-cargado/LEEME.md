# Mi cerebro, ya cargado

El kit te dio un cerebro vacío. Este paquete lo llena con lo que yo aprendí abriendo 13 países: cómo se le habla a la clienta en cada idioma, qué se rompió, qué apagué y por qué.

## Qué necesitás
Tener instalado el kit «De 0 a 100» (tu carpeta `cerebro` ya tiene que existir).

## Qué hacer
Dejá este zip en Descargas y pegale esto a Claude:

> Tengo en Descargas el zip cerebro-cargado.zip. Descomprimilo, abrí INSTALAR.md y seguilo. No pises nada de mi cerebro. Al terminar, mostrame qué sumaste.

## Qué trae
- `experiencia/paises/` 13 fichas, una por país o idioma.
- `experiencia/lecciones.md` 20 errores reales, cada uno con lo que se hace ahora.
- `experiencia/decisiones-de-ejemplo.md` 8 decisiones contadas con su resultado.
- `experiencia/paises-apagados.md` los que cerré y el motivo.
- `experiencia/cobros.md` qué mirar del cobro antes de escalar un país.
- `experiencia/lista-al-reusar-una-tienda.md` la limpieza completa, paso por paso.

Y ahora también:
- `experiencia/indice.md` el mapa: qué leer para cada situación. Empezá por acá.
- `experiencia/guias-de-idioma/` 9 guías de estilo completas (italiano, danés, húngaro, polaco, alemán, francés, griego, hebreo y chino de Taiwán) y las reglas que valen en todos. Sirven para cualquier producto.
- `experiencia/metodo/` 14 notas de cómo trabajo: el bot de escala, escalar por la hora en que compra cada país, renovar un ganador, estructura y nombres de campaña, segmentación abierta, salida a las 00:00, etiquetas de seguimiento, reusar una página de Facebook, revisar el checkout como otro país, recuperar carritos y pagos fallados, el extra del checkout y las ofertas de después, la rutina diaria, qué mirar antes de elegir país y el recorrido completo para llevar un producto a otro idioma.
- `experiencia/plantillas/` 3 listas de control (antes de prender, antes de publicar una traducción, al apagar un país) y 5 pedidos listos para copiar.

Nuevo:
- **El bot de escala.** `experiencia/metodo/bot-de-escala.md` explica qué es: Claude sube el presupuesto solo cuando un conjunto vende, en la hora en que compra cada país, y a la noche deja todo como estaba. Se instala con `experiencia/plantillas/pedido-instalar-el-bot-de-escala.md`: copiás el pedido, se lo pegás a Claude y arranca con un día de prueba en el que no toca nada. Es para cuando ya tenés un anuncio ganador.

## Importante
Es mi experiencia, no una regla universal. Las reglas de idioma son de trabajo: salieron de leer cómo escribe la gente de cada país y de revisiones hechas con IA, sin una persona nativa que las certifique. Si podés, hacé revisar tu texto final por alguien del país.

No hay números de mi negocio ni nombres de mis productos. No hacen falta para que te sirva. Los únicos números que vas a ver son los de las reglas del método. Nada de esto promete un resultado.
