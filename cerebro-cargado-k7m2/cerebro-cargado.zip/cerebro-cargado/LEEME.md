# Mi cerebro, ya cargado

El kit te dio un cerebro vacío. Este paquete lo llena con lo que yo aprendí abriendo 13 países: cómo se le habla a la clienta en cada idioma, qué se rompió, qué apagué y por qué.

## Qué necesitás
Tener instalado el kit «De 0 a 100» (tu carpeta `cerebro` ya tiene que existir).

## Qué hacer
Dejá este zip en Descargas y pegale esto a Claude:

> Tengo en Descargas el zip cerebro-cargado.zip. Descomprimilo, abrí INSTALAR.md y seguilo. No pises nada de mi cerebro. Al terminar, mostrame qué sumaste.

## Qué trae
- `experiencia/paises/` 13 fichas, una por país o idioma.
- `experiencia/lecciones.md` 20 errores reales, cada uno con lo que se hace ahora.
- `experiencia/decisiones-de-ejemplo.md` 8 decisiones contadas con su resultado.
- `experiencia/paises-apagados.md` los que cerré y el motivo.
- `experiencia/cobros.md` qué mirar del cobro antes de escalar un país.
- `experiencia/lista-al-reusar-una-tienda.md` la limpieza completa, paso por paso.

## Importante
Es mi experiencia, no una regla universal. Las reglas de idioma son de trabajo: salieron de leer cómo escribe la gente de cada país y de revisiones hechas con IA, sin una persona nativa que las certifique. Si podés, hacé revisar tu texto final por alguien del país.

No hay números de mi negocio ni nombres de mis productos. No hacen falta para que te sirva.
