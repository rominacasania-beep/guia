# Kit De 0 a 100

No abras ni muevas nada a mano. Claude lo instala por vos.

## Qué necesitás
- La app de Claude instalada en tu computadora (Windows o Mac), con plan pago.
- Estar en la pestaña **Code**, con una carpeta de trabajo elegida.
- Este zip en tu carpeta Descargas.

## Qué hacer
Escribile esto a Claude:

> Instalá el kit kit-de-0-a-100 que está en mi carpeta Descargas y guiame paso a paso.

Nada más. Claude abre el kit, instala todo, te hace unas preguntas y te lleva de la mano.

## Qué trae
- `GUIA.md` la guía completa en texto, para que Claude la tenga entera.
- `cerebro/` las notas con las que arranca tu Claude: el manual, tu tablero y las reglas del método.
- `skills/` 20 manuales, uno por cada tarea del camino.
- `GUIA-OTRO-IDIOMA.md` el paso a paso para llevar tu producto a otro país, con las frases para copiar.
- `motor-pdf/` el motor que traduce tus PDF sin romper el diseño (solo Windows).
- `INSTALAR.md` las instrucciones que sigue Claude.
