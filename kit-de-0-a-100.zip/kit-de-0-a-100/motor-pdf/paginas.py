# Paso 1. Convierte cada pagina del PDF original en imagen y le pasa el lector de texto (OCR) de Windows.
# uso: paginas.py 1 2 ...  (o: paginas.py all)  -> w/XX/pNNN.png y w/XX/pNNN.png.json
import sys,os,glob,subprocess,pymupdf,cfg
for i in cfg.ids(sys.argv[1:]):
    d=pymupdf.open(os.path.join(cfg.ORIG,cfg.pdf(i)['archivo'])); o=f"{cfg.W}/{i:02d}"; os.makedirs(o,exist_ok=True)
    for n,p in enumerate(d): p.get_pixmap(dpi=cfg.est(i).get('dpi',216)).save(f"{o}/p{n:03d}.png")
    r=subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',os.path.normpath(cfg.S+'/ocr.ps1'),os.path.normpath(o),cfg.C['idioma_origen_ocr']],capture_output=True,text=True)
    print(i,'paginas',len(d),'leidas',len(glob.glob(o+'/*.png.json')),r.stderr.strip()[:300],flush=True)
