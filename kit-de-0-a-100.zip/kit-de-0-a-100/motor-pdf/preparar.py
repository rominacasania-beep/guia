# Paso 3. Arma la lista a traducir de cada PDF: tr/in_XX.json
# uso: preparar.py 1 2 ... (o all)
import json,os,sys,cfg
os.makedirs(cfg.TR,exist_ok=True)
for i in cfg.ids(sys.argv[1:]):
    b=json.load(open(f"{cfg.W}/blocks_{i:02d}.json",encoding='utf-8')); T=cfg.txt(i)
    dp=set(T.get('drop_pages',[])); sk=set(T.get('skip',[])); items=[]
    for n in sorted(map(int,b)):
        if n in dp: continue
        for x in b[str(n)]['blocks']:
            if x['id'] not in sk: items.append({'k':x['id'],'orig':x['orig'],'ancho_px':x['box'][2]-x['box'][0],'lineas':x['nl']})
    json.dump(items,open(f"{cfg.TR}/in_{i:02d}.json",'w',encoding='utf-8'),ensure_ascii=False,indent=0)
    print(i,'items',len(items),'letras',sum(len(x['orig']) for x in items))
