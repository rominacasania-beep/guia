# Lee config.json (copia config.ejemplo.json y completala). Lo usan todos los scripts.
import json,os,sys
S=os.path.dirname(os.path.abspath(__file__))
if not os.path.exists(S+'/config.json'): sys.exit('Falta config.json: copia config.ejemplo.json y completala.')
C=json.load(open(S+'/config.json',encoding='utf-8'))
W=S+'/w'; TXT=S+'/txt'; TR=S+'/tr'; OUT=S+'/out'
ORIG=C['carpeta_originales']; DEST=C['carpeta_final']
def ids(args): return [int(k) for k in C['pdfs']] if args==['all'] else [int(a) for a in args]
def pdf(i): return C['pdfs'][str(i)]
def est(i): return pdf(i).get('estilo',{})
def txt(i):
    p=f"{TXT}/{i:02d}.json"
    return json.load(open(p,encoding='utf-8')) if os.path.exists(p) else {}
