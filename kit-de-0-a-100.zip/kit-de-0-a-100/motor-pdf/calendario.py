# Calendarios y planificadores con TEXTO REAL (se puede seleccionar con el mouse en el PDF).
# Cambia solo los nombres de dias, meses y rotulos; numeros y diseno quedan intactos.
# uso: calendario.py <numero> ...   -> out/XX.pdf   (lo que no supo traducir lo lista en «sin mapear»)
# Las palabras salen de "calendario" en config.json: dias, meses (12, en orden), meses_origen y otros.
# Es un punto de partida: cada calendario tiene su diseno y casi siempre hay que ajustar tamanos y lugares.
import pymupdf,os,sys,re,cfg,hp
K=cfg.C['calendario']; norm=lambda t: re.sub(r'\s','',t).lower()
DAYS={norm(k):v for k,v in K['dias'].items()}; OTROS={norm(k):v for k,v in K.get('otros',{}).items()}
MO=[norm(m) for m in K['meses_origen']]
def mes(k):
    for n,a in enumerate(MO):
        if k==a: return K['meses'][n]
def run(i):
    d=pymupdf.open(os.path.join(cfg.ORIG,cfg.pdf(i)['archivo'])); unk=set()
    for p in d:
        todo=[]
        for b in p.get_text('dict')['blocks']:
            for l in b.get('lines',[]):
                t=''.join(s['text'] for s in l['spans']).replace('​','').strip(); k=norm(t)
                if not t or re.fullmatch(r'[\d.,/-]+',k): continue
                nuevo=DAYS.get(k) or OTROS.get(k) or mes(k)
                if not nuevo: unk.add(t); continue
                if t[:1].isupper(): nuevo=nuevo.upper() if t.isupper() else nuevo[:1].upper()+nuevo[1:]
                s=l['spans'][0]; todo.append((list(l['bbox']),nuevo,s['size'],'#%06x'%s['color']))
                p.add_redact_annot(pymupdf.Rect(l['bbox']),fill=False,cross_out=False)
        p.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE,graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,text=pymupdf.PDF_REDACT_TEXT_REMOVE)
        for (x0,y0,x1,y1),t,sz,col in todo:
            ex=30 if sz>=30 else 14
            hp.put(p,[x0-ex,y0-3,x1+ex,y1+sz*0.6],t,'cuerpo',sz*0.95,col,'center',vcenter=False)
    os.makedirs(cfg.OUT,exist_ok=True); name=f"{cfg.OUT}/{i:02d}.pdf"; d.subset_fonts(); d.save(name,garbage=3,deflate=True)
    print(i,'pags',len(d),'MB',round(os.path.getsize(name)/1e6,1),'sin mapear',sorted(unk)[:30])
for i in map(int,sys.argv[1:]): run(i)
