# Paso 5. Arma el PDF traducido: borra el texto viejo de cada pagina y escribe el nuevo en el mismo lugar.
# uso: render.py <numero> [--pages a,b,c]   -> out/XX.pdf
# Lee w/blocks_XX.json (donde esta cada texto) y txt/XX.json (la traduccion y los ajustes):
#   {"t": {clave: texto},            texto nuevo de cada bloque; "" = se borra y no se escribe nada
#    "skip": [claves],               bloques que se dejan como estan (logos, dibujos con letras)
#    "drop_pages": [numeros],        paginas que no van en la version nueva
#    "erase": [{"page":n,"box":[x0,y0,x1,y1]}],                 restos a borrar que el lector no vio
#    "add": [{"page":n,"box":[...],"t":"texto","hpx":40}]}      textos que el lector no vio
#           (en add se puede sumar "font", "align", "color" y "erase": false)
import sys,os,re,json,numpy as np,pymupdf
from PIL import Image
import cfg,hp
def caps(o):
    L=[c for c in (o or '') if c.isalpha()]
    return len(L)>=3 and sum(c.isupper() for c in L)/len(L)>=0.75
def up(t): return ''.join(p if p.startswith('<') else p.upper() for p in re.split(r'(<[^>]+>|&[a-z]+;)',t))
def run(i,only=None):
    st=cfg.est(i); Z=st.get('dpi',216)/72
    blocks=json.load(open(f"{cfg.W}/blocks_{i:02d}.json",encoding='utf-8'))
    T=cfg.txt(i); txt=T.get('t',{}); add=T.get('add',[])
    skip=set(T.get('skip',[])); dropp=set(T.get('drop_pages',[])); ea=T.get('erase',[])
    out=pymupdf.open(); os.makedirs(cfg.OUT,exist_ok=True); miss=[]
    for n in sorted(map(int,blocks)):
        if n in dropp or (only and n not in only): continue
        pg=blocks[str(n)]
        im=np.array(Image.open(f"{cfg.W}/{i:02d}/p{n:03d}.png").convert('RGB')); H,W=im.shape[:2]
        items=[]; boxes=list(pg['erase'])
        for b in pg['blocks']:
            if b['id'] in skip: continue
            if b['id'] not in txt: miss.append(b['id']); continue
            boxes+=b['lb']; items.append(b)
        padd=[a for a in add if a['page']==n]
        for a in padd:
            if a.get('erase',True): boxes.append(a['box'])
        for e in ea:
            if e['page']==n: boxes.append(e['box'])
        cols={b['id']:hp.textcolor(im,b['box']) for b in items}
        addc=[hp.textcolor(im,a['box']) for a in padd]
        im2=hp.erase(im,boxes)
        PW,PH=W/Z,H/Z
        sc=min(1,st.get('maxw',1300)/W)
        bgim=Image.fromarray(im2)
        if sc<1: bgim=bgim.resize((int(W*sc),int(H*sc)),Image.LANCZOS)
        p=out.new_page(width=PW,height=PH); p.insert_image(p.rect,stream=hp.jpg(np.array(bgim),st.get('q',78)))
        def draw(box,t,hpx,col,lb=None,font=None,align=None):
            if not t.strip(): return
            x0,y0,x1,y1=[v/Z for v in box]; h=hpx/Z; tit=hpx>=st.get('title_px',62)
            f=font or (st.get('title','titulo') if tit else st.get('body','cuerpo'))
            size=h*(st.get('title_k',0.86) if tit else st.get('body_k',1.0))
            if not align:
                align='center'
                if lb and len(lb)>1:
                    L=np.std([l[0] for l in lb]);C=np.std([(l[0]+l[2])/2 for l in lb]);align='center' if C<=L else 'left'
            w=x1-x0; ex=max(w*0.07,6) if not (lb and len(lb)>1) else 1
            X0=max(14,x0-ex);X1=min(PW-14,x1+ex)
            hb=y1-y0; ey=max(2,hb*0.1)
            hp.put(p,[X0,y0-ey,X1,y1+ey+h*0.35],t,f,size,col,align)
        for b in items:
            t=txt[b['id']]; t=up(t) if caps(b['orig']) else t
            draw(b['box'],t,st.get('hpx_over',{}).get(b['id'],b['hpx']),cols[b['id']],b['lb'],st.get('font_over',{}).get(b['id']))
        for k,a in enumerate(padd):
            draw(a['box'],a['t'],a.get('hpx',(a['box'][3]-a['box'][1])*0.8),a.get('color') or addc[k],None,a.get('font'),a.get('align'))
    name=f"{cfg.OUT}/{i:02d}{'_t' if only else ''}.pdf"; out.subset_fonts(); out.save(name,garbage=3,deflate=True)
    print(i,'pags',len(out),'MB',round(os.path.getsize(name)/1e6,1),'sin_traducir',len(miss),miss[:6])
    return name
if __name__=='__main__':
    only=None
    if '--pages' in sys.argv: only=set(map(int,sys.argv[sys.argv.index('--pages')+1].split(',')))
    run(int(sys.argv[1]),only)
