# Paso 4. Control de la traduccion antes de armar el PDF.
# uso: chequeo.py 1 2 ... (o all) -> faltan, restos del idioma original, marcas, letras que la fuente no tiene, textos demasiado largos
import json,sys,os,re,cfg,hp
from fontTools.ttLib import TTFont
sys.stdout.reconfigure(encoding='utf-8')
CM=[TTFont(os.path.join(hp.FONTS,f)).getBestCmap() for f in sorted(set(hp.FF.values()))]
C=cfg.C
pal=C.get('palabras_del_idioma_origen',''); let=C.get('letras_que_no_existen_en_destino','')
ORI=re.compile((f"[{re.escape(let)}]|" if let else '')+rf"\b({pal})\b",re.I) if (pal or let) else None
mk=[re.escape(m) for m in C.get('marcas_a_borrar',[]) if not m.startswith('<')]
MARK=re.compile('|'.join(mk)+'|@',re.I) if mk else re.compile('@')
limpio=lambda v: re.sub(r'<[^>]+>','',v)
for i in cfg.ids(sys.argv[1:]):
    inp=json.load(open(f"{cfg.TR}/in_{i:02d}.json",encoding='utf-8')); t=cfg.txt(i).get('t')
    if t is None: print(i,'NO EXISTE txt'); continue
    miss=[x['k'] for x in inp if x['k'] not in t]
    ori=[(k,v[:60]) for k,v in t.items() if ORI and ORI.search(limpio(v))]
    mar=[(k,v[:60]) for k,v in t.items() if MARK.search(v)]
    gl=sorted({c for v in t.values() for c in limpio(v) if c not in '\n' and any(ord(c) not in cm for cm in CM)})
    src={x['k']:len(x['orig']) for x in inp}
    lng=[k for k,v in t.items() if k in src and len(limpio(v))>1.3*src[k]+6]
    print(f"{i:02d} items {len(inp)} traducidos {len(t)} | faltan {len(miss)} {miss[:8]} | idioma original {len(ori)} {ori[:4]} | marcas {len(mar)} {mar[:3]} | letras sin fuente {''.join(gl) or '-'} | largos {len(lng)} {lng[:8]}")
