# Paso 2. Junta las lineas leidas en bloques (parrafos, titulos) y arma hojas numeradas para revisar.
# uso: bloques.py 1 2 ... (o all) -> w/blocks_XX.json y w/revXX/sNNN.jpg
import json,glob,os,re,sys,cfg
from PIL import Image,ImageDraw
MARCAS=[re.sub(r'[^a-z0-9]','',m.lower()) for m in cfg.C.get('marcas_a_borrar',[]) if not m.startswith('<')]
def isbrand(t):
    c=re.sub(r'[^a-z0-9]','',t.lower())
    return any(m and m in c for m in MARCAS)
def junk(t): return sum(c.isalpha() for c in t)<=2
def lines_of(js):
    out=[]
    ls=js.get('lines') or []
    if isinstance(ls,dict): ls=[ls]
    for l in ls:
        w=l['words'] if isinstance(l['words'],list) else [l['words']]
        x0=min(a['x'] for a in w);y0=min(a['y'] for a in w);x1=max(a['x']+a['w'] for a in w);y1=max(a['y']+a['h'] for a in w)
        out.append(dict(t=l['text'],b=[x0,y0,x1,y1],h=y1-y0))
    return out
def group(ls):
    ls=sorted(ls,key=lambda l:(l['b'][1],l['b'][0])); bl=[]
    for l in ls:
        for b in reversed(bl[-4:]):
            la=b['lines'][-1]
            gap=l['b'][1]-la['b'][3]; hm=max(l['h'],la['h'])
            ov=min(l['b'][2],la['b'][2])-max(l['b'][0],la['b'][0])
            if -0.5*hm<gap<1.1*hm and ov>0 and max(l['h'],la['h'])/max(1,min(l['h'],la['h']))<2.2:
                b['lines'].append(l);break
        else: bl.append({'lines':[l]})
    return bl
def build(i):
    d=f"{cfg.W}/{i:02d}"; pages={}
    for f in sorted(glob.glob(d+'/*.png.json')):
        n=int(os.path.basename(f)[1:4])
        js=json.load(open(f,encoding='utf-8-sig'))
        erase_only=[];keep=[]
        for l in lines_of(js):
            if isbrand(l['t']): erase_only.append(l['b'])      # tu marca: se borra y no se traduce
            elif junk(l['t']): pass
            else: keep.append(l)
        bl=[]
        for k,b in enumerate(group(keep)):
            L=b['lines']
            bl.append(dict(id=f"p{n:03d}b{k:02d}",box=[min(x['b'][0] for x in L),min(x['b'][1] for x in L),max(x['b'][2] for x in L),max(x['b'][3] for x in L)],
              lb=[x['b'] for x in L],hpx=sorted(x['h'] for x in L)[len(L)//2],nl=len(L),orig=' / '.join(x['t'] for x in L)))
        pages[n]=dict(blocks=bl,erase=erase_only)
    json.dump(pages,open(f"{cfg.W}/blocks_{i:02d}.json",'w',encoding='utf-8'),ensure_ascii=False,indent=0)
    os.makedirs(f"{cfg.W}/rev{i:02d}",exist_ok=True)
    ns=sorted(pages)
    for a in range(0,len(ns),4):
        ims=[]
        for n in ns[a:a+4]:
            im=Image.open(f"{d}/p{n:03d}.png").convert('RGB'); sc=480/im.width; dr=ImageDraw.Draw(im)
            for b in pages[n]['blocks']:
                dr.rectangle(b['box'],outline=(230,0,60),width=int(2/sc)); dr.text((b['box'][0],max(0,b['box'][1]-int(16/sc))),b['id'][4:],fill=(230,0,60),font_size=int(13/sc))
            dr.text((10,10),f"p{n:03d}",fill=(0,0,200),font_size=int(18/sc))
            ims.append(im.resize((480,int(im.height*sc))))
        H=max(x.height for x in ims); sh=Image.new('RGB',(sum(x.width+6 for x in ims),H),'white'); xx=0
        for x in ims: sh.paste(x,(xx,0)); xx+=x.width+6
        sh.save(f"{cfg.W}/rev{i:02d}/s{a:03d}.jpg",quality=72)
    print(i,'paginas',len(pages),'bloques',sum(len(p['blocks']) for p in pages.values()),'letras',sum(len(b['orig']) for p in pages.values() for b in p['blocks']))
for i in cfg.ids(sys.argv[1:]): build(i)
