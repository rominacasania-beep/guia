# Paso 7. Vuelve a leer (OCR) los PDF finales y busca palabras del original que quedaron sin borrar.
# uso: verificar.py 1 2 ... (o all) -> lista de paginas con restos y w_v/res_XX.json
# Ojo: una palabra que existe igual en los dos idiomas no se marca. Mira tambien las paginas con tus ojos.
import pymupdf,glob,os,sys,subprocess,json,re,shutil,unicodedata,cfg
sys.stdout.reconfigure(encoding='utf-8')
def nz(w): return ''.join(c for c in unicodedata.normalize('NFD',w.lower()) if c.isalpha() and not unicodedata.combining(c))
def words(s,n): return {nz(w) for w in re.findall(r'[^\W\d_]{%d,}'%n,s)}
orig=set()
for j in glob.glob(cfg.TR+'/in_*.json'):
    for it in json.load(open(j,encoding='utf-8')): orig|=words(it['orig'],4)
for i in cfg.ids(sys.argv[1:]):
    d=pymupdf.open(os.path.join(cfg.DEST,cfg.pdf(i)['nombre_final']+'.pdf'))
    o=f"{cfg.S}/w_v/{i:02d}"; shutil.rmtree(o,ignore_errors=True); os.makedirs(o)
    for n in range(len(d)): d[n].get_pixmap(dpi=cfg.est(i).get('dpi',216)).save(f"{o}/p{n:03d}.png")
    subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',os.path.normpath(cfg.S+'/ocr.ps1'),os.path.normpath(o),cfg.C['idioma_origen_ocr']],capture_output=True)
    T=cfg.txt(i); nuevo=set()
    for v in list(T.get('t',{}).values())+[a['t'] for a in T.get('add',[])]: nuevo|=words(re.sub(r'<[^>]+>',' ',v),3)
    res={}
    for j in sorted(glob.glob(o+'/*.json')):
        n=int(os.path.basename(j)[1:4]); ls=json.load(open(j,encoding='utf-8-sig')).get('lines') or []
        ls=[ls] if isinstance(ls,dict) else ls
        for l in ls:
            for x in (l['words'] if isinstance(l['words'],list) else [l['words']]):
                c=nz(x['t'])
                if len(c)>=4 and c in orig and c not in nuevo: res.setdefault(n,[]).append({'t':x['t'],'box':[x['x'],x['y'],x['x']+x['w'],x['y']+x['h']]})
    print(f"== {i:02d} paginas {len(d)} con restos {len(res)}",flush=True)
    for n,v in res.items(): print('  pagina final',n,' '.join(x['t'] for x in v)[:200])
    json.dump(res,open(f"{cfg.S}/w_v/res_{i:02d}.json",'w',encoding='utf-8'),ensure_ascii=False)
