# Brief de traducción · <PRODUCTO> a <IDIOMA> de <PAÍS>

> Plantilla. Claude la completa con la guía de estilo del país antes de traducir.

Producto: <QUÉ ES Y PARA QUIÉN>. El original está en <IDIOMA ORIGINAL>. Se lleva al **<IDIOMA> natural de <PAÍS>**, como lo escribiría una persona de allá. **No es traducción literal.**

## Entrada y salida
- Entrada: `tr/in_XX.json`. Cada ítem trae `k` (clave), `orig` (texto leído del original; « / » son cortes de línea), `ancho_px` y `lineas`.
- Salida: `txt/XX.json` con la forma `{"t": {"clave": "texto"}}`, con **todas** las claves. UTF-8.
- `<br/>` solo donde hay un corte de sentido (título / subtítulo). El texto se acomoda solo en la caja.
- No escribas en mayúsculas: si el original estaba en mayúsculas, el motor lo pasa solo.
- El lector se equivoca: «10» por «lo», «fe» por «te». Si algo no tiene sentido, mirá la página en `w/XX/pNNN.png` (la clave `p012b03` es la página 12).

## Reglas de idioma
- Trato: <TÚ / USTED / EQUIVALENTE>. Género: <…>.
- Largo: como el original o menos. Nunca más de 1,25 veces.
- Ortografía, comillas, fechas y números como en <PAÍS>.
- Sin promesas médicas. Sin religión agregada.
- Sin marcas ni nombres propios de la dueña: si aparecen, la clave va con texto vacío `""`.
- Sin referencias del país de origen: se cambian por algo natural allá.
- Cero palabras del idioma original en la salida.

## Glosario obligatorio (igual en todos los PDF)
<término original> = <término local> · …

## Al terminar
Corré `python chequeo.py XX` y arreglá todo lo que marque. Reporte de 4 líneas: archivos, cantidad de claves, dudas.
