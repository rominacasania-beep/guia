# Motor de PDF · cambia el idioma sin romper el diseño

Toma tu PDF, borra el texto viejo de cada página y escribe el nuevo en el mismo lugar, con el mismo color y tamaño.
**No hace falta que programes.** Le pasás esta carpeta a Claude y él lo usa. Este archivo es para que Claude sepa cómo.

## Qué necesitás

| Qué | Para qué | ¿Obligatorio? |
|---|---|---|
| Computadora con **Windows 10 u 11** | El lector de texto (OCR) es el de Windows | 🔴 Sí. En Mac no funciona tal como está |
| **Claude** en la computadora (app de escritorio, con acceso a tus carpetas) | Corre los scripts por vos | 🔴 Sí |
| **Python 3.10 o más nuevo** | Los scripts están en Python | 🔴 Sí. Claude te guía para instalarlo |
| El idioma original instalado en Windows | El lector lo usa para leer tu PDF | 🟡 Casi siempre ya está |
| Los PDF originales en una carpeta | Son la base | 🔴 Sí |

Librerías (Claude las instala con una línea; esto es para él):

```bash
pip install pymupdf opencv-python numpy pillow fonttools
```

Probado con Python 3.12 y estas versiones: pymupdf 2.1, opencv 5.0, numpy 2.5, pillow 13.0, fonttools 4.68. `bloques.py` pide pillow 10.1 o más nuevo.

## Qué hace cada archivo

| Orden | Archivo | Qué hace | Qué deja |
|---|---|---|---|
| 0 | `config.ejemplo.json` | Plantilla de datos. Se copia como `config.json` y se completa | `config.json` |
| 0 | `fuentes.py` | Copia las letras desde tu Windows a `fonts/` | `fonts/` |
| 1 | `paginas.py` | Convierte cada página en imagen y la lee (OCR) | `w/01/p000.png` + `.json` |
| 2 | `bloques.py` | Junta las líneas en párrafos y títulos. Borra tu marca | `w/blocks_01.json` y hojas `w/rev01/` |
| 3 | `preparar.py` | Arma la lista a traducir | `tr/in_01.json` |
| — | *(Claude traduce)* | Escribe la traducción | `txt/01.json` |
| 4 | `chequeo.py` | Controla: faltan, restos del idioma viejo, marcas, letras sin fuente, textos largos | Un renglón por PDF |
| 5 | `render.py` | Arma el PDF nuevo | `out/01.pdf` |
| 6 | `final.py` | Lo guarda con su nombre final y sin datos de autor | Tu carpeta de salida |
| 7 | `verificar.py` | Vuelve a leer el PDF final y caza palabras viejas | Lista de páginas con restos |
| extra | `calendario.py` | Calendarios con texto real: cambia días y meses | `out/02.pdf` |

`cfg.py`, `hp.py` y `ocr.ps1` son piezas internas. No se corren solas.

## Para Claude: cómo adaptarlo a un producto y a un idioma nuevos

1. Copiá `config.ejemplo.json` como `config.json`. Completá: carpeta de originales, carpeta de salida, cada PDF con un número y su nombre final en el idioma nuevo, y las marcas de la dueña (se borran solas). En `marcas_a_borrar` va cada palabra de la marca por separado y también todo junto: el lector a veces la parte en dos renglones.
2. `idioma_origen_ocr`: el idioma del PDF original (`es-ES`, `en-US`, `pt-BR`…). Si Windows no lo tiene, `paginas.py` lo avisa.
3. `fuentes`: comprobá que cada letra cubra el idioma nuevo (`chequeo.py` lista las que faltan en «letras sin fuente»). Corré `python fuentes.py`. Para otra letra, poné el `.ttf` en `fonts/` y cambiá el nombre en `config.json`.
4. Corré `paginas.py all`, `bloques.py all`, `preparar.py all`.
5. **Mirá las hojas `w/rev01/*.jpg`.** Cada caja roja es un bloque. Lo que el lector no vio (adornos, portadas, letra manuscrita) no tiene caja: se suma a mano en `txt/01.json` con `add` y `erase`.
6. Escribí el brief con `BRIEF_PLANTILLA.md` y la guía de estilo del país. Traducí `tr/in_01.json` a `txt/01.json`:

```json
{
  "t": {"p000b00": "texto nuevo", "p000b01": ""},
  "skip": ["p004b02"],
  "drop_pages": [8],
  "erase": [{"page": 3, "box": [100, 200, 500, 260]}],
  "add": [{"page": 3, "box": [100, 200, 500, 260], "t": "texto", "hpx": 40}]
}
```

| Clave | Significa |
|---|---|
| `t` | Texto nuevo de cada bloque. `""` = se borra y no se escribe nada |
| `skip` | Bloques que quedan como están (logos, dibujos con letras) |
| `drop_pages` | Páginas que no van en la versión nueva |
| `erase` | Restos a borrar que el lector no vio. Caja en píxeles de la imagen |
| `add` | Textos que el lector no vio. Acepta `font`, `align`, `color`, `"erase": false` |

7. `palabras_del_idioma_origen` y `letras_que_no_existen_en_destino`: ajustá la lista. **Sacá las palabras que existen en los dos idiomas** (en la prueba, «que» y «para» dieron falsa alarma en portugués).
8. `chequeo.py all` hasta que dé todo en cero. Después `final.py all` y `verificar.py all`.
9. **Probá el control roto a propósito** (dejá un bloque en el idioma viejo) antes de creerle un «0 restos».
10. Mirá cada página del PDF final. El control no reemplaza los ojos.
11. Ajustes finos por PDF en `"estilo"`: `dpi` (216), `title_px` (62: desde qué alto un texto es título), `title_k`, `body_k`, `maxw`, `q` (calidad), `hpx_over` y `font_over` (por bloque).

## Lo que este motor NO hace

| Tema | Estado |
|---|---|
| Mac o Linux | 🔴 No. El lector de texto es de Windows. Haría falta otro (no viene) |
| Hebreo, árabe (derecha a izquierda) | 🔴 No incluido |
| Chino, japonés, coreano | 🔴 No probado en esta versión: necesitan otra letra y otro corte de línea |
| Griego, cirílico | 🟡 Deberían andar cambiando la letra. No probado en esta versión |
| Texto en letra manuscrita o muy adornada | 🟡 El lector suele no verlo: se suma a mano |
| Texto sobre fotos | 🟡 El borrado puede dejar marca. Revisar a ojo |
| El PDF final | Queda como imágenes con texto encima. No conserva enlaces ni campos para rellenar |
| Calendarios | 🟡 `calendario.py` es un punto de partida: cada diseño pide ajustes. No recalcula fechas, feriados ni fases de la luna |
| Traducir | El motor no traduce. Traduce Claude, con tu guía de estilo |

## Cómo se probó

| Prueba | Resultado |
|---|---|
| PDF inventado de 2 páginas (español → portugués) y calendario de 1 página | 🟢 Pasos 1 a 7 completos, marca borrada, control roto a propósito y cazado |
| Dos cuadernos reales con diseño (16 y 13 páginas, español → húngaro, con una traducción ya hecha) | 🟢 Mismo diseño, chequeo en cero, verificador en cero |
| Lo que salió de la prueba real | El verificador cazó una palabra de la marca que se escapaba: **poné cada palabra de tu marca por separado** en `marcas_a_borrar`, además de todo junto |
| Producto de otra persona, de punta a punta, con traducción nueva | 🔴 Sin probar |
