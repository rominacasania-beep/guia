# Copia a fonts/ las letras que nombra config.json desde las fuentes de tu Windows. uso: fuentes.py
import os,shutil,cfg
os.makedirs(cfg.S+'/fonts',exist_ok=True)
for k,f in cfg.C['fuentes'].items():
    dst=f"{cfg.S}/fonts/{f}"; src=os.path.join(os.environ.get('WINDIR','C:/Windows'),'Fonts',f)
    if os.path.exists(dst): print('ya estaba',f)
    elif os.path.exists(src): shutil.copy(src,dst); print('copiada',f)
    else: print('FALTA',f,'-> ponla a mano en la carpeta fonts')
