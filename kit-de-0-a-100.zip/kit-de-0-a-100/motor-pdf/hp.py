# Borra el texto viejo de la imagen de una pagina y escribe el nuevo (idiomas de izquierda a derecha).
import re,pymupdf,io,os,numpy as np,cv2
from PIL import Image
import cfg
FONTS=os.path.join(cfg.S,'fonts')
FF=cfg.C['fuentes']
ARCH=pymupdf.Archive(FONTS)
def erase(img,boxes,pad=4):
    H,W=img.shape[:2]; img=img.copy(); mask=np.zeros((H,W),np.uint8); m_=max(8,int(W/110)); clean=[]
    for x0,y0,x1,y1 in boxes:
        pd=max(pad,min(26,int((y1-y0)*0.22)))
        x0=max(0,int(x0-pd));y0=max(0,int(y0-pd));x1=min(W,int(x1+pd));y1=min(H,int(y1+pd))
        if x1<=x0 or y1<=y0: continue
        X0,Y0,X1,Y1=max(0,x0-m_),max(0,y0-m_),min(W,x1+m_),min(H,y1+m_)
        rm=np.ones((Y1-Y0,X1-X0),bool); rm[y0-Y0:y1-Y0,x0-X0:x1-X0]=False
        ring=img[Y0:Y1,X0:X1][rm].astype(np.float32)
        if len(ring)==0: continue
        med=np.median(ring,axis=0); dev=np.abs(ring-med).sum(axis=1)
        if np.percentile(dev,97)<26:
            # fondo liso o degradado: se rellena mezclando los bordes
            ah=y1-y0; aw=x1-x0; rr=img.astype(np.float32)
            def edge(a,n):
                a=cv2.blur(a.reshape(1,-1,3),(max(3,n//8)|1,1)).reshape(-1,3); return a
            top=edge(rr[max(0,y0-2):y0,x0:x1].mean(axis=0),aw) if y0>2 else None
            bot=edge(rr[y1:min(H,y1+2),x0:x1].mean(axis=0),aw) if y1<H-2 else None
            lef=edge(rr[y0:y1,max(0,x0-2):x0].mean(axis=1),ah) if x0>2 else None
            rig=edge(rr[y0:y1,x1:min(W,x1+2)].mean(axis=1),ah) if x1<W-2 else None
            if top is None: top=bot
            if bot is None: bot=top
            if lef is None: lef=rig
            if rig is None: rig=lef
            ty=np.linspace(0,1,ah).reshape(-1,1,1); tx=np.linspace(0,1,aw).reshape(1,-1,1)
            V=top.reshape(1,aw,3)*(1-ty)+bot.reshape(1,aw,3)*ty
            Hh=lef.reshape(ah,1,3)*(1-tx)+rig.reshape(ah,1,3)*tx
            img[y0:y1,x0:x1]=np.clip((V+Hh)/2,0,255).astype(np.uint8)
        else:
            # fondo con dibujo: se tapan solo las letras
            roi=img[y0:y1,x0:x1].astype(np.int16)
            bgc=np.median(roi.reshape(-1,3),axis=0)
            d=np.abs(roi-bgc).sum(axis=2)
            if (y1-y0)>=45 and bgc.min()>205 and (d<16).mean()>0.42: clean.append((x0,y0,x1,y1,bgc))
            m=(d>30).astype(np.uint8)*255
            mask[y0:y1,x0:x1]=np.maximum(mask[y0:y1,x0:x1],m)
    if mask.any():
        mask=cv2.dilate(mask,np.ones((3,3),np.uint8),iterations=2)
        img=cv2.cvtColor(cv2.inpaint(cv2.cvtColor(img,cv2.COLOR_RGB2BGR),mask,3,cv2.INPAINT_TELEA),cv2.COLOR_BGR2RGB)
    for x0,y0,x1,y1,bgc in clean:
        roi=img[y0:y1,x0:x1]; d=np.abs(roi.astype(np.int16)-bgc).sum(axis=2)
        roi[d<110]=bgc.astype(np.uint8)
    return img
def textcolor(img,box):
    x0,y0,x1,y1=[int(v) for v in box]; roi=img[max(0,y0):y1,max(0,x0):x1].reshape(-1,3).astype(np.int16)
    if not len(roi): return '#222222'
    bg=np.median(roi,axis=0); d=np.abs(roi-bg).sum(axis=1); c=roi[d>=np.percentile(d,96)].mean(axis=0)
    if np.abs(c-bg).sum()<90: c=np.array([50,40,50])
    return '#%02x%02x%02x'%tuple(int(v) for v in c)
AVISADAS=set()
def _css(font,size,color,align,lh):
    if font not in FF:   # letra que no esta en config.json: se usa la del cuerpo y se avisa una vez
        if font not in AVISADAS: print(f"  aviso: la letra '{font}' no esta en config.json, uso 'cuerpo'"); AVISADAS.add(font)
        font='cuerpo'
    return f"@font-face{{font-family:f;src:url({FF[font]})}} *{{font-family:f;color:{color};font-size:{size}pt;line-height:{lh};text-align:{align};word-break:keep-all;margin:0;padding:0}}"
def nowrap(t):
    # ninguna palabra se corta a la mitad (sin partir etiquetas html)
    t=re.sub(r'<[^>]+>',lambda m:m.group(0).replace(' ','\u0001'),t)
    out='<br/>'.join(' '.join(f'<span style="white-space:nowrap">{w}</span>' for w in seg.split(' ') if w) for seg in re.split(r'<br\s*/?>',t))
    return out.replace('\u0001',' ')
def put(page,rect,t,font='cuerpo',size=12,color='#222222',align='center',lh=1.22,vcenter=True):
    r=pymupdf.Rect(rect); html='<div>'+nowrap(t)+'</div>'; css=_css(font,size,color,align,lh)
    if vcenter:
        tmp=pymupdf.open(); tp=tmp.new_page(width=page.rect.width,height=page.rect.height)
        sp,sc=tp.insert_htmlbox(r,html,css=css,archive=ARCH,scale_low=0.4)
        tmp.close()
        if sp>0.5: r=pymupdf.Rect(r.x0,r.y0+sp/2,r.x1,r.y1)
    return page.insert_htmlbox(r,html,css=css,archive=ARCH,scale_low=0.4)
def jpg(img,q=78):
    b=io.BytesIO(); Image.fromarray(img).save(b,'JPEG',quality=q,optimize=True); return b.getvalue()
