# Paso 6. Arma cada PDF y lo guarda con su nombre final en la carpeta de salida, sin datos de autor.
# uso: final.py 1 2 ... (o all)
import sys,os,pymupdf,cfg,render
os.makedirs(cfg.DEST,exist_ok=True)
for i in cfg.ids(sys.argv[1:]):
    d=pymupdf.open(render.run(i)); nom=cfg.pdf(i)['nombre_final']
    d.set_metadata({'title':nom,'author':'','creator':'','producer':''})
    dst=os.path.join(cfg.DEST,nom+'.pdf'); d.save(dst,garbage=3,deflate=True)
    print(nom,len(d),'pags',round(os.path.getsize(dst)/1e6,1),'MB',flush=True)
