param([string]$Dir,[string]$Lang='es-ES')
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime]
$null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
$m=[System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'}|select -First 1
function Aw($op,$t){$task=$m.MakeGenericMethod($t).Invoke($null,@($op));$task.Wait();$task.Result}
$eng=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new($Lang))
if($null -eq $eng){ [Console]::Error.WriteLine("Windows no tiene el lector de texto para $Lang. Instala ese idioma en Configuracion, Hora e idioma, Idioma."); exit 1 }
Get-ChildItem $Dir -Filter *.png | %{
 $f=Aw ([Windows.Storage.StorageFile]::GetFileFromPathAsync($_.FullName)) ([Windows.Storage.StorageFile])
 $st=Aw ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
 $dec=Aw ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($st)) ([Windows.Graphics.Imaging.BitmapDecoder])
 $bmp=Aw ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
 $r=Aw ($eng.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
 $lines=@(); foreach($l in $r.Lines){ $w=@(); foreach($x in $l.Words){$b=$x.BoundingRect;$w+=@{t=$x.Text;x=[int]$b.X;y=[int]$b.Y;w=[int]$b.Width;h=[int]$b.Height}}; $lines+=@{text=$l.Text;words=$w} }
 $o=@{file=$_.Name;lines=$lines}|ConvertTo-Json -Depth 6 -Compress
 [IO.File]::WriteAllText($_.FullName+'.json',$o,[Text.UTF8Encoding]::new($false))
 $st.Dispose()
}
