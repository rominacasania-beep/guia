# Llevá tu producto a otro idioma · paso a paso

Para cuando tu producto **ya vende** y querés venderlo en otro país.
No hace falta programar. Vos decidís y das los clics delicados. Claude hace el resto.

## Cómo leer esta guía

Cada paso es una pantalla. Hacés uno, comprobás que salió bien y pasás al siguiente.

| Símbolo | Significa |
|---|---|
| 💬 | La frase exacta para copiar y pegar en Claude |
| ❓ | Lo que Claude te va a preguntar |
| ✋ | Lo que hacés vos a mano (Claude no puede ni debe) |
| ✅ | Cómo sabés que salió bien |
| 🟢 🟡 🔴 | Seguí · decidís vos · pará |

Lo que va entre `[CORCHETES]` lo cambiás por lo tuyo.

## El mapa

| # | Paso | Quién trabaja | Tiempo tuyo |
|---|---|---|---|
| 0 | Antes de empezar | Vos | 10 min |
| 1 | Preparar el motor de PDF | Claude | 5 min |
| 2 | Revisar accesos | Claude | 2 min |
| 3 | Validar en la Biblioteca de Anuncios | Claude | 5 min |
| 4 | Cómo hablan allá | Claude | 2 min |
| 5 | Clienta ideal | Claude | 5 min |
| 6 | Ficha del país | Claude | 5 min |
| 7 | Preparar tus PDF | Claude | 5 min |
| 8 | Traducir y revisar | Claude | 10 min |
| 9 | Armar y controlar los PDF | Claude + vos | 20 min |
| 10 | Carpeta de entrega | Claude | 5 min |
| 11 | Tienda, moneda, precio y dominio | Claude + vos | 15 min |
| 12 | Pagos | Vos | 10 min |
| 13 | Extras y post-compra | Claude | 10 min |
| 14 | Página de venta | Claude | 10 min |
| 15 | Página de Facebook | Vos, con todo preparado | 15 min |
| 16 | Píxel | Claude + vos | 10 min |
| 17 | Anuncios | Claude | 15 min |
| 18 | Lista final y prender | Vos | 10 min |

«Tiempo tuyo» es lo que estás vos delante. Claude tarda más: dejalo trabajar. Un país completo lleva entre 2 y 4 días.

---

## Paso 0 · Antes de empezar

| Necesitás | |
|---|---|
| Un producto en PDF que **ya vende** (un ganador de los escalones) | 🔴 Sin esto, no sigas |
| Computadora con **Windows** | 🔴 Para traducir los PDF. En Mac, el resto de la guía sirve igual, pero la traducción de los PDF no |
| Tus PDF originales en una carpeta | 🔴 |
| Tu tienda, tu dominio y tu cuenta de anuncios andando | 🔴 Es lo que armaste en los escalones |
| País e idioma elegidos | 🟡 El bono «Mapa de países» te ayuda |

✋ Tené a mano: el precio que querés cobrar allá y cuánto podés gastar en la prueba.

🟡 Traducir muchos PDF gasta bastante uso de Claude. Si llega al límite no se rompe nada: cuando se recarga, seguís desde donde quedó.

---

## Paso 1 · Preparar el motor de PDF

El motor ya vino en tu kit. Este paso lo deja listo para usar.

💬

```
Voy a abrir otro país. Buscá la carpeta motor-pdf que instalaste con el kit, leé su LEEME.md,
fijate si tengo Python y las librerías, e instalá lo que falte. Decime en una tabla qué quedó listo.
```

| | |
|---|---|
| ❓ | Nada, salvo permisos |
| ✋ | Si falta Python, Claude te da el enlace: lo instalás vos con «Siguiente, siguiente» |
| ✅ | Claude dice «motor listo» |

---

## Paso 2 · Revisar accesos

💬

```
Abramos [PAÍS] en [IDIOMA] con [MI PRODUCTO]. Usá la skill abrir-pais.
Empezá por el chequeo de accesos, solo leyendo. Mostrame una tabla con ✅ o ❌ y la prueba de cada uno.
No sigas si algo falla.
```

| | |
|---|---|
| ✋ | Iniciá sesión vos en lo que salga con ❌ (tienda, dominio, Facebook) |
| ✅ | Toda la tabla en ✅ |

---

## Paso 3 · Validar en la Biblioteca de Anuncios

El paso más importante: te dice si vale la pena.

💬

```
Seguí con la Biblioteca de Anuncios. Buscá mi producto y productos parecidos en varios idiomas y en [PAÍS].
Mostrame el semáforo y los 10 mejores anuncios con enlace. Solo lectura. Lo que no puedas comprobar, decímelo.
```

| Color | Qué significa | Qué hacés |
|---|---|---|
| 🟢 | Se vende en 2 o más idiomas, con anuncios de más de 30 días y 3 o más vendedores | Seguís |
| 🟡 | Se vende en otros idiomas, pero hace poco o lo vende uno solo | Decidís vos |
| 🔴 | Un solo idioma, o ningún anuncio dura 14 días | **No sigas.** Probá otro país |

| | |
|---|---|
| ✋ | Abrí 2 o 3 enlaces y mirá los anuncios con tus ojos |
| ✅ | Está el archivo `BIBLIOTECA` en la carpeta del país, con enlaces que abren |

---

## Paso 4 · Cómo hablan allá

💬

```
Ahora la guía de estilo. Leé mínimo 15 fuentes reales de [PAÍS], de al menos 5 tipos distintos, con enlace.
Quiero frases reales copiadas tal cual, el trato que se usa, palabras a evitar y 5 nombres para mi producto.
```

| | |
|---|---|
| ✅ | Está `GUIA_ESTILO`, con 15 enlaces o más y un banco de frases reales |

---

## Paso 5 · Clienta ideal

💬

```
Con esas fuentes, escribí la clienta ideal de [PAÍS]: quién es, 10 dolores con una frase real cada uno,
qué ya probó, qué desea, por qué desconfía de comprar por internet y un gancho de anuncio por dolor.
Poneme al lado la traducción al español.
```

| | |
|---|---|
| ✋ | Leé los 10 dolores. ¿Se parecen a los de tus compradoras de ahora? |
| ✅ | Está `CLIENTE_IDEAL`, con 10 dolores y 10 ganchos |

---

## Paso 6 · Ficha del país

El «pasaporte»: sirve para este producto y para el próximo que lleves allá.

💬

```
Armá la ficha del país. Buscá en la web, con la fuente al lado: moneda, medios de pago que se usan allá,
garantía legal, qué pide la ley en el pie de la tienda, fechas fuertes y qué día empieza la semana.
Proponeme 3 nombres para el producto y un precio en moneda local que allá se vea normal.
```

| | |
|---|---|
| ❓ | Qué nombre elegís · qué precio y qué tachado |
| ✋ | **Nombre y precio los elegís vos.** Claude propone |
| ✅ | Está `PAIS`, con cada dato legal con su enlace |

---

## Paso 7 · Preparar tus PDF

💬

```
Mis PDF originales están en [CARPETA]. Prepará el motor para este país: completá config.json y corré los pasos 1, 2 y 3
del LEEME. Mostrame las hojas de revisión y decime qué textos el lector no vio.
```

| | |
|---|---|
| ❓ | Qué marca, nombre o usuario tuyo hay que borrar de las hojas |
| ❓ | Si hay páginas que no viajan (frases religiosas, marcas ajenas, fotos tuyas) |
| ✋ | Mirá las hojas: cada texto tiene que tener su caja roja |
| ✅ | Claude te dice cuántas páginas y textos encontró, y cuáles suma a mano |

🟡 Portadas y letra manuscrita casi nunca se leen solas. Es normal: Claude las suma a mano.

---

## Paso 8 · Traducir y revisar

💬

```
Escribí el brief con la guía de estilo y traducí todo. Reescribí como lo diría alguien de [PAÍS], no palabra por palabra.
Después pasalo por dos revisoras nativas en limpio, que marquen lo que suena a traducción y lo corrijan.
Corré el chequeo hasta que dé todo en cero.
```

| | |
|---|---|
| ❓ | Dudas de contenido: «esta frase no tiene equivalente, ¿la cambio por…?» |
| ✅ | El chequeo da: faltan 0 · idioma original 0 · marcas 0 · letras sin fuente «-» |

🟡 Claude te va a avisar siempre: «revisado con IA, falta una persona nativa». Si podés, que lo lea alguien del país.

---

## Paso 9 · Armar y controlar los PDF

💬

```
Armá los PDF finales y corré el verificador. Antes de creerle, probalo roto a propósito.
Mostrame 5 páginas al lado de las originales y una tabla con el texto original y el nuevo.
```

| | |
|---|---|
| ✋ | **Abrí cada PDF y pasá todas las páginas.** Buscá: letras cortadas, textos encimados, restos de español, tu nombre |
| ✅ | El verificador dice «con restos 0» y vos no viste nada raro |

Si ves algo, decí la página y qué pasa: «página 12, el título pisa el dibujo».

---

## Paso 10 · Carpeta de entrega

💬

```
Subí los PDF finales a mi carpeta de entrega: una carpeta para [PAÍS] y adentro una por producto.
Compartila como «cualquiera con el enlace» y probá el enlace sin sesión iniciada.
```

| | |
|---|---|
| ✋ | Si son muy pesados, puede que tengas que arrastrarlos vos |
| ✅ | Abrís el enlace en una ventana de incógnito y se descarga |

---

## Paso 11 · Tienda, moneda, precio y dominio

💬

```
Armá la tienda de [PAÍS]: idioma [IDIOMA], moneda local, precio fijo [PRECIO] y tachado [PRECIO].
Nombres de producto y regalos en el idioma. Checkout que pida solo el correo, con todos los rótulos traducidos.
Textos legales en el idioma con lo de la ficha. Cargá el enlace de entrega.
Decime qué registro tengo que crear en mi dominio.
```

| | |
|---|---|
| ❓ | El subdominio que querés · los datos de tu empresa para los legales |
| ✋ | **Dominio:** entrás a tu proveedor y creás el registro que Claude te dicta. La contraseña la ponés vos |
| ✅ | El dominio abre con candado · el checkout muestra la moneda y el precio correctos |

💬 Para comprobar el precio:

```
Mostrame el checkout como lo ve alguien de [PAÍS], con captura.
```

---

## Paso 12 · Pagos

| | |
|---|---|
| ✋ | **Lo hacés vos.** Conectás tus cobros en la tienda nueva, o los copiás de tu tienda que ya cobra |
| ✋ | Contraseñas, códigos y verificaciones: siempre vos |
| ✅ | La tienda muestra los cobros activos en la moneda del país |

💬

```
Revisá, solo leyendo, que la tienda de [PAÍS] puede cobrar en [MONEDA]. Decime qué medios quedaron activos.
```

🔴 No todos los medios cobran en todas las monedas. Si uno no acepta la del país, decidilo antes de anunciar.

---

## Paso 13 · Extras y post-compra

💬

```
Armá los extras del checkout y la post-compra de [PAÍS] con los mismos productos de mi tienda original,
traducidos con el motor. Dejalo en pausa hasta que cada uno tenga su archivo.
Después recorré todos los caminos: todo «no», todo «sí» y mezclado.
```

| | |
|---|---|
| ❓ | Qué extras, a qué precio, y qué descuento en la post-compra |
| ✅ | Cada extra tiene su archivo · Claude te muestra la prueba de cada camino |

---

## Paso 14 · Página de venta

💬

```
Armá la página de venta de [PAÍS] con los 10 dolores arriba. Testimonios solo reales, traducidos, sin nombres
y aclarando que vienen de la versión original. Revisala a tamaño celular y mostrámela antes de publicar.
```

| | |
|---|---|
| ✋ | Abrila en tu celular. Das el OK |
| ✅ | Se lee bien y el botón lleva al checkout correcto |

---

## Paso 15 · Página de Facebook

💬

```
Preparame la página de Facebook de [PAÍS]: nombre en el idioma, descripción, usuario con 3 alternativas,
foto de perfil y portada distintas, y 4 publicaciones. Guiame clic por clic.
```

| | |
|---|---|
| ✋ | **Los clics los das vos.** Guardar el usuario pide tu contraseña. Sumala a tu portfolio |
| ✅ | La página tiene foto, portada y 4 publicaciones |

---

## Paso 16 · Píxel

💬

```
Creá el píxel de [PAÍS], conectalo a mi cuenta de anuncios y cargalo en la tienda.
Decime dónde genero la clave de la API de conversiones y dónde la pego.
Después comprobá que registra la visita en la página de venta y en el checkout.
```

| | |
|---|---|
| ✋ | **La clave la generás y la pegás vos**, directo en la tienda. No la pegues en el chat |
| ✅ | En el Administrador de eventos aparece la visita a la página y al checkout |

---

## Paso 17 · Anuncios

💬

```
Armá los anuncios de [PAÍS]: primero mis 5 que más venden, traducidos; después uno por cada dolor.
Con mi producto real en la imagen. Revisá cada texto con zoom. Mostrame cada anuncio con el texto en español al lado.
Cargá la campaña en pausa, con público país + idioma y enlaces con seguimiento. No la prendas.
```

| | |
|---|---|
| ❓ | Presupuesto por día y fecha de salida |
| ✋ | Mirá cada imagen a tamaño real. Aprobá |
| ✅ | Campaña en pausa, con tus anuncios y el enlace del dominio nuevo |

🔴 Si Claude duplica anuncios de otro país, tienen que llevar al dominio nuevo, no al viejo.

---

## Paso 18 · Lista final y prender

💬

```
Pasá la lista final de la skill. Cada renglón con su prueba: dónde lo viste. Lo que no tenga prueba, marcalo como no hecho.
```

| Renglón | 🟢 si… |
|---|---|
| PDF | Abren y descargan desde el enlace, sin sesión |
| Dominio | Abre con candado |
| Checkout | En el idioma, con moneda y precio correctos |
| Pagos | Activos en esa moneda |
| Extras y post-compra | Con archivo y recorridos |
| Compra de prueba | Te compraste y te llegó todo (recomendado) |
| Página de venta | Leída en el celular |
| Píxel | Registra visita, y la compra de prueba como «Compra» |
| Página de Facebook | Con fotos y 4 publicaciones |
| Anuncios | Revisados, con seguimiento, en pausa |

| | |
|---|---|
| ✋ | **Prender es tu decisión.** Si todo está 🟢, decile: «prendela» |
| ✅ | Claude te confirma la hora de salida y el presupuesto |

---

## Después de prender

| Cuándo | Qué le pedís |
|---|---|
| Cada día | Tu «buen día» de siempre: ya incluye el país nuevo |
| Si a los 4 días gastó y no vendió | Se apaga y se anota por qué |
| Al cerrar | 💬 `Sumá a la ficha del país lo que aprendimos.` |

## Si algo sale mal

| Pasa esto | Hacé esto |
|---|---|
| Sale el cartel de que el lector no reconoce tu idioma | Instalá el español en Windows: Configuración → Hora e idioma → Idioma |
| Cuadraditos en vez de letras | 💬 `Cambiá la letra por una que tenga todas las letras de [IDIOMA].` |
| Un texto no entra o pisa un dibujo | 💬 `Página [N]: acortá ese texto o achicá la letra.` |
| Quedó una palabra en español | 💬 `Página [N]: quedó «[PALABRA]». Borrala y volvé a verificar.` |
| Quedó tu marca | 💬 `Sumá cada palabra de mi marca por separado a las marcas a borrar y rearmá.` |
| Se cortó la sesión o llegaste al límite | 💬 `Leé ESTADO.md de la carpeta de [PAÍS] y seguí desde ahí.` |
| El precio se ve distinto | 💬 `Mostrame el checkout como lo ve alguien de [PAÍS] y corregí el precio.` |

## Lo que esta guía no hace

| Tema | |
|---|---|
| Traducir PDF en Mac | 🔴 El motor es solo para Windows |
| Hebreo, árabe, chino, japonés, coreano | 🔴 El motor no los trae. Griego y ruso: sin probar |
| Calendarios con fechas, feriados o lunas del país | 🟡 Solo cambia nombres de días y meses |
| Productos que no son PDF (video, audio) | 🔴 |
| Portadas nuevas en el idioma | 🟡 Se generan aparte, con un generador de imágenes |
| Asesoría legal o de impuestos | 🟡 Claude busca y te da la fuente; no reemplaza a un profesional |

## Las 5 reglas

1. Sin 🟢 o 🟡 en la Biblioteca, no se traduce nada.
2. Contraseñas, claves y pagos: siempre vos.
3. Nada se publica ni se prende sin tu OK.
4. Testimonios y números: solo reales.
5. Lo revisado con IA no reemplaza a una persona nativa.
