# Guía «De 0 a 100 por día»

Esta es la guía completa, en texto, para que Claude la tenga entera. La versión con videos e imágenes es la página donde se descargó este kit.

Los pedidos que aparecen entre secciones son frases que la persona te puede decir; cuando te las diga, usá la skill que corresponda.

------------

PARTE A

Me copiaron el producto. Lo llevé a otros idiomas.
Video 1 · Por qué existe esta guía. Voz generada con IA.
Los idiomas a los que lo fui llevando
Italiano
Francés
Danés
Polaco
Húngaro
Hebreo
Chino
Alemán
Griego
Holandés
Coreano
Ruso
Portugués

No hablo ninguno de esos idiomas. Lo que tengo es un sistema, y ese sistema es lo que vas a instalar acá.

Cómo trabajo hoy
Sin mostrar la cara	Estos productos no los vendo con mi marca personal ni con mi imagen
Solo con Facebook	Ni siquiera uso Instagram: son anuncios en Facebook y nada más
Todo vive en Claude	Hoy todo mi negocio está ahí adentro: lo que vendo, lo que aprendo y lo que decido
Desde octubre de 2026	Vendo productos digitales hace 4 años, pero trabajo de esta forma desde hace muy poco
Esto lo armó Claude	La guía, el kit y los videos. Yo le dije qué quería y él hizo el resto
Es mi proceso	Lo que estoy aprendiendo en el camino. Seguro hay un millón de formas más; esta es la que uso yo ahora
26
días tiene mi cerebro
20/10
el día que nació
Así se ve un cerebro en Obsidian: cada punto es una nota y cada línea, una conexión. El mío nació el 20 de octubre y crece todos los días.
Lo que necesitás para empezar
QUÉ	CUÁNTO	CUÁNDO
Claude, plan Pro como mínimo	Unos 20 dólares por mes. La versión gratis no alcanza	Desde el día 1
Tienda	Yo uso Impultienda. Tiene 45 días gratis	Cuando tengas el producto
Anuncios	35 dólares por día mientras probás	Cuando salgan tus primeros anuncios
Una computadora	Windows o Mac. Con el celular solo no alcanza	Desde el día 1
¿Cuánta plata necesito para saber si funciona?
QUÉ	CUÁNTO
Claude, el primer mes	Unos 20 dólares
La tienda	0 los primeros 45 días. Después tiene un costo mensual: miralo en su página y anotate la fecha en que termina la prueba
La primera prueba de anuncios	5 anuncios a 7 dólares por día son 35 por día. Cuatro días de prueba: unos 140 dólares
Para tu primer intento	Reservá entre 150 y 200 dólares, que puedas perder mientras aprendés
Dudas antes de empezar
¿Sirve para vender mi ropa o mis productos físicos?

No. Esta guía es para productos digitales: cosas que se descargan, como un PDF. No hay stock ni envíos.

¿Cuánto tiempo lleva?

La instalación de hoy, menos de una hora. Después, una o dos horas por día. Los primeros escalones los podés hacer en una semana.

¿En cuánto tiempo voy a vender?

No te lo puedo prometer. Hay productos que venden en la primera tanda y otros que no venden nunca: por eso existe la regla de cortar rápido y probar otro.

¿Es seguro que Claude toque mi computadora?

Claude trabaja dentro de la carpeta que le elegiste y te pide permiso antes de cada cosa. Nunca ve tus contraseñas ni tus tarjetas: eso lo escribís siempre vos.

¿Cómo cobro la plata?

La tienda cobra por vos, con tarjeta y otros medios, y después te lo pasa. En el escalón 4 Claude te guía para conectarlo según tu país.

¿Tengo que facturar o pagar impuestos?

Depende de tu país. Antes de escalar, consultalo con un contador de donde vivís.

¿Y si alguien pide que le devuelva la plata?

Se devuelve desde la tienda. Pasa poco, y es parte del negocio.

Uso Instagram, ¿necesito Facebook?

Sí. Los anuncios salen desde una página de Facebook, aunque nunca publiques ahí. Conviene que tu perfil de Facebook sea el tuyo de siempre, no uno recién creado.

¿Cómo cancelo Claude si no me sirve?

Desde Configuración, en la parte de tu plan. Se corta al terminar el mes pago.

100 por día es una meta, no una garantía. Vas a invertir en Claude y en anuncios, y algunos intentos no van a vender. Acá te muestro el camino y cómo cortar rápido lo que no funciona.

------------

PARTE 0

Instalar tu oficina

Marcá cada casilla al terminar: tu avance queda guardado en este navegador.

Hoy, solo estas 3 cosas
1	Instalar Claude y abrirlo en la pestaña Code	unos 20 minutos
2	Descargar el kit	1 minuto
3	Escribirle una frase a Claude	10 a 15 minutos, mientras instala

Todo lo demás no es para hoy. Más abajo vas a ver cosas con nombres raros. Las vas a hacer otro día y con Claude guiándote. Si hoy llegás hasta la frase, ya está.

Video 2 · Instalar tu oficina. Miralo antes de empezar los pasos.
Antes de tocar nada: qué es cada cosa
PALABRA	QUÉ ES, EN SIMPLE
Claude	Una inteligencia artificial a la que le escribís como a una persona. Acá va a ser tu empleada: investiga, escribe, arma y te muestra
Pestaña Code	La parte de Claude que puede trabajar dentro de tu computadora: crear archivos, instalar cosas, abrir páginas. El chat común no puede
Cerebro	Una carpeta de notas en tu computadora. Ahí Claude guarda lo que aprende de tu negocio para no olvidarlo de un día para el otro
Skill	Un manual que Claude sigue para hacer bien una tarea, por ejemplo armar tu tienda
Kit (el zip)	Un solo archivo que trae el cerebro inicial y las 19 skills. Claude lo abre y lo instala solo
Conector	Un permiso para que Claude vea una cuenta tuya (anuncios, ventas, mail) sin que le pases la contraseña
0.1
Instalá Claude

Claude es un programa que se instala en tu computadora, como cualquier otro. Necesitás el plan pago más chico (se llama Pro, unos 20 dólares por mes): la versión gratis no trae la parte que vamos a usar.

La página de Claude. El botón negro es el que tocás.
#	QUÉ HACÉS	QUÉ VAS A VER
1	Entrá a claude.ai/download y tocá Descargar para Windows (o para Mac)	Abajo o arriba del navegador aparece un archivo bajando
2	Cuando termine, tocá ese archivo para abrirlo. Si no lo ves, está en tu carpeta Descargas	Windows puede preguntar «¿Querés permitir que esta aplicación haga cambios?». Tocá Sí: es normal
3	Se abre Claude y te pide entrar. Si nunca lo usaste, tocá Crear cuenta y usá el mail que usás siempre	Te manda un código a ese mail para confirmar
4	Te ofrece elegir un plan: elegí Pro, pago mensual, y poné tu tarjeta. Si te dejó entrar sin pagar, tocá tu nombre (abajo a la izquierda) y buscá Mejorar plan; en inglés dice Upgrade	Se cobra en el momento. Se puede cancelar cuando quieras desde Configuración
5	Arriba vas a ver tres pestañas. Tocá la que dice Code	Es la parte de Claude que puede crear archivos e instalar cosas. La de Chat no puede
6	Te pide elegir una carpeta. En la ventana que se abre, tocá Documentos (está a la izquierda) y después el botón Seleccionar carpeta	Ahí va a trabajar Claude. Si pregunta si confiás en esa carpeta, decí que sí: es tuya
7	Abajo hay una caja para escribir. Escribí hola, ¿me ves? y apretá Enter	Si te contesta, ya está andando
Así se ve por dentro: arriba están las pestañas. La que usás es Code. (Ilustración)

Si Claude te habla en inglés, escribile: «hablame siempre en español y explicame todo simple».

Claude está abierto en la pestaña Code y me contestó
0.2
Descargá el kit

Es un solo archivo. Trae esta guía completa, tu cerebro y las 19 skills. No lo abras: lo abre Claude.

Descargar el kit

¿Tocás el botón y no baja nada? Casi siempre es porque la página se abrió adentro de Instagram o WhatsApp. Copiá la dirección, pegala en Chrome (o Safari, o Edge) y tocá el botón de nuevo.

Te pregunta si querés guardarlo: decí que sí. Si el navegador avisa que «este tipo de archivo puede dañar tu equipo», tocá Conservar: es un archivo comprimido con textos adentro. Queda en tu carpeta Descargas con el nombre kit-de-0-a-100.

El kit está en mi carpeta Descargas
0.3
Escribile una frase a Claude

Volvé a Claude, al mismo chat donde le dijiste hola, y escribile esto tal cual:

La frase
Instalá el kit que está en mi carpeta Descargas y guiame paso a paso.
Le escribís la frase, Claude va tildando cada paso y, cuando aparece el cartel, tocás Permitir. (Ilustración)
Clic por clic: qué vas a ver mientras instala

1. Escribí la frase (o tocá «Copiar» y pegala con Ctrl + V) y apretá Enter.

2. Claude empieza a trabajar y te pide permiso muchas veces, a veces en inglés (dice «Allow»). Mientras esté instalando el kit, decile siempre que sí.

3. Te va a hacer unas preguntas: tu nombre, dónde vivís, si ya tenés algo armado. Contestá con tus palabras.

4. Tarda entre 10 y 15 minutos. No cierres la ventana.

5. Al final te muestra una tabla con lo instalado. Si alguna fila dice que falta algo, escribile «arreglá lo que falta».

6. Para probar que quedó bien, escribile: «¿cuándo un anuncio es ganador?». Si te contesta con una regla con números, funcionó.

Claude terminó la instalación y mostró la tabla
Le pregunté «¿cuándo un anuncio es ganador?» y me contestó con una regla
Listo por hoy

Si Claude te mostró la tabla de lo instalado, terminaste. Cerrá la computadora. Todo lo que sigue más abajo es para otro día.

0.4
Mañana: tu primer «buen día»

Mañana, y cada día: abrís Claude, pestaña Code, la misma carpeta, y escribís «buen día». Así empieza cada día de trabajo. La primera vez, Claude te hace una entrevista corta y arma tu oficina.

Pedido · todos los días
Buen día
ESCRIBÍS	PASA
«Guardá esto»	Guarda lo nuevo del chat en el cerebro y lo respalda. Al cerrar cada sesión
«Regla nueva»	Cuando Claude se equivoca: lo convierte en regla para que no se repita
«Ordená el cerebro»	Ordena el cerebro. Una vez por semana
«Pasá la posta»	Cierra un chat largo y deja todo listo para seguir en uno nuevo
Escribís «buen día» y te responde con dónde estás y qué toca hoy. (Ilustración)
Hice mi primer «buen día» y tengo mi meta escrita
Lo que vas a ir sumando

Nada de esto es para hoy. Claude te avisa cuándo toca cada cosa y te guía clic por clic. Si te perdés, sacale una foto a tu pantalla y preguntale.

QUÉ	CUÁNDO	PARA QUÉ
Obsidian	Cuando quieras ver tu cerebro	Es la ventana para leer las notas que escribe Claude. Gratis
Chrome con Claude adentro	Antes del escalón 1	Para que Claude pueda mirar páginas con vos. Pedile: «ayudame a poner Claude en Chrome»
ChatGPT	Escalón 3	Para generar las imágenes. Empezá con la versión gratis y fijate si te alcanza
La tienda	Escalón 4	Donde se cobra y se entrega
Página de Facebook, llave de Meta Ads y píxel	Escalón 6	Para poder anunciar. Ahí aparece el token
Cuenta de anuncios y tarjeta	Escalón 8	Recién ahí empezás a gastar en anuncios
Respaldo en GitHub	Opcional	Una copia de seguridad de tu cerebro
0.5
Mirá tu cerebro en Obsidian

Claude escribe en el cerebro; Obsidian es la ventana para leerlo. Los dos miran la misma carpeta. Se baja gratis de obsidian.md/download.

La página de Obsidian. El botón violeta es el que tocás.

¿No sabés dónde quedó tu cerebro? Preguntale a Claude: «¿en qué carpeta quedó mi cerebro?». Te dice la ruta exacta, y esa es la que elegís en Obsidian.

¿Qué cerebro recibís y dónde queda?
	QUÉ ES	DÓNDE QUEDA
Tu cerebro	Viene con el kit. Trae el método y las reglas, pero todavía no sabe nada de tu negocio: lo vas llenando vos con cada día de trabajo	En tu computadora, en una carpeta que se llama cerebro, dentro de tu carpeta de usuario
Mi cerebro	Es el mío, con mi negocio adentro. No se entrega: tiene mis productos y mis números	En mi computadora

Tu cerebro es tuyo y queda en tu computadora. Nadie más lo ve, ni yo.

Captura real de Obsidian. Tocás Abrir, en «Abrir una carpeta como bóveda», y elegís tu carpeta cerebro.
Abrí Obsidian y elegí «Abrir carpeta como bóveda»
Elegí la carpeta «cerebro» de mi usuario
Abrí HOT.md: es mi tablero, la primera línea es mi meta

No edites a mano mientras Claude trabaja. Para sumar algo, decile «guardá esto en el cerebro: …» y lo ordena.

0.6
Las cuentas, cuando toque

Esto lo hacés vos. Claude nunca crea cuentas ni escribe contraseñas.

CUENTA	PARA QUÉ	CUÁNDO
Gmail del negocio	Opcional: una casilla separada de la personal. Si preferís, seguí con tu mail de siempre	Cuando quieras
GitHub	Respaldo automático de tu cerebro. Gratis, en github.com/signup	Opcional
Facebook y Business Manager	Página, píxel y cuenta publicitaria. En business.facebook.com, con un perfil real y con antigüedad	Escalón 6
Tienda (Impultienda)	Donde se cobra y se entrega el producto. Mirá el recuadro de abajo	Escalón 4
Google Drive	Para guardar los PDF que recibe quien compra. Viene con el Gmail	Escalón 4
Tarjeta para anuncios	La cargás vos en la cuenta publicitaria. Nunca se la pases a Claude	Escalón 8
La tienda que uso yo: Impultienda
La página de Impultienda. El botón de arriba a la derecha crea tu cuenta.
Por qué	Es la que tiene llave para Claude: él arma la tienda, los productos y el checkout por vos
Qué plan	Yo uso el plan Max y es el que te recomiendo, porque es el que trae esa llave
Cuánto sale al empezar	45 días gratis. Te pide la tarjeta al suscribirte, pero cobra recién cuando termina la prueba, y podés cancelar antes sin cargo
Mi consejo	Aprovechá esos 45 días: alcanzan para hacer los 12 escalones y saber si esto es para vos antes de pagar el plan
0.7
Las llaves de Claude

La de la tienda se conecta en el escalón 4, y la de Meta Ads junto con el token en el 6. Leelo ahora si querés entender la idea; hacerlo, más adelante.

Pensalo así: Claude es tu empleada nueva. Sabe hacer el trabajo, pero todavía no tiene las llaves de la oficina. Cada conector es una llave: una para ver tus anuncios, otra para entrar a tu tienda, otra para leer tu mail. Vos elegís qué llaves le das, y se las podés sacar cuando quieras.

Una llave no es tu contraseña. Claude nunca ve ni guarda tus claves: cuando conectás algo, se abre la página de ese servicio, entrás vos como siempre y tocás «Permitir».

Video 3 · Las llaves de Claude y el token.
Tus llaves, una por una
LLAVE	LO QUE CLAUDE HACE SOLO	LO QUE HACÉS VOS
Meta Ads
la más importante	Mira tus campañas, cuánto gastó y qué vendió cada anuncio. Busca en la Biblioteca de Anuncios. Sube las imágenes. Arma la campaña, los conjuntos y los anuncios, con país, idioma, presupuesto y fecha de salida. Cambia presupuestos. Revisa que el píxel esté recibiendo las visitas y las compras	Cargar la tarjeta, dar el OK y prender
Tu tienda	Crea la tienda y los productos. Pone los precios y la moneda de cada país. Arma el checkout, los extras, la oferta después de la compra y la página de venta. Carga lo que recibe quien compra. Configura el dominio. Te muestra ventas, carritos abandonados y pagos rechazados	Crear la cuenta, conectar el cobro y aprobar los cambios. El token se pega en el escalón 6
Gmail	Lee los mails de tus clientes y te deja la respuesta escrita en borrador	Leerla y enviarla
Calendario	Agenda recordatorios y revisiones (por ejemplo, «volver a mirar este país el lunes»)	Nada
Claude en Chrome	Maneja tu navegador donde no hay llave: genera las imágenes en ChatGPT, sube los PDF a Drive, prepara la página de Facebook, mira páginas de otros	Tener la sesión iniciada en cada sitio
Hotmart
opcional	Si vendés por ahí: te muestra ventas y crea cupones	Nada

Cuando abro una tienda nueva, lo único técnico que hago yo a mano es pegar el token. Lo demás lo arma Claude y yo voy aprobando.

Qué es el token y cómo se pega, clic por clic

El token es una clave larga que te da Meta. Sirve para que tu tienda le avise a Meta cada vez que alguien compra, así tus anuncios aprenden a quién mostrarse. Como es una clave, Claude no la puede escribir por vos: te dice dónde copiarla y dónde pegarla.

1. Pedile a Claude: «creá el píxel de mi tienda y decime dónde saco el token».

2. Entrá a Meta, al Administrador de eventos, y tocá tu píxel.

3. Abrí la pestaña Configuración y bajá hasta API de conversiones.

4. Tocá Generar token de acceso. Aparece un texto larguísimo que empieza con «EA». Copialo entero.

5. Volvé a tu tienda: Configuraciones → Meta / Tracking. Pegalo en el campo del token, al lado de tu píxel, y guardá.

6. Decile a Claude «ya pegué el token, comprobá que funciona». Te responde si Meta lo aceptó.

Los nombres de los botones de Meta cambian cada tanto. Si no encontrás alguno, mandale a Claude una captura de tu pantalla y preguntale dónde está.

Clic por clic: darle a Claude la llave de Meta Ads

1. En Claude, tocá tu nombre (abajo a la izquierda) y entrá a Configuración.

2. Tocá Conectores. Vas a ver una lista.

3. Buscá el de Meta Ads y tocá Conectar.

4. Se abre Facebook. Entrá con tu cuenta, elegí tu cuenta publicitaria y tocá Permitir.

5. Volvé a Claude. Al lado del conector ahora dice «Desconectar»: esa es la señal de que quedó.

Clic por clic: darle a Claude la llave de tu tienda (Impultienda)

1. En Claude: tu nombre → Configuración → Conectores → Agregar → Agregar conector personalizado.

2. En nombre escribí Impultienda. En dirección pegá https://mcp.impultienda.ar/mcp. Tocá Agregar.

3. Tocá Conectar. Se abre el inicio de sesión de Impultienda: entrá con tu cuenta y autorizá.

4. Cuando el botón diga «Desconectar», ya está.

5. Probalo en un chat nuevo con esta pregunta: «¿qué tiendas tiene mi cuenta?».

Pedido · comprobar los conectores
Revisá qué conectores tengo activos. Para cada uno, hacé una lectura simple y decime en una tabla: conectado o no, y qué podés ver. No cambies nada.
0.8
Qué hago si…
Se trabó la instalación

Copiá el mensaje de error completo y pegáselo a Claude con esta frase: «¿qué pasó y cómo lo arreglo? Explicámelo simple». Casi siempre lo resuelve solo.

Claude dice que llegué al límite

No se rompió nada: el plan tiene un tope de uso que se recarga solo en unas horas. Esperá y seguí. Para que rinda más: un tema por chat, y cuando un chat se hace largo escribile «pasá la posta» y seguí en uno nuevo.

Claude dice «listo» y no funciona

Pedile: «mostrame la prueba de que funciona». Si no puede mostrarla, no está listo.

Meta me pide verificar la cuenta o me la restringe

Hacé la verificación con tus datos reales. No abras cuentas nuevas para saltearla: empeora el problema.

No sé qué producto elegir

Volvé al escalón 1 y pedí 5 ofertas más en otro nicho. Elegí por lo que ya se vende, no por lo que te gusta.

Gasté y no vendí nada

Es normal en las primeras tandas. Aplicá la regla del escalón 9, apagá, y sacá una tanda nueva con otros ángulos antes de cambiar de producto.

------------

PARTE 1

Los 12 escalones

Un solo producto, un solo camino. No pases al siguiente hasta cumplir el «pasás cuando».

Antes del escalón 1: vendé algo que ya se vende

Casi todas queremos inventar un producto desde cero. A veces funciona. La gran mayoría de las veces, no, y te enterás después de haber gastado.

Yo lo hago al revés: primero busco un producto que ya se esté vendiendo, y recién ahí creo el mío, desde cero, basándome en ese. Eso es modelar.

CAMINO	QUÉ ES	QUÉ SUELE PASAR
Inventar	Crear algo que nadie vende todavía	No sabés si alguien lo quiere hasta que gastaste
Copiar	Usar los textos, imágenes o el nombre de otro	Está mal, te pueden bajar la cuenta y no aprendés nada
Modelar así lo hago yo	Mirar qué problema resuelve, a quién, a qué precio y cómo está armada la página. Y crear el tuyo, con tu contenido, tu nombre y tus imágenes	Arrancás sabiendo que hay gente que ya compra eso
La Biblioteca de Anuncios de Meta: es pública y gratis. Ahí se ve todo lo que se está anunciando hoy.
Nichos donde más ofertas vas a encontrar

Son ejemplos para arrancar la búsqueda del escalón 1. Lo que manda es lo que veas vendiéndose hoy en la Biblioteca de Anuncios.

NICHO	QUÉ SE VENDE
Bienestar emocional	Diarios guiados, cuadernos de escritura, planes de 21 o 30 días para ansiedad, hábitos o descanso
Crianza y niños	Kits de actividades para imprimir, juegos de emociones, experimentos caseros, rutinas
Espiritualidad	Agendas y rituales por fecha, manifestación, cartas, calendarios lunares
Oficios y manualidades	Planos, moldes y patrones para carpintería, herrería, costura, crochet
Cocina y alimentación	Recetarios por objetivo o por aparato, menús semanales, viandas
Estudio	Láminas, resúmenes y fichas por materia o carrera
Plata y negocio	Planillas de presupuesto, plantillas para vender, guías para emprender
Mascotas	Guías de adiestramiento, recetas caseras, cuidados por raza

Cómo elegir: un nicho sirve cuando ves el mismo tipo de producto anunciado por varias personas distintas, desde hace semanas. Si lo vende una sola, todavía no está probado.

Los escalones en video
Video 4 · Escalones 1 a 3. Elegir y armar tu producto.
Video 5 · Escalones 4 a 6. Tienda, página y píxel.
Video 6 · Escalones 7 a 9. Anuncios, campaña y primeros días.
Video 7 · Escalones 10 a 12. Crecer con tu ganador.
1
Elegir qué vender
VOS
Mirás las 5 ofertas y elegís una
TU CLAUDE
Busca en la Biblioteca de Anuncios qué se está vendiendo y lo ordena en una tabla
Pedido para pegar
Busco un producto digital para vender con anuncios de Meta en [NICHO o «sorpréndeme»] para [PAÍS]. Mirá la Biblioteca de Anuncios y dame 5 ofertas en una tabla: cuántos anuncios activos, días del más viejo, cuántos anunciantes distintos, precio y promesa. Solo lectura. Lo que no puedas comprobar, decímelo.
Clic por clic

1. Abrí un chat nuevo en Claude (pestaña Code) y pegá el pedido. Cambiá lo que está entre corchetes por tu nicho y tu país.

2. Claude abre la Biblioteca de Anuncios en Chrome y busca. Tarda unos minutos: dejalo trabajar.

3. Te devuelve una tabla con 5 ofertas. Mirá dos columnas: cuántos anunciantes distintos hay y cuántos días lleva el anuncio más viejo.

4. Si querés verlas con tus ojos: entrá a facebook.com/ads/library, elegí el país, «Todos los anuncios», y escribí la palabra.

5. Elegí una y decile: «me quedo con la número 3».

Error típico: elegir lo que te gusta a vos en vez de lo que ya se está vendiendo.

Pasás cuando tenés una oferta con 20 o más anuncios activos y al menos 3 anunciantes distintos
2
Desarmar la oferta elegida
VOS
Le pasás el enlace
TU CLAUDE
Confirma que es la página real y te dice su estructura, precio y extras
Pedido para pegar
Analizá esta página: [ENLACE]. Primero confirmá que es la página real a la que llevan los anuncios. Después decime su estructura, precio, extras y qué promete. Quiero modelar la estructura mejorada, sin copiar textos, imágenes ni marcas.
Clic por clic

1. En la tabla del escalón anterior, cada oferta tiene su enlace. Copialo.

2. Pegá el pedido con ese enlace en el lugar de los corchetes.

3. Claude abre la página, la recorre hasta el botón de compra y mira qué ofrece al pagar.

4. Te devuelve qué vende, a cuánto, qué extras ofrece y en qué orden está armada la página.

5. Para que no se pierda, decile: «guardá esto en el cerebro».

Error típico: copiar textos o imágenes. Se toma el orden de la página, nunca el contenido.

Pasás cuando sabés qué vende, a cuánto y con qué extras
3
Armar tu producto
VOS
Elegís nombre y precio, y leés el PDF entero
TU CLAUDE
Escribe el contenido, arma el PDF y te da el pedido de imagen para la portada
Pedido para pegar
Armá conmigo el producto: un [ebook o kit] en PDF sobre [TEMA] para [CLIENTA]. Proponeme 3 nombres, el índice y el precio de entrada. Después escribilo completo y generá el PDF. Para la portada, escribime el pedido de imagen para pegar en ChatGPT.
Clic por clic

1. Pegá el pedido con tu tema y a quién va dirigido.

2. Elegí uno de los 3 nombres y confirmá el precio.

3. Claude escribe todo y te deja un PDF en tu carpeta. Te dice dónde quedó.

4. Abrilo y leelo entero. Lo que no te guste, decíselo en simple: «el capítulo 2 hacelo más corto».

5. Para la portada: copiá el pedido de imagen que te da, pegalo en ChatGPT, bajá la imagen y decile a Claude dónde la guardaste.

Error típico: dar por bueno un PDF sin haberlo leído.

Pasás cuando abriste el PDF y lo leíste de punta a punta
4
La tienda
VOS
Creás la cuenta, cargás el cobro y aprobás cada cambio
TU CLAUDE
Crea el producto, el checkout, y la entrega por mail
Pedido para pegar
Creá mi tienda en [PLATAFORMA] con este producto: nombre, precio [X] en [MONEDA] y entrega automática por mail con el enlace al PDF. Por ahora sin ofertas extra: esas se suman en el escalón 11. Mostrame cada cambio antes de aplicarlo.
Clic por clic

1. Creá tu cuenta en la plataforma de venta. Esto lo hacés vos.

2. Conectá el cobro desde el panel de la tienda. Claude te pasa el enlace y los pasos; las claves las escribís vos.

3. Pegá el pedido. Claude te muestra cada cambio antes de hacerlo: leé y aprobá.

4. Pedile que suba el PDF a Drive y cargue el enlace como entrega del producto.

5. Hacé una compra de prueba con tu propio mail y fijate que te llegue el producto.

Error típico: salir a vender sin haber comprado vos primero.

Pasás cuando hiciste una compra de prueba y te llegó el producto
5
La landing
VOS
La leés en tu celular
TU CLAUDE
Escribe una página corta con los dolores arriba y la revisa a ancho de celular
Pedido para pegar
Escribí una landing corta (300 a 800 palabras) para [PRODUCTO]. Los dolores de la clienta van arriba. Sin testimonios inventados ni promesas de resultado. Después revisala a ancho de celular y decime qué se ve mal.
Clic por clic

1. Pegá el pedido con el nombre de tu producto.

2. Claude escribe la página y te la muestra. Pedile cambios con tus palabras.

3. Pedile el enlace y abrila en tu celular. Leela entera, de arriba abajo.

4. Tocá el botón de compra: tiene que llevarte al checkout.

Error típico: revisar solo en la computadora. Casi todas las compras se hacen desde el celular.

Pasás cuando la landing se lee bien en el celular y el botón lleva al checkout
6
Página de Facebook y píxel
VOS
Das los clics en Facebook y pegás la clave del píxel
TU CLAUDE
Prepara nombre, textos, fotos y publicaciones, y comprueba que el píxel registra
Pedido para pegar
Preparame la página de Facebook de [MARCA]: nombre, descripción, foto de perfil y portada distintas y 4 publicaciones. Yo doy los clics. Después guiame para crear el píxel y conectarlo a la tienda, y comprobá que registra la visita.
Clic por clic

1. Pegá el pedido. Claude te prepara el nombre, los textos y dos imágenes distintas.

2. Creá la página en Facebook siguiendo sus indicaciones, un paso por vez.

3. Pedile que cree el píxel y te diga dónde sacar el token (está explicado en el paso 0.7).

4. Pegá el token en tu tienda y avisale: «ya lo pegué».

5. Claude entra a tu página de venta y comprueba que el píxel registra la visita.

Error típico: saltearse el token. Sin él, Meta se pierde parte de las compras y el anuncio aprende peor.

Pasás cuando el píxel registra la visita en la landing y en el checkout
7
Primera tanda de anuncios
VOS
Generás las imágenes y elegís
TU CLAUDE
Escribe 5 anuncios, uno por ángulo, con su pedido de imagen
Pedido para pegar
Haceme 5 anuncios para [PRODUCTO], cada uno con un ángulo distinto: precio, negocio, deseo, capacidad e identidad. Para cada uno dame el texto, el titular y el pedido de imagen para ChatGPT usando la tapa real del producto. Antes de darlos por buenos, revisá la ortografía y que no prometan resultados.
Clic por clic

1. Pegá el pedido con el nombre de tu producto.

2. Recibís 5 anuncios. Cada uno trae texto, titular y un pedido de imagen.

3. Abrí ChatGPT, adjuntá la tapa de tu producto y pegá el primer pedido de imagen. Repetí con los otros 4.

4. Mirá cada imagen en grande: buscá letras raras o palabras mal escritas. Si hay, pedila de nuevo.

5. Guardá las 5 en una carpeta y decile a Claude cuál es.

Error típico: usar una imagen donde se ve un producto que no es el tuyo.

Pasás cuando tenés 5 anuncios revisados, con la tapa real del producto
8
Campaña de prueba
VOS
La revisás y la prendés vos
TU CLAUDE
Arma la campaña en pausa con todo configurado
Pedido para pegar
Creá una campaña de ventas en pausa: 5 conjuntos de 7 USD por día cada uno (presupuesto por conjunto, no por campaña), un anuncio por conjunto, país [PAÍS], idioma [IDIOMA], sin filtro de edad ni género, con inicio mañana a las 00:00. Ponele la fecha al nombre de cada conjunto. No la actives: la prendo yo.
Clic por clic

1. Antes de nada: esta campaña gasta 35 dólares por día en total. Tené apartado lo de 4 días.

2. Cargá tu tarjeta en la cuenta publicitaria de Meta. Esto lo hacés vos.

3. Pegá el pedido con tu país y tu idioma.

4. Claude sube las imágenes y arma todo en pausa. Te muestra un resumen de lo que creó.

5. Entrá al Administrador de anuncios y mirá que estén los 5 conjuntos, cada uno con su anuncio.

6. Cuando estés conforme, prendé el interruptor de la campaña. Ese clic es tuyo. Como tiene fecha de inicio, empieza a gastar recién a las 00:00.

Error típico: prender a mitad del día. Dejala para que arranque sola a las 00:00.

Pasás cuando la campaña está creada, la revisaste y la prendiste
9
Leer y cortar
VOS
Decidís qué se apaga
TU CLAUDE
Te muestra cada mañana qué gastó y qué vendió cada anuncio
Pedido para pegar
Mostrame en una tabla, por anuncio: gastado, ventas cobradas en la tienda y costo por venta. Decime cuáles apagar con esta regla: si gastó la mitad del precio del producto sin vender, se apaga. No decidas nada con una sola venta.
Clic por clic

1. Cada mañana, pegá el pedido.

2. Mirá la tabla: gastado, ventas cobradas y costo por venta de cada anuncio.

3. Aplicá la regla: si gastó la mitad del precio de tu producto y no vendió, se apaga.

4. Decile «apagá el anuncio 4» y confirmá.

5. Los primeros 3 días no toques nada más que eso.

Error típico: apagar todo el primer día por nervios, o agrandarse con una sola venta.

Pasás cuando apagaste tu primer anuncio con criterio, a los 3 días
10
Renovar cada 48 horas
VOS
Generás las imágenes y aprobás
TU CLAUDE
Saca versiones nuevas del anuncio que mejor va
Pedido para pegar
Del anuncio que mejor va, haceme 2 versiones nuevas cambiando una sola cosa en cada una (gancho, titular o primera imagen). Sumale 1 anuncio con un ángulo nuevo. Dejalos en pausa para mañana a las 00:00.
Clic por clic

1. Cada 2 días, pegá el pedido.

2. Generá las imágenes nuevas en ChatGPT, igual que en el escalón 7.

3. Claude las sube en conjuntos nuevos, en pausa, para las 00:00.

4. Revisá y prendé.

Error típico: cambiar todo a la vez. Si cambiás una sola cosa, sabés qué fue lo que funcionó.

Pasás cuando ya salieron tu segunda y tercera tanda
11
Primer ganador: subir lo que deja cada venta
VOS
Aprobás la oferta
TU CLAUDE
Arma la oferta que aparece después de la compra
Pedido para pegar
Tengo un ganador (4 o más ventas cobradas y vuelve más del doble de lo gastado). Proponeme una oferta después de la compra que sea «más de lo mismo» a 1,4 veces el precio, y su versión a mitad de precio si la rechazan. Armala en la tienda y mostramela antes de activarla.
Clic por clic

1. Confirmá que tenés un ganador: 4 o más ventas cobradas y vuelve más del doble de lo gastado.

2. Pegá el pedido.

3. Claude te propone la oferta. El precio final lo elegís vos.

4. La arma en la tienda y te la muestra antes de activarla.

5. Hacé una compra de prueba para verla aparecer después de pagar.

Error típico: armar ofertas extra antes de tener un ganador.

Pasás cuando la oferta está activa y la viste aparecer en una compra de prueba
12
Escalar y recuperar ventas
VOS
Aprobás subidas y mails
TU CLAUDE
Detecta la hora en que compra tu país y redacta los mails de recuperación
Pedido para pegar
Mirá a qué hora compra mi país en los últimos 7 días. Si hoy hubo ventas, proponé subir el presupuesto del ganador en esa franja. Aparte, listá los pagos rechazados de esta semana y redactá un mail corto para recuperarlos. No cambies presupuestos ni envíes nada sin mi OK.
Clic por clic

1. Pegá el pedido.

2. Claude te muestra a qué hora compra tu país.

3. Si hoy hubo venta, te propone cuánto subir. Aprobás o no.

4. Mirá la lista de pagos rechazados y el mail que redactó. Si te gusta, pedile que lo deje en borrador y lo enviás vos.

5. Repetilo todos los días.

Error típico: subir el presupuesto un día sin ventas.

Pasás cuando llevás 7 días seguidos sobre tu meta: seguís con la Parte 2, el plan para crecer

------------

PARTE 2

Escalar, explicado desde cero

Escalar es poner más plata en lo que ya demostró que vende. Nada más. No se escala una idea ni una corazonada: se escala un anuncio que ya trajo ventas cobradas.

Hay muchas formas de escalar. Acá te cuento la que uso yo hoy; no es la única ni la mejor para todo el mundo.

Primero, dos palabras: ABO y CBO

Es solo quién reparte la plata.

	QUIÉN REPARTE	PENSALO ASÍ	PARA QUÉ LO USO
ABO	Vos. Le ponés un monto a cada conjunto	Le das la misma plata a cada una de tus vendedoras, para ver cuál vende	Para probar: todos los anuncios reciben lo mismo y la comparación es justa
CBO	Meta. Le ponés un monto a la campaña y él lo reparte	Le das toda la plata a un encargado y él decide a quién mandarla	Cuando ya sé qué funciona y quiero que Meta empuje lo mejor
Segundo, los tres números

Vas a escuchar «uno-cinco-uno» o «uno-uno-uno». Son siempre lo mismo, en este orden: campañas · conjuntos · anuncios por conjunto.

ESTRUCTURA	QUÉ ES	CUÁNDO LA USO
1 · 5 · 1	1 campaña madre, 5 conjuntos, 1 anuncio en cada uno. En ABO, a 7 dólares por día cada conjunto	Para probar. Es mi campaña de siempre: cinco anuncios compitiendo en igualdad
1 · 1 · 1	1 campaña, 1 conjunto, 1 anuncio: el ganador solo, con su propia plata	Para escalar. Es la que más uso: saco al ganador de la prueba y le subo de a poco
Las formas de escalar que existen
FORMA	EN SIMPLE	CUIDADO
Subirle al ganador	Más presupuesto al anuncio que vende, de a 20 o 30 % por vez	Si subís de golpe, se desordena
Darle campaña propia	Sacás al ganador a una 1 · 1 · 1	Solo con un ganador de verdad
Renovarlo	Versiones nuevas del ganador, con un solo cambio	Sin tocar el original
Por horario	Subir en la hora en que tu país compra	Solo si hoy hubo venta
Abrir otro país	El mismo producto en otro idioma	Es la que más crece y la que más trabajo lleva

No lo hacés a mano. Le pedís el plan a Claude con el pedido de más abajo, lo mirás y aprobás. Él no cambia ningún presupuesto sin tu OK.

Mi plan: tres motores

Los tres corren a la vez. Si uno se frena, el negocio deja de crecer aunque los otros dos funcionen.

Video 8 · El plan de escala.
CADA 48 HORAS AL EMPEZAR, DESPUÉS TODOS LOS DÍAS
Renovar lo que ya vende

De cada anuncio ganador sale una versión nueva: el mismo anuncio con un solo cambio (gancho, titular o primera imagen).

TODOS LOS DÍAS
Escalar con un plan escrito

El presupuesto sube solo donde hubo venta hoy, y en la hora en que ese país compra. Nunca a ojo.

CADA 2 O 3 DÍAS
Abrir un mercado nuevo

Un país más con el mismo producto. Si en pocos días no vende, se apaga y se pasa al siguiente.

SITUACIÓN	QUÉ HACÉS
4 o más ventas cobradas y vuelve más del doble de lo gastado	Es ganador: se renueva todos los días
El país vendió hoy y viene vendiendo los últimos 4 días	Se le sube presupuesto en su hora pico
El país no vendió hoy	No se escala, aunque ayer haya ido bien
País nuevo que gasta y no vende en pocos días	Se apaga y se abre el siguiente
Pedido · plan de escala del día
Armá mi plan de escala de hoy en una tabla, por país: ventas cobradas hoy y en los 4 días anteriores, gasto, y qué propones (subir, mantener, bajar o apagar) con el motivo. Usá lo cobrado en la tienda, no lo que dice el panel de anuncios. No cambies ningún presupuesto sin mi OK.

------------

PARTE 3

Abrir otros idiomas: las 13 etapas

Cuando tu producto ya vende, este es el recorrido para llevarlo a un país nuevo. Es el mismo para cualquier idioma.

Video 9 · Abrir un país nuevo.
#	ETAPA	QUÉ QUEDA HECHO	QUIÉN
0	Arranque	Producto que ya vende, país, idioma, precio y nombre	Vos decidís
1	Biblioteca de Anuncios	Comprobar que el producto ya se vende en otros idiomas. Si no, no se lanza	Claude
2	Cómo hablan allá	Guía de estilo con frases reales del país	Claude
3	Clienta ideal	10 dolores dichos con sus palabras	Claude
4	Traducción nativa	Producto y bonos con el mismo diseño, con dos revisiones	Claude
5	Entrega	Una carpeta por producto con su enlace comprobado	Claude
6	Tienda	Idioma, dominio, moneda local, pagos y checkout limpio	Claude
7	Ofertas extra	Extras en el checkout y oferta después de la compra, con un juego del país	Claude
8	Landing	Los dolores arriba, sin testimonios inventados, revisada en el celular	Claude
9	Página de Facebook	Nombre en el idioma, perfil, portada y 4 publicaciones	Claude Vos das los clics
10	Píxel	Conectado a la tienda y probado en vivo	Claude Vos pegás la clave
11	Anuncios	Un ángulo por dolor, campaña armada y en pausa	Claude
12	Antes de prender	Lista de control completa	Vos das el OK
Pedido · abrir un país
Abramos [PAÍS] en [IDIOMA] con [MI PRODUCTO].
Empezá por la Biblioteca de Anuncios: decime si este producto ya se vende en otros idiomas y mostrame el semáforo.
Si da verde, seguí con las 13 etapas en orden y preguntame solo lo que tengo que decidir yo: nombre, precio y el OK final.
No prendas ninguna campaña ni gastes nada sin que yo lo apruebe.

------------

INCLUIDO

Bonos adicionales
BONO 1 · ABRIR
Mapa de países

Mi ranking de los 13 países que probé, cómo cobrar afuera sin empresa en Estados Unidos y un semáforo de seis preguntas para decidir si abrís un país.

BONO 2 · ABRIR
Los tipos de anuncio

14 formas de mostrar tu producto: pregunta grande, la lista, recorrido por dentro, voz en off, historia y más. Con cuándo usar cada una y el pedido para Claude.

BONO 3 · ABRIR
Calculadora de números

Costo por venta, punto de empate y cuándo cortar.

BONO 4 · ABRIR
«Qué hago si…» ampliado

24 problemas del camino, con su salida y lo que le decís a Claude. Con buscador.

------------

Glosario: todas las palabras, explicadas

63 palabras que aparecen en esta guía, dichas en simple. Si una herramienta tiene página propia, al lado está el enlace.

Lo primero: Claude y tu computadora
Claude: la inteligencia artificial con la que vas a trabajar. Le escribís como a una persona y hace el trabajo: busca, escribe, arma archivos y te guía. claude.ai ↗
Aplicación de Claude: el programa que instalás en tu computadora. No alcanza con usarlo desde el navegador ni desde el celular. descargarla ↗
Pestaña Code: la parte de la aplicación donde Claude puede trabajar con las carpetas de tu computadora. Es la que usamos siempre.
Plan Pro: la versión paga de Claude, unos 20 dólares por mes. La gratis no alcanza para esto.
Chat: una conversación con Claude. Conviene un tema por chat.
Pedido: lo que le escribís a Claude. En inglés le dicen «prompt». En esta guía ya vienen escritos: los copiás y cambiás lo que está entre corchetes.
Permitir («Allow»): el botón con el que Claude te pide permiso antes de tocar algo. Leés qué va a hacer y decís que sí o que no.
Límite de uso: el tope del plan. Si Claude dice que llegaste al límite no se rompió nada: se recarga solo en unas horas.
Pasar la posta: lo que le decís a Claude cuando un chat se hizo largo: te deja un resumen para seguir en un chat nuevo sin perder nada.
Carpeta Descargas: la carpeta de tu computadora donde cae todo lo que bajás de internet.
Archivo zip: varios archivos guardados en uno solo, como una valija. No hace falta que lo abras: lo abre Claude.
El kit y el cerebro
Kit: el archivo que descargás de esta página. Trae la guía, tu cerebro inicial y las 19 skills.
Skill: un manual que Claude sigue para hacer bien una tarea, por ejemplo armar tu tienda. Vos no la leés: le pedís la tarea y él la usa.
Cerebro: la carpeta de notas donde Claude anota todo lo de tu negocio: qué probaste, qué funcionó, tus números y tus reglas. Así no arranca de cero cada día.
Tablero (HOT): la nota que Claude lee primero cada mañana: en qué escalón estás, qué falta y qué sigue.
Buen día: lo que le escribís a Claude al empezar. Lee tu tablero y te dice qué hacer hoy.
Obsidian: un programa gratis para ver tu cerebro como notas conectadas. Claude escribe; Obsidian es la ventana para leer. obsidian.md ↗
Bóveda: así llama Obsidian a la carpeta donde están tus notas.
Llave (conector): el permiso que le das a Claude para entrar a una herramienta tuya, como la tienda o los anuncios. También vas a escuchar «MCP»: es lo mismo.
Token: una clave larga de letras y números que conecta dos herramientas. La copiás de un lado y la pegás en el otro. Es lo único técnico que hacés a mano.
Solo lectura: cuando Claude mira pero no cambia nada. Es como arranca siempre.
Tu producto y tu tienda
Producto digital: algo que se entrega por internet y no se envía por correo: un PDF, una guía, un cuaderno para imprimir.
PDF: el formato del archivo que recibe tu compradora. Se abre en cualquier celular o computadora.
Nicho: el tema y el tipo de persona a la que le vendés.
Oferta: todo lo que recibe la compradora y a qué precio: el producto, los regalos y los extras.
Modelar: mirar algo que ya se vende, entender por qué funciona y hacer tu propia versión mejorada. No es copiar: ni textos, ni imágenes, ni marcas.
Precio de entrada: lo que cuesta tu producto principal. También le dicen «ticket».
Tienda: la plataforma que muestra tu producto, cobra y lo entrega sola. Yo uso Impultienda.
Landing: la página que ve la gente al tocar el anuncio.
Checkout: la página donde paga.
Extra del checkout: un producto barato que se suma con un clic antes de pagar.
Oferta post-compra: la que aparece después de pagar; ahí está buena parte de la ganancia.
Entrega automática: el mail que le llega sola a la compradora con el enlace a su producto.
Compra de prueba: comprarte a vos misma para comprobar que cobra y que llega el mail.
Google Drive: la carpeta en la nube, gratis con tu Gmail, donde queda guardado el PDF que se entrega. drive.google.com ↗
Dominio: la dirección de tu página, por ejemplo tumarca.com.
Los anuncios
Meta: la empresa dueña de Facebook e Instagram. Los anuncios se hacen ahí.
Meta Ads: el sistema de anuncios de Meta. Pagás para que tu anuncio le aparezca a gente que no te conoce.
Administrador de anuncios: la pantalla de Meta donde están tus campañas y lo que gastó cada una. abrirlo ↗
Biblioteca de Anuncios: el buscador público y gratis de Meta donde ves qué anuncia cada uno. De ahí sale qué vender. abrirla ↗
Página de Facebook: la página de tu marca. Los anuncios salen a nombre de ella, no de tu perfil personal.
Píxel: el código de Meta que avisa quién compró, para que el anuncio aprenda a quién mostrarse.
Campaña: la caja grande que contiene tus conjuntos y anuncios.
Conjunto: el grupo de anuncios que comparte un presupuesto, un país y un idioma.
Anuncio: lo que ve la persona: la imagen o el video, el texto y el botón.
Creativo: la imagen o el video del anuncio.
Ángulo: la razón por la que alguien compraría.
Gancho: lo primero que se ve o se lee del anuncio, lo que frena el dedo.
Presupuesto diario: lo máximo que Meta puede gastar por día en ese conjunto o campaña.
ABO: campaña donde vos decidís cuánto gasta cada conjunto. Sirve para probar.
CBO: campaña donde ponés un solo presupuesto y Meta lo reparte. Sirve para crecer.
1·5·1: mi forma de probar: 1 campaña, 5 conjuntos, 1 anuncio en cada uno.
1·1·1: mi forma más usada de crecer: 1 campaña, 1 conjunto, 1 anuncio que ya ganó.
Los números
Venta cobrada: la que de verdad entró en tu tienda. Es la única que cuenta; lo que dice Meta es orientativo.
Gasto: lo que pagaste en anuncios.
Retorno: cuánto vuelve por cada dólar en anuncios; 2 significa que por cada 1 vuelven 2. En inglés, «ROAS».
Costo por venta: lo que gastaste en anuncios dividido por las ventas que tuviste.
Punto de empate: lo máximo que podés pagar por venta sin perder plata.
Ganador: el anuncio que ya demostró que vende: 4 ventas cobradas o más, y cobró más del doble de lo que gastó.
Cortar: apagar un anuncio que gastó la mitad del precio de tu producto y no vendió.
Renovar: hacer versiones nuevas de un anuncio ganador antes de que se canse.
Escalar: ponerle más presupuesto a lo que ya vende, de a poco.
Abrir un país: llevar el mismo producto, traducido, a otro país u otro idioma.
