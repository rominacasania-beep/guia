# Instalación (la sigue Claude, paso a paso)

Quien te pide esto no sabe programar. Hablale simple y contale en una línea qué vas a hacer antes de cada paso.

Al empezar, avisale esto: «Voy a crear una carpeta para tu negocio y a copiar unos manuales. La app te va a mostrar carteles pidiendo permiso: es normal, leé qué dice y tocá Permitir». Con ese aviso alcanza; no pidas un permiso aparte por cada archivo.

Para descomprimir y copiar usá la consola (en Windows, `Expand-Archive` y `Copy-Item`; en Mac, `unzip` y `cp -R`): copian cada archivo tal cual, sin cambiarle una letra. Para crear o editar un archivo (`CLAUDE.md`, `HOT.md`) usá tus herramientas de archivos, no la consola: así no se rompen las tildes.

## 0. Abrir el kit
Buscá en su carpeta Descargas un archivo `kit-de-0-a-100*.zip` o una carpeta `kit-de-0-a-100`. Si hay más de uno (por ejemplo `kit-de-0-a-100 (1).zip`), usá el más nuevo. Si es un zip, descomprimilo en una carpeta nueva dentro de la carpeta de trabajo actual. Si ya es una carpeta (en Mac pasa seguido, porque el navegador lo descomprime solo), no descomprimas nada: usala así. En Mac puede aparecer un cartel de la computadora pidiendo acceso a Descargas: avisale que toque Permitir. Adentro hay una carpeta `kit-de-0-a-100` con `cerebro`, `skills` y este archivo. El zip y esa carpeta se pueden borrar al terminar; preguntale antes.

## 1. Conocer a la persona
Preguntale, en un solo mensaje:
- Su nombre.
- En qué país vive y en qué país quiere vender.
- Si ya tiene un producto o arranca de cero.
- Cuánto tiempo por día le puede dedicar.
- Cuánta plata puede poner por día en anuncios, en dólares, sin que le duela perderla.

## 2. Instalar el cerebro
- Destino: la carpeta `cerebro` dentro de su carpeta de usuario. En Windows es `C:\Users\<su usuario>\cerebro`; en Mac, `/Users/<su usuario>/cerebro`. Averiguá la ruta real y usala completa de acá en adelante.
- Si no existe, copiá ahí todo el contenido de `cerebro` del kit.
- Copiá también `GUIA.md` (está en la raíz del kit) adentro de esa carpeta `cerebro`. Es la guía completa en texto.
- Si ya existe, no pises nada: copiá solo los archivos que falten y decile cuáles dejaste como estaban.

## 3. Instalar las skills
- Destino: la carpeta `.claude/skills` dentro de su carpeta de usuario (`C:\Users\<su usuario>\.claude\skills` o `/Users/<su usuario>/.claude/skills`). Creala si no existe. Es una carpeta oculta: es normal que ella no la vea.
- Copiá las 20 carpetas de `skills` del kit.
- Si ya hay una skill con el mismo nombre, mostrale cuál es y preguntale. Con su OK, renombrá la vieja agregándole `-anterior` y poné la del kit. Sin su OK, dejá la vieja y anotalo.

## 4. Decirle a Claude dónde está el cerebro
- Archivo: `CLAUDE.md` dentro de `.claude` en su carpeta de usuario.
- Si ya tiene un bloque «Mi negocio», no lo repitas: actualizá la ruta si cambió.
- Si el archivo no existe, crealo con el bloque de abajo. Si existe, mostrale el bloque y agregalo al final con su OK.
- Escribí la ruta COMPLETA y real, no una abreviada:

```
## Mi negocio
Mi cerebro está en <RUTA COMPLETA DE LA CARPETA cerebro>. Al empezar cualquier chat de trabajo, leé de esa carpeta CLAUDE.md y HOT.md antes de responder.
```

- Si dice que no quiere agregarlo, explicale que entonces al empezar cada chat tiene que escribir «leé mi cerebro en <ruta>», y seguí.

## 5. Dejar el tablero listo
En `HOT.md` completá: nombre, país donde vive, país donde vende, tiempo por día, presupuesto de anuncios por día, si ya tiene producto, y la fecha de hoy (día/mes/año). La meta por defecto es 100 dólares de ganancia por día; preguntale si la deja así.

## 6. Respaldo (opcional)
Explicale en una línea: «Un respaldo guarda una copia de tu cerebro cada vez que cambia, para que no se pierda nada».
- Fijate si tiene Git instalado. Si no lo tiene, no lo instales ahora: decile que el respaldo se puede sumar más adelante y pasá al paso 7.
- Si lo tiene: dentro de la carpeta del cerebro iniciá un repositorio. Si Git no tiene nombre y mail configurados, pedíselos y configuralos solo para esa carpeta. Hacé el primer guardado.
- GitHub solo si ella ya tiene cuenta y lo pide: repositorio PRIVADO, y el inicio de sesión lo hace ella. Si no tiene cuenta, el respaldo queda en su computadora y alcanza.
- Si algo falla, no insistas: anotalo para la tabla final y seguí.

## 7. Comprobar
1. Listá las skills que quedaron instaladas: tienen que ser 20 carpetas, cada una con su `SKILL.md`. En el cerebro tienen que estar los 8 archivos: 7 notas y `GUIA.md`.
2. Leé el `CLAUDE.md` del paso 4 y confirmá que la ruta escrita existe.
3. Leé `reglas.md` y respondé citándolo: «¿cuándo un anuncio es ganador?».
4. Mostrale una tabla con tres columnas: qué quedó instalado, qué se salteó y por qué, y qué falta. En «qué falta» van siempre estas tres cosas, hasta que estén hechas, cada una con su momento: el primer «buen día» (mañana), conectar la tienda (escalón 4) y conectar Meta Ads (escalón 6). Ninguna es para hoy.

## 8. Cerrar por hoy
Después de la tabla decile: «Listo por hoy. Mañana abrí un chat nuevo y escribí "buen día"».

Y frená ahí. No leas la guía entera, no le hagas más preguntas y no arranques ningún escalón: las preguntas que faltan y su paso a paso los hace la skill `buen-dia` la primera vez que ella escribe «buen día».

De ahí en más, cada día ella abre un chat y escribe «buen día».

## Lo que nunca hacés en la instalación
- Escribir o pedir contraseñas, tarjetas o claves.
- Crear cuentas a su nombre.
- Publicar, gastar o prender nada.
- Borrar o reemplazar archivos que ya tenía sin su OK.
