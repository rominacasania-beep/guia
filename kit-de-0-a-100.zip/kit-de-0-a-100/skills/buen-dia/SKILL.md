---
name: buen-dia
description: Arranque de cada día de trabajo. Usala cuando la persona escriba «buen día», «arranquemos», «qué hago hoy» o abra un chat sin un pedido claro. La primera vez completa el tablero y muestra el camino; después da el parte del día con el escalón actual y 3 prioridades.
---

# Buen día

Leé siempre, del cerebro: `HOT.md`, `reglas.md` y `decisiones.md`.

## Si es la primera vez (en HOT.md el escalón actual es 0)
1. Saludá por su nombre y explicá en dos líneas qué van a hacer.
2. Mirá la sección «Sobre mí» de `HOT.md`. Preguntá solo lo que esté vacío, de a una cosa por vez. Lo que falta casi siempre es el presupuesto de anuncios por día: «¿cuánto podés poner por día, en dólares, sin que te duela perderlo?».
3. Escribí las respuestas en `HOT.md` y cambiá el título a «Escalón actual: 1 · Elegir qué vender».
4. Mostrale los 12 escalones en una tabla corta y decile cuál es el paso de hoy.
5. Fijate si tiene conectados Meta Ads y la tienda. Si no, decile que no hace falta todavía: se conectan en los escalones 4 y 8.

## Todos los demás días
1. Si hay anuncios corriendo, traé los números de ayer y de hoy con la skill `leer-y-cortar`. Si no hay conexión con la tienda, pedile que los copie del panel y te los pegue.
2. Antes de proponer, leé en `errores.md` la fila del escalón en el que está.
3. Respondé con una sola tabla:

| Dónde estoy | Qué falta para pasar | Mis 3 prioridades de hoy |
|---|---|---|

4. Si ayer se tomó una decisión, completá la columna «qué pasó» en `decisiones.md`.
5. Preguntá: «¿Arrancamos por la primera?».

## Reglas
- Nunca más de 3 prioridades.
- Si falta un dato, decí que falta; no lo inventes.
- Los números salen de la tienda, no del panel de anuncios.
- Toda la plata se habla en dólares, salvo que ella pida otra moneda.
