---
name: leer-y-cortar
description: "Escalón 9. Lee cada mañana qué gastó y qué vendió cada anuncio, cruzando Meta con lo cobrado en la tienda, y propone qué apagar con la regla de corte. Usala cuando pidan «cómo van los anuncios», «qué apago», «leé la campaña», «números de hoy»."
---

# Leer y cortar

## Pasos
1. Traé de Meta, por anuncio: gastado hoy y acumulado.
2. Traé de la TIENDA las ventas cobradas, con su etiqueta de seguimiento para saber de qué anuncio vinieron.
3. Armá esta tabla:

| Anuncio | Gastado | Ventas cobradas | Costo por venta | Qué propongo |
|---|---|---|---|---|

4. Aplicá las reglas:
   - Gastó la mitad del precio del producto y no vendió → **apagar**.
   - Tiene 1 venta → **esperar**, no se decide con una.
   - Tiene 2 o 3 ventas → **va bien**, se deja.
   - Tiene 4 o más ventas pero lo cobrado no llega al doble de lo gastado → **vende caro**: se deja, no se escala.
   - 4 o más ventas cobradas y lo cobrado es más del doble de lo gastado → **ganador**. Anotalo en `HOT.md`: habilita el escalón 11.
5. Esperá su OK antes de apagar. Después de apagar, volvé a leer el estado para confirmar.
6. Anotá cada decisión en `decisiones.md` y los números del día en `HOT.md`, los dos del cerebro.

## Cómo se cuenta
- Las reglas se aplican sobre lo acumulado desde que salió el anuncio, no solo sobre hoy.
- Para saber de qué anuncio vino una venta se usa su etiqueta de seguimiento (`utm_content` trae el nombre del anuncio). Al cruzar con Meta, compará los nombres sin mirar mayúsculas, corchetes ni espacios.
- «Ventas» son las compras del producto principal. «Cobrado» es todo lo que entró, con los extras.
- Las ventas sin etiqueta van en una fila aparte.

## Si no hay conexión con Meta o con la tienda
Pedile que copie los números del panel y te los pegue, o que te mande una captura. No propongas nada con una sola de las dos fuentes.

## Pasa al escalón 10 cuando
Pasaron 3 días y apagó al menos un anuncio aplicando la regla. No hace falta tener ganador todavía.

## Reglas
- Antes de leer un número, comprobá que la cuenta y el conjunto estén entregando. Mucho gasto con cero ventas se revisa primero en el píxel.
- Los clics y el costo por clic sirven para saber qué arreglar del anuncio. Nunca para declararlo ganador ni para apagarlo.
- Algo que venía vendiendo no se apaga por un día flojo: se mira hoy más los 4 días anteriores.
- Mirá el anuncio real antes de opinar, no te guíes por su nombre.
- Las compras de prueba no se cuentan como ventas.
- Los primeros 3 días solo se aplica la regla de corte. Nada más se toca.
- Si la tienda y Meta no coinciden, vale la tienda. Decí la diferencia.
- Si no pudiste leer una de las dos fuentes, no propongas nada: decí qué faltó.
- Usá la hora del país donde vende para decir «hoy».
