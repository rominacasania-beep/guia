---
name: guardar
description: Guarda en el cerebro lo nuevo de este chat y hace el respaldo. Usala al cerrar una sesión de trabajo o cuando digan «guardá esto», «metele esto al cerebro», «que no se pierda», «cerremos por hoy».
---

# Guardar

## Pasos
1. Repasá el chat y juntá solo lo nuevo: decisiones, números del día, enlaces, cosas que quedaron pendientes.
2. Mostrá la lista y esperá el OK.
3. Escribí cada cosa en su lugar:
   - Estado de hoy y pendientes → `HOT.md` (máximo 40 líneas; lo viejo baja a `log.md`).
   - Decisiones → `decisiones.md`.
   - Lo que pasó hoy, en 3 líneas → arriba de `log.md`, con la fecha.
4. No dupliques: si ya está anotado, actualizá esa línea.
5. Si la carpeta del cerebro tiene respaldo con Git, hacé un guardado con la fecha y un resumen de una línea. Si además está conectada a GitHub, subilo. Si falla, avisá y seguí.
6. Respondé con una tabla de qué se guardó y dónde.

## Reglas
- Nunca guardes contraseñas, tokens ni datos de tarjetas.
- No borres notas viejas: movelas.
- Lo que fue solo charla no se guarda.
