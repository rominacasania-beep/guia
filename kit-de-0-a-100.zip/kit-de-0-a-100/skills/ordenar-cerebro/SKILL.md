---
name: ordenar-cerebro
description: "Limpieza semanal del cerebro: acorta el tablero, mueve lo viejo a la bitácora y detecta notas repetidas o contradictorias. Usala una vez por semana o cuando digan «ordená el cerebro», «está todo desordenado», «limpiá las notas»."
---

# Ordenar el cerebro

## Pasos
1. Leé todos los archivos de la carpeta del cerebro.
2. Buscá:
   - `HOT.md` con más de 40 líneas.
   - Cosas repetidas en dos notas.
   - Reglas que se contradicen.
   - Pendientes viejos que ya se hicieron.
   - Filas de `decisiones.md` sin «qué pasó».
3. Mostrá lo encontrado en una tabla y qué harías con cada cosa.
4. Con el OK: mové lo viejo a `log.md`, uní lo repetido, completá lo que falta.
5. Hacé el respaldo.

## Reglas
- Arreglá lo que existe. No crees notas nuevas ni borres ninguna.
- Si dos reglas se contradicen, no elijas vos: preguntá.
