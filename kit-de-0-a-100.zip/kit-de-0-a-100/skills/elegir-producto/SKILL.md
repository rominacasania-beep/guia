---
name: elegir-producto
description: "Escalón 1. Busca en la Biblioteca de Anuncios de Meta qué productos digitales se están vendiendo y devuelve 5 ofertas comparadas. Usala cuando pidan «qué vendo», «buscame un producto», «ideas de productos» o «qué se está vendiendo en [nicho]». Solo lectura: no crea ni gasta nada."
---

# Elegir qué vender

## Antes de buscar
Preguntá el nicho y el país. Si dice «sorprendeme», proponé 3 nichos de esta lista y que elija: bienestar emocional, crianza y niños, espiritualidad, oficios y manualidades, cocina, estudio, plata y negocio, mascotas.

## Antes de buscar: el navegador
La búsqueda se hace en su Chrome. Si no podés abrir el navegador, frená: guiala para conectarlo (que te escriba «ayudame a conectar Chrome») y probá con «abrí google.com». No sigas de memoria ni armes la tabla con ofertas que no viste.

## Buscá por otra puerta
Para la búsqueda en sí, seguí la skill `busqueda-unica-romi` (palancas, reglas y tabla). Lo de abajo es el resumen.

Si buscás «ebook» o «journal» como todo el mundo, encontrás lo mismo que todo el mundo. Antes de abrir la Biblioteca, armá la búsqueda con 6 palancas (si la persona trae el pedido del generador de la guía, usá esas):
1. **Puerta**: un dolor, un deseo, un oficio, algo que se vende en papel, una fecha, un problema de la casa.
2. **Nicho**: uno o dos cruzados (por ejemplo crianza + cocina).
3. **Palabras**: como las escribiría una página de venta de ese país («para imprimir», «paso a paso», «en 21 días»), traducidas al idioma.
4. **A quién**: la persona que compra (abuelas, maestras, mamás…). El mismo tema para otra persona es otro mercado.
5. **Formato**: diario guiado, plan de días, recetario, planos, plantillas, kit para imprimir.
6. **Idioma**: lo lleno en un idioma puede estar vacío en otro.
Si una combinación no trae nada, cambiá una sola palanca y probá de nuevo.

## Cómo buscar
1. Abrí la Biblioteca de Anuncios (facebook.com/ads/library) en el navegador, con el país elegido y «Todos los anuncios».
2. Probá 5 a 8 palabras del nicho, en el idioma del país.
3. De cada resultado mirá: cuántos anuncios activos tiene esa página, desde cuándo corre el más viejo y a qué página lleva.
4. Abrí la página de venta y anotá el precio y la promesa.

## Qué descartar
- Productos físicos o con envío.
- Cursos caros o con una persona famosa detrás.
- Ofertas que anuncia una sola página.
- Anuncios con menos de 2 semanas.

## Qué entregar
Una tabla con 5 ofertas:

| # | Qué vende | Precio | Anuncios activos | Anunciantes distintos | Días del anuncio más viejo | Enlace | Nota 1–10 |
|---|---|---|---|---|---|---|---|

Debajo, una línea con tu recomendación y por qué.

## Pasa al escalón 2 cuando
Eligió una oferta con 20 o más anuncios activos y al menos 3 anunciantes distintos. Anotá la elegida en `HOT.md` del cerebro.

## Reglas
- Sumá a la búsqueda palabras de formato: «imprimible», «descarga inmediata», «PDF».
- Si no aparece nada, cambiá las palabras y probá en otros dos idiomas antes de decir que nadie lo vende.
- Contá por oferta, no por página: diez páginas con el mismo producto son una sola oferta fuerte.
- Descartá suscripciones, catálogos enormes y todo lo que use marcas registradas.
- Si el producto es de temporada, anotá cuándo empieza y cuándo termina su ventana. Fuera de ella no se lanza.
- Mirá dos números juntos: días del anuncio más viejo y anuncios prendidos. Uno solo no prueba nada.
- Que no lo venda nadie no es una oportunidad: la Biblioteca no muestra lo que fracasó.
- Modelá al original (el de más días y más anuncios), no a sus copias.
- Antes de recomendar, entrá hasta la página donde se paga: a veces lo de afuera no es lo que se vende.
- En la tabla, cada oferta lleva el link al anuncio y el link a la página del anunciante en la Biblioteca.
- Lo que no pudiste comprobar, decilo.
- No recomiendes por gusto: recomendá por lo que se ve vendiéndose.
