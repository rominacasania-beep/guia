---
name: elegir-producto
description: Escalón 1. Busca en la Biblioteca de Anuncios de Meta qué productos digitales se están vendiendo y devuelve 5 ofertas comparadas. Usala cuando pidan «qué vendo», «buscame un producto», «ideas de productos» o «qué se está vendiendo en [nicho]». Solo lectura: no crea ni gasta nada.
---

# Elegir qué vender

## Antes de buscar
Preguntá el nicho y el país. Si dice «sorprendeme», proponé 3 nichos de esta lista y que elija: bienestar emocional, crianza y niños, espiritualidad, oficios y manualidades, cocina, estudio, plata y negocio, mascotas.

## Cómo buscar
1. Abrí la Biblioteca de Anuncios (facebook.com/ads/library) en el navegador, con el país elegido y «Todos los anuncios».
2. Probá 5 a 8 palabras del nicho, en el idioma del país.
3. De cada resultado mirá: cuántos anuncios activos tiene esa página, desde cuándo corre el más viejo y a qué página lleva.
4. Abrí la página de venta y anotá el precio y la promesa.

## Qué descartar
- Productos físicos o con envío.
- Cursos caros o con una persona famosa detrás.
- Ofertas que anuncia una sola página.
- Anuncios con menos de 2 semanas.

## Qué entregar
Una tabla con 5 ofertas:

| # | Qué vende | Precio | Anunciantes distintos | Días del anuncio más viejo | Enlace | Nota 1–10 |
|---|---|---|---|---|---|---|

Debajo, una línea con tu recomendación y por qué.

## Pasa al escalón 2 cuando
Eligió una oferta que anuncian al menos 3 páginas distintas, con anuncios de varias semanas. Anotá la elegida en `cerebro/HOT.md`.

## Reglas
- Sumá a la búsqueda palabras de formato: «imprimible», «descarga inmediata», «PDF».
- Si no aparece nada, cambiá las palabras y probá en otros dos idiomas antes de decir que nadie lo vende.
- Contá por oferta, no por página: diez páginas con el mismo producto son una sola oferta fuerte.
- Descartá suscripciones, catálogos enormes y todo lo que use marcas registradas.
- Si el producto es de temporada, anotá cuándo empieza y cuándo termina su ventana. Fuera de ella no se lanza.
- Lo que no pudiste comprobar, decilo.
- No recomiendes por gusto: recomendá por lo que se ve vendiéndose.
