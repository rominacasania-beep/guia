---
name: plan-de-escala
description: Arma el plan de escala del día con los tres motores (renovar lo que vende, escalar con plan escrito, abrir un mercado nuevo). Usala cuando pidan «plan de escala», «cómo crezco», «qué motor falta hoy», o cuando ya hay ventas todos los días.
---

# Plan de escala

Los tres motores corren a la vez. Cada día revisá los tres y decí primero el que está en falta.

| Motor | Cada cuánto | Skill |
|---|---|---|
| Renovar lo que ya vende | Todos los días | `renovar` |
| Escalar con plan escrito | Todos los días | `escalar` |
| Abrir un mercado nuevo | Cada 2 o 3 días | `abrir-pais` |

## El parte del día
1. Por país: ventas cobradas hoy y en los 4 días anteriores, y gasto.
2. Para cada país, una propuesta: subir, mantener, bajar o apagar, con el motivo.
3. ¿Salió la renovación de hoy? Si no, es lo primero.
4. ¿Cuándo se abrió el último mercado? Si pasaron más de 3 días, proponé el siguiente.

| País | Hoy | 4 días | Gasto | Propongo | Por qué |
|---|---|---|---|---|---|

## Reglas
- Todo sale de la tienda, no del panel de anuncios.
- Un país nuevo que gasta y no vende en pocos días se apaga. Anotalo con el monto y el motivo: los apagados también enseñan.
- Antes de recomendar un país, revisá en `cerebro/decisiones.md` que no se haya probado y apagado ya.
- No cambies nada sin OK.
