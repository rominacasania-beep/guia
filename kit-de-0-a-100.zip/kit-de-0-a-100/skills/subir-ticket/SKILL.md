---
name: subir-ticket
description: Escalón 11. Con un anuncio ganador, arma la oferta que aparece después de la compra para que cada venta deje más. Usala cuando pidan «oferta post-compra», «upsell», «que cada venta deje más», «subir el ticket».
---

# Subir lo que deja cada venta

## Condición
Solo si hay ganador: 4 o más ventas cobradas y lo cobrado es más del doble de lo gastado. Si no hay, decí que todavía no toca.

## La escalera
| Momento | Oferta | Precio |
|---|---|---|
| En el checkout | Un extra chico y relacionado | Un tercio del precio o menos |
| Después de pagar | «Más de lo mismo»: la versión ampliada o el complemento natural | 1,4 veces el precio |
| Si la rechaza | La misma, rebajada | La mitad |

## Pasos
1. Proponé qué ofrecer en cada lugar, con nombre y precio. Que elija.
2. Si el producto extra no existe, armalo con `armar-producto`.
3. Cargalo en la tienda y mostralo antes de activarlo.
4. Pedile una compra de prueba para ver la oferta aparecer.
5. Medí 7 días: cuántas compras aceptaron la oferta.

## Reglas
- Primero se sube lo que deja cada venta y después la cantidad de ventas. Hacé la cuenta con `numeros.md`: cuántas ventas por día necesita con cada ticket.
- Se cambia una oferta por vez y se mide una semana antes de tocar otra.
- La oferta tiene que tener sentido con lo que acaba de comprar.
- Sin presión falsa: nada de «última oportunidad» si no lo es.
- El precio lo decide ella.

## Pasa al escalón 12 cuando
Cada venta deja, en promedio, cerca de 1,5 veces el precio de entrada.
