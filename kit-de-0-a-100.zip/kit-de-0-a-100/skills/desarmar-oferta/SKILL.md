---
name: desarmar-oferta
description: "Escalón 2. Analiza la página de venta de una oferta ajena para entender su estructura, precio y extras, sin copiar nada. Usala cuando pasen un enlace y pidan «analizá esta página», «desarmá esta oferta» o «cómo vende esto»."
---

# Desarmar una oferta

## Pasos
1. Comprobá que es la página real: abrí 2 o 3 anuncios de esa oferta en la Biblioteca y fijate a qué enlace llevan. Si llevan a otra página, analizá esa.
2. Recorré la página de arriba abajo y anotá el orden de las secciones.
3. Tocá el botón de compra y mirá el checkout: precio, extras que se suman con un clic, medios de pago.
4. Si podés ver qué ofrece después de pagar sin comprar, anotalo. Si no, decí que no se puede ver.

## Qué entregar

| Parte | Qué tiene |
|---|---|
| Promesa principal | |
| A quién le habla | |
| Orden de la página | |
| Precio y precio tachado | |
| Extras en el checkout | |
| Lo que parece falso | (reseñas, contadores, «quedan 3») |

Y al final: «Para tu producto yo haría esto distinto: …» con 3 mejoras.

## Reglas
- Se toma la estructura. Nunca textos, imágenes, nombres ni testimonios.
- No recomiendes copiar trucos falsos (escasez inventada, reseñas falsas).
- Guardá el resumen en la carpeta del cerebro con el nombre `oferta-modelo.md`.

## Pasa al escalón 3 cuando
Sabe qué vende la oferta, a cuánto y con qué extras.
