---
name: armar-landing
description: Escalón 5. Escribe y arma la página de venta corta (300 a 800 palabras) y la revisa a ancho de celular. Usala cuando pidan «hacé la landing», «la página de venta», «escribí la página».
---

# Armar la landing

## Estructura
1. Titular con el dolor principal, dicho con palabras de la clienta.
2. Tres dolores más, en frases cortas.
3. Qué es el producto y qué trae adentro (con imágenes reales de sus páginas).
4. Para quién es y para quién no.
5. Qué recibe al comprar y cómo le llega.
6. Preguntas frecuentes (4 a 6).
7. Botón de compra arriba, en el medio y al final.

## Reglas
- La landing no muestra el precio: aparece recién en el checkout.
- Sin testimonios inventados. Si no hay reales, no se ponen.
- Sin contadores falsos ni «quedan 3».
- Sin promesas de resultado.
- Frases cortas. Nada que suene a traducción o a robot.

## Revisión
1. Abrí la página a 390 px de ancho (tamaño de celular).
2. Comprobá: nada se sale por los costados, ninguna imagen rota, el botón se ve sin hacer scroll largo.
3. Tocá el botón: tiene que llevar al checkout correcto.
4. Pasale el enlace para que la lea en su celular.

## Pasa al escalón 6 cuando
La leyó en el celular y el botón lleva al checkout.
