---
name: armar-tienda
description: "Escalón 4. Deja la tienda lista para cobrar y entregar: producto, precio, checkout limpio y entrega automática, sin ofertas extra (van en el escalón 11). Usala cuando pidan «armá la tienda», «cargá el producto», «configurá el checkout»."
---

# Armar la tienda

## Antes de empezar
- Comprobá que hay una llave (conector) a la plataforma de venta. Si no la hay, guiá a la persona paso a paso en el panel y que ella haga los clics.
- La cuenta y el cobro los configura ella. Nunca recibas ni escribas claves de cobro.
- La aprobación del cobro puede tardar de minutos a varios días. Decile que la empiece cuanto antes, el mismo día que elige el producto.

## Pasos
1. Crear el producto con nombre, precio y moneda.
2. Cargar la entrega: el PDF subido a una carpeta en la nube con enlace público comprobado (abrilo en una ventana sin sesión).
3. Checkout limpio: pedir solo el mail, un solo botón de pago. Arriba, el resumen y una imagen con todo lo que se lleva. Sin carteles de «X personas comprando».
4. Sin ofertas extra por ahora: se suman en el escalón 11, cuando haya un ganador.
5. Mostrale cada cambio antes de aplicarlo.

## Comprobación obligatoria
Pedile que haga una compra de prueba con su propio mail. Paga de verdad, con su tarjeta, y después se lo devuelve desde la tienda: decile dónde. Verificá con ella: llegó el mail, el enlace abre, el PDF es el correcto.

## Reglas
- Los regalos van en la misma carpeta de entrega del producto, no cargados como productos aparte.
- Una cosa es regalo o es extra pago. Nunca las dos a la vez.
- Si un cambio queda «pendiente de aprobar» en el panel, todavía no está hecho: decíselo y pasale el enlace.
- No digas cómo se ve la tienda sin haberla abierto.

## Pasa al escalón 5 cuando
La compra de prueba funcionó de punta a punta. Anotá el enlace de la tienda en `HOT.md` del cerebro.
