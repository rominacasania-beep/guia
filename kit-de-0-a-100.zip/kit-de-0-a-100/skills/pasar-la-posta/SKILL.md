---
name: pasar-la-posta
description: "Cierra un chat que se hizo largo y deja un resumen para seguir en uno nuevo sin perder nada. Usala cuando el chat esté lento o muy largo, o cuando digan «sigamos en otro chat», «cerrá este chat», «pasá la posta»."
---

# Pasar la posta

## Pasos
1. Corré `guardar` para que lo nuevo quede en el cerebro.
2. Escribí un resumen de no más de 15 líneas:
   - Qué estábamos haciendo y para qué.
   - Qué quedó hecho (con enlaces o rutas).
   - Qué falta, en orden.
   - Decisiones que ya tomó y no hay que volver a preguntar.
3. Guardalo en `posta.md`, en la carpeta del cerebro (reemplaza al anterior).
4. Decile: «Abrí un chat nuevo y escribí: seguí desde la posta».

## Al recibir «seguí desde la posta»
Leé del cerebro `posta.md`, `HOT.md` y `reglas.md`, decí en 3 líneas dónde quedamos y seguí con el primer pendiente.
