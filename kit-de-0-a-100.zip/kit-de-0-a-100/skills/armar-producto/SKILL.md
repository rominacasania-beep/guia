---
name: armar-producto
description: Escalón 3. Crea el producto digital (ebook, cuaderno o kit en PDF) con nombre, índice, contenido completo y el pedido de imagen para la portada. Usala cuando pidan «armemos el producto», «escribí el ebook», «haceme el PDF».
---

# Armar el producto

## Pasos
1. Leé `cerebro/oferta-modelo.md` si existe.
2. Preguntá: tema, a quién va dirigido y qué resultado concreto le deja.
3. Proponé 3 nombres y un precio de entrada. Que elija.
4. Mostrá el índice y esperá el OK antes de escribir.
5. Escribí el contenido completo, propio, sin copiar de la oferta modelo.
6. Generá el PDF en la carpeta de trabajo y decí dónde quedó.
7. Abrí el PDF y revisá vos misma: que no haya páginas en blanco, texto cortado ni títulos sueltos al final de una hoja.
8. Escribí el pedido de imagen para la portada, listo para pegar en un generador de imágenes: título exacto, estilo, colores y formato vertical.

## Reglas
- Todo el PDF en un solo tamaño de hoja: A4 vertical.
- Lo que después muestre el anuncio tiene que estar adentro del PDF. Antes de publicar, abrí páginas al azar y comprobalo.
- Contenido útil de verdad: ejercicios, plantillas, pasos. Nada de relleno.
- Sin promesas de salud, plata o resultados garantizados.
- Sin nombres de marcas ni personas reales.
- Si el producto toca salud emocional, se presenta como apoyo y autocuidado, nunca como terapia.

## Pasa al escalón 4 cuando
La persona leyó el PDF entero y dijo que está bien. Anotá nombre y precio en `cerebro/HOT.md`.
