---
name: abrir-pais
description: "Lleva un producto en PDF que ya vende a un país e idioma nuevo, de punta a punta: validación en la Biblioteca de Anuncios, guía de estilo del país, clienta ideal, ficha del país, traducción de los PDF con el motor (mismo diseño), entrega, tienda con moneda y precio local, pagos, extras y post-compra, landing, página de Facebook, píxel, anuncios y lista final con prueba. Usala cuando pidan «abramos [país]», «llevemos mi producto a [idioma]», «próximo país», «traducí mi producto». NO elige el país por ella, NO prende campañas ni gasta sin su OK, y NO escribe contraseñas."
---

# Abrir un país

Solo para un producto que **ya tiene ganador** en su idioma. Seguí las etapas en orden y no saltees la 1.
La guía paso a paso que ve ella está en `GUIA-OTRO-IDIOMA.md` (en su carpeta del cerebro). El motor de PDF está en `motor-pdf`, dentro de su carpeta de usuario (se copió al instalar el kit; si no está, buscalo en el kit descargado).

Sus datos (tienda, dominio, carpeta de entrega, cuenta de anuncios, nombre de soporte) están en el cerebro: `HOT.md` y `decisiones.md`. Si falta alguno, preguntale una sola vez y anotalo.

| # | Etapa | Qué queda hecho | Skill | Quién decide |
|---|---|---|---|---|
| 0a | Accesos | Tabla ✅ / ❌ con la prueba de cada uno | abajo | Vos |
| 0 | Arranque | País, idioma, precio local, nombre, extras, tope de gasto | abajo | Ella |
| 1 | Biblioteca de Anuncios | Semáforo + `BIBLIOTECA_<XX>.md` | abajo | Vos; ella si da 🟡 |
| 2 | Cómo hablan allá | `GUIA_ESTILO_<XX>.md` con frases reales | abajo | Vos |
| 3 | Clienta ideal | `CLIENTE_IDEAL_<XX>.md` con 10 dolores | abajo | Vos |
| 4 | Ficha del país | `PAIS_<XX>.md` («pasaporte») | abajo | Ella elige nombre y precio |
| 5 | Traducción de los PDF | Mismo diseño, 2 revisiones, controles en cero | abajo + `motor-pdf/LEEME.md` | Vos |
| 6 | Entrega | Carpeta por producto, enlace comprobado sin sesión | `armar-tienda` | Vos |
| 7 | Tienda | Idioma, dominio, moneda y precio fijo local, checkout limpio, legales | `armar-tienda` | Ella aprueba |
| 8 | Pagos | Cobros activos en la moneda del país | `armar-tienda` | Ella los conecta |
| 9 | Extras y post-compra | Con archivo cargado y todos los caminos probados | `subir-ticket` | Ella aprueba precios |
| 10 | Landing | Dolores arriba, revisada en el celular | `armar-landing` | Ella da el OK |
| 11 | Página de Facebook | Nombre en el idioma, fotos, 4 publicaciones | `pagina-y-pixel` | Ella da los clics |
| 12 | Píxel | Conectado y probado | `pagina-y-pixel` | Ella pega la clave |
| 13 | Anuncios | Campaña en pausa | `anuncios` y `campana-de-prueba` | Vos |
| 14 | Lista final | Cada renglón con su prueba | abajo | Ella da el OK |

## Carpeta del país
`[PRODUCTO] [PAÍS] [IDIOMA]`, con nombre en español; los archivos de adentro, en su idioma. Desde el minuto cero, `ESTADO.md`: qué se hizo, qué se decidió, qué falló y la prueba de cada renglón. Si la sesión se corta, se retoma desde ahí.

## Etapa 0a · Accesos (solo lectura, antes de preguntar nada)
Una línea por acceso con la prueba. Si algo falla, se para y se avisa: no se arranca a medias.
- La tienda responde y cobra.
- La cuenta de anuncios está activa y sin deuda.
- El navegador tiene sesión en la tienda, en el proveedor del dominio y en Facebook.
- La carpeta de entrega es accesible.
- La computadora es **Windows** (el motor no corre en Mac) y Python responde. Si falta Python o las librerías, guiala para instalarlos (ver `motor-pdf/LEEME.md`).

Si es Mac: decíselo claro. Todo lo demás de esta skill sirve igual; la traducción de los PDF no se puede hacer con este motor.

## Etapa 0 · Un solo mensaje con lo que falta
- Idioma exacto y a quién se apunta (no es lo mismo Portugal que Brasil).
- Precio en moneda local y tachado.
- Nombre del producto en el idioma: proponé 3 con palabras de todos los días allá. Elige ella.
- Extras del checkout y post-compra: cuáles y a qué precio.
- Tope de gasto de la prueba.

## Etapa 1 · Biblioteca de Anuncios (OBLIGATORIA)
Antes de traducir nada. Buscá **el mismo producto y productos parecidos**, en varios idiomas y en el país destino.

| Color | Cuándo | Qué se hace |
|---|---|---|
| 🟢 | 2 o más idiomas o países, anuncios de 30 días o más, 3 o más anunciantes | Se lanza |
| 🟡 | 2 o más idiomas, pero 14 a 30 días o un solo anunciante. También si ya hay competencia directa allá | Decide ella |
| 🔴 | Un solo idioma, o ningún anuncio llega a 14 días | No se lanza. Se avisa |

Por anunciante: días activos, ganchos, ángulos, formato, precio, oferta, extras y página real. Dejá `BIBLIOTECA_<XX>.md` con los 10 mejores con enlace. **Sin este archivo no se escribe clienta ideal, landing ni anuncios.** Confirmá también que su plataforma de cobro funciona hoy en ese país y en esa moneda.

## Etapa 2 · Cómo hablan allá
Mínimo **15 fuentes reales con enlace, de al menos 5 tipos**: blogs y revistas del tema, foros, reseñas de productos parecidos, comentarios de redes del nicho, anuncios de la competencia local.
`GUIA_ESTILO_<XX>.md`: trato (tú, usted o equivalente), ortografía, glosario, expresiones naturales, qué evitar, 5 nombres de producto y un **banco de frases reales copiadas tal cual**. La usan la traducción, la landing, los anuncios y la página de Facebook.

## Etapa 3 · Clienta ideal
`CLIENTE_IDEAL_<XX>.md`: quién es, **10 dolores con una frase real cada uno**, qué ya probó, qué desea, por qué desconfía de comprar por internet allá, fechas fuertes y tabúes, y **un gancho de anuncio por dolor**. Con la traducción al español al lado, para que ella lo pueda leer.

## Etapa 4 · Ficha del país («pasaporte»)
`PAIS_<XX>.md`, reusable para el próximo producto que vaya allá: idioma y variante, moneda, precio con tachado, medios de pago que se usan allá, garantía legal y lo que la ley pide en el pie de la tienda (**buscado en la web, con la fuente al lado, nunca de memoria**), fechas fuertes, día en que empieza la semana, nombre elegido, tienda, dominio, página, píxel y qué salió mal. Se actualiza al cerrar.

## Etapa 5 · Traducción de los PDF (motor)
Leé `motor-pdf/LEEME.md` entero y seguilo. Resumen:
1. Copiá la carpeta `motor-pdf` a la carpeta del país. `config.json` con sus PDF, el nombre final de cada uno y su marca (**cada palabra por separado y todo junto**).
2. `paginas.py` → `bloques.py` → mirá las hojas de revisión → `preparar.py`.
3. Brief con `BRIEF_PLANTILLA.md` + la guía de estilo. Largo máximo 1,25 veces el original.
4. Traducción repartida en ayudantes en paralelo (unas 30.000 letras cada uno). Se reescribe, no se traduce palabra por palabra.
5. **Dos revisoras nativas en contexto limpio** que marquen lo que suena a traducción y corrijan.
6. `chequeo.py` en cero → `final.py` → `verificar.py` (probado roto a propósito) → mirar cada página.
7. Siempre el aviso: «revisado con IA, falta una persona nativa».

Contenido: su nombre, su marca y sus fotos no viajan si vende sin cara · lo que no viaja (religión, marcas ajenas, billetes, frases en otro idioma) se saca, preguntando antes · fechas y semana como se usan allá.
Avisale que traducir muchos PDF gasta bastante uso de Claude: si llega al límite, se sigue cuando se recarga, desde `ESTADO.md`.

## Etapas 6 a 13
Seguí las skills de la tabla, con estas reglas del país nuevo:
- **Entrega:** carpeta del país › una subcarpeta por producto, «cualquiera con el enlace». Los regalos van dentro, no como productos sueltos. Enlace probado sin sesión. Sin esto no se pauta.
- **Tienda:** en el idioma, con zona horaria del país. Subdominio revisado antes (que no esté usado); el DNS lo carga ella. Precio fijo elegido directo en la moneda local, comprobado en el checkout visto como alguien de ese país. Checkout que pide solo el correo y con todos los rótulos traducidos. Legales en el idioma; los datos de su empresa los pone ella, nunca inventados. Lo que sobra se borra, no se deja en borrador. Si reusa una tienda: respaldo antes, y lo ya vendido se oculta, no se borra.
- **Pagos:** los conecta ella. Confirmá que cobran en esa moneda.
- **Extras y post-compra:** un extra nunca queda visible sin su archivo. Embudo en pausa hasta tener todo cargado. Recorré todo «no», todo «sí» y mezclado.
- **Landing:** testimonios solo reales, traducidos, sin nombres, aclarando que vienen de la versión original. Nada de contadores ni «alguien acaba de comprar».
- **Página de Facebook:** perfil y portada distintas, 4 publicaciones revisadas por la revisora nativa. Si tiene una página sin uso, conviene renombrarla.
- **Píxel:** propio del país. La clave de la API de conversiones la pega ella, directo en la tienda.
- **Anuncios:** primero sus mejores anuncios ya probados, traducidos; después uno por dolor. Con el producto real. Zoom a cada texto de cada imagen. Idioma y país en el nombre del archivo. Público: país + idioma. Si duplicás anuncios de otro país, revisá el enlace. En la Unión Europea, beneficiario y pagador en cada conjunto. No hagas otros cambios en la cuenta mientras cargás una tanda. Campaña **en pausa**.

## Etapa 14 · Lista final, con prueba por renglón
Un renglón sin prueba (herramienta, enlace o captura) no está hecho.
- [ ] Semáforo 🟢, o 🟡 aceptado por ella
- [ ] PDF traducidos, revisados dos veces, controles en cero y mirados página por página
- [ ] Todos los PDF abren y descargan desde el enlace, sin sesión
- [ ] Dominio verificado con candado
- [ ] Checkout en el idioma, con moneda y precio correctos
- [ ] Cobros activos en esa moneda
- [ ] Extras con su archivo; post-compra recorrida por todos los caminos
- [ ] Compra de prueba de punta a punta, si ella la quiere hacer
- [ ] Landing leída en el celular
- [ ] Píxel registra visita en landing y checkout; clave de conversiones cargada
- [ ] Página de Facebook con fotos y 4 publicaciones
- [ ] Anuncios revisados a tamaño real, con etiquetas de seguimiento
- [ ] Campaña en pausa

Informe en 5 líneas: qué quedó, enlace, qué falta de ella, lo elegido y «¿la prendo?». Después sumá lo aprendido a `PAIS_<XX>.md` y a `decisiones.md`.

## Reglas
- Nada se publica, se prende ni se gasta sin su OK.
- Nunca escribas contraseñas, claves ni tarjetas.
- Lo que no puedas comprobar, decilo.
- Un control automático se prueba roto a propósito antes de creerle.
- Un país por vez.
- Si a los 4 días gastó y no vendió, se apaga y se anota en `decisiones.md` con el motivo.
