---
name: abrir-pais
description: "Lleva un producto que ya vende a un país e idioma nuevo, en 13 etapas: validación en la Biblioteca, investigación de cómo hablan, traducción nativa, tienda, ofertas, landing, página, píxel y anuncios. Usala cuando pidan «abramos [país]», «llevemos el producto a [idioma]», «próximo país»."
---

# Abrir un país

Solo para un producto que ya tiene ganador. Seguí las etapas en orden y no saltees la 1.

| # | Etapa | Qué queda hecho | Skill | Quién decide |
|---|---|---|---|---|
| 0 | Arranque | Producto, país e idioma | — | Ella |
| 1 | Biblioteca de Anuncios | Semáforo de validación | abajo | Vos |
| 2 | Cómo hablan allá | Guía de estilo con frases reales | abajo | Vos |
| 3 | Clienta ideal | 10 dolores con sus palabras | abajo | Vos |
| 4 | Traducción nativa | Producto y extras, mismo diseño, 2 revisiones. Nombre local (proponé 3) | abajo | Ella elige el nombre |
| 5 | Entrega | Carpeta por producto, enlace comprobado | `armar-tienda` | Vos |
| 6 | Tienda | Idioma, moneda y precio local, cobro, checkout, compra de prueba | `armar-tienda` | Ella aprueba y fija el precio |
| 7 | Ofertas extra | Extras y post-compra | `subir-ticket` | Ella aprueba |
| 8 | Landing | Dolores arriba, revisada en celular | `armar-landing` | Vos |
| 9 | Página de Facebook | Nombre en el idioma, publicaciones | `pagina-y-pixel` | Ella da los clics |
| 10 | Píxel | Conectado y probado | `pagina-y-pixel` | Ella pega el token |
| 11 | Anuncios | 5 anuncios, campaña en pausa | `anuncios` y `campana-de-prueba` | Vos |
| 12 | Antes de prender | Lista de control de abajo | — | Ella da el OK |

## Etapa 1 · semáforo
Buscá el producto y otros parecidos, en varios idiomas y en el país destino.

| Color | Cuándo | Qué se hace |
|---|---|---|
| Verde | Se vende en 2 o más idiomas, con anuncios de 30 días o más y 3 o más anunciantes | Se lanza |
| Amarillo | Todo lo que no es verde ni rojo. También si ya hay competencia directa en el país destino | Se puede lanzar; se vuelve a mirar cada semana |
| Rojo | Se vende en un solo idioma, o ningún anuncio llega a 14 días | No se lanza |

## Etapa 2 · cómo hablan
Leé al menos 15 fuentes reales del país (foros, reseñas, comentarios, anuncios locales). Anotá: cómo se tratan (de tú, de usted o equivalente), qué palabras usan para el problema, y formatos propios (fechas, moneda, día en que empieza la semana).

## Etapa 3 · clienta ideal
Con esas fuentes, escribí 10 dolores con sus palabras. Para los anuncios de la etapa 11 elegí los 5 más repetidos.

## Etapa 4 · traducción
- Se reescribe, no se traduce palabra por palabra.
- Dos revisiones «nativas» en limpio, que marquen lo que suena a traducción.
- Comprobá que la tipografía tenga las letras de ese idioma.
- Revisá los PDF finales buscando restos del idioma original.

## Etapa 12 · lista de control
- [ ] Semáforo verde o amarillo
- [ ] Producto traducido y revisado dos veces
- [ ] Compra de prueba hecha en la tienda del país
- [ ] Landing leída en el celular
- [ ] Píxel registrando visitas y una compra de prueba registrada como Compra
- [ ] 5 anuncios revisados a tamaño real
- [ ] Campaña en pausa, con inicio a las 00:00

## Reglas
- Antes de traducir nada, confirmá que la plataforma de cobro funciona hoy en ese país.
- El precio se elige directo en la moneda local, con un número que allá se vea normal. Comprobá que el checkout muestre esa moneda.
- Los testimonios son los reales, traducidos, sin nombres y aclarando que vienen de la versión original.
- Al país nuevo van primero los mejores anuncios ya probados, traducidos. Después, los nuevos.
- Un solo idioma por pieza. Buscá restos de la marca o del idioma original en cada hoja.
- Público: país + idioma, nada más.
- Si a los 4 días gastó y no vendió, se apaga y se anota en `decisiones.md` con el motivo.
- Nada se prende sin su OK.
