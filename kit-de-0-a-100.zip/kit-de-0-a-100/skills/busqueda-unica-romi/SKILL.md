---
name: busqueda-unica-romi
description: Busca productos digitales que ya se venden con anuncios en la Biblioteca de anuncios de Meta, entrando «por otra puerta» (6 palancas que cruzan puerta, nicho, palabras, a quién, formato e idioma) para no encontrar lo mismo que todos, y los valida con 5 reglas. Es «La búsqueda única» de RomiManifiesta (Bono 5 de la guía «De 0 a 100 por día»). Usar cuando diga "búsqueda única", "buscame un producto", "qué puedo vender", "qué está funcionando en la Biblioteca", "analizá este nicho" o pegue un pedido de «La búsqueda única». Solo lee: no toca campañas ni compra nada.
---

# La búsqueda única · RomiManifiesta

Encontrá productos digitales que otros ya venden con anuncios, para que el usuario elija uno y lo haga mejor. Vos buscás; el producto lo elige él.

**La idea de fondo:** si buscás «ebook» o «journal» como todo el mundo, encontrás los mismos diez productos que todo el mundo, y ese mercado se llena en semanas. Por eso no buscás más horas: entrás **por otra puerta**, cruzando cosas que casi nadie cruza.

## 1. Armá la búsqueda, todo en un mensaje

Si el usuario pegó un pedido de «La búsqueda única» («Puerta: … Nicho: … Palabras: …»), usalo tal cual y pasá al paso 2. Si no, mostrale estas 6 palancas como opciones para tocar (lista numerada, nunca campos vacíos) y que elija una por fila, o «sorteá vos»:

| Palanca | Opciones |
|---|---|
| 1 · Puerta | Un dolor que quita el sueño · un deseo grande · un oficio o hobby · algo que hoy se vende en papel · una fecha del año · un problema de la casa |
| 2 · Nicho (hasta 2, cruzados) | Bienestar emocional · crianza · espiritualidad · manualidades · cocina · estudio · plata y ahorro · mascotas · pareja · jardín y huerta · orden de la casa · belleza natural |
| 3 · Palabras (hasta 3) | para imprimir · paso a paso · en 21 días · sin experiencia · plantillas · para principiantes · descarga inmediata · método · desde casa · cuaderno |
| 4 · A quién | Mamás de chicos chicos · abuelas · maestras · emprendedoras · estudiantes · mujeres de 40 a 60 · parejas · personas que trabajan desde casa |
| 5 · Formato | Diario guiado · plan de días · recetario · planos o patrones · plantillas · kit para imprimir · fichas · guía corta en PDF |
| 6 · Idioma y países | El idioma donde quiere vender, con todas sus regiones (francés = Francia, Bélgica, Suiza, Luxemburgo, Quebec…). Español: los países donde se puede cobrar fácil desde tu tienda |

En el mismo mensaje confirmá:
- **Filtros** (si no indica otros): 20 o más anuncios activos hoy y el anunciante pautando hace 14 días o más. No hace falta que cada anuncio tenga 14 días: los que escalan rotan.
- **Cuántos candidatos.** Si no dice, 5.

Lo que indique el usuario manda. Si ya lo contó en su cerebro, usalo y no se lo vuelvas a preguntar. Antes de proponer un idioma, mirá el Bono 1 «Mapa de países» de la guía.

## 2. Buscá en la Biblioteca

**Con el conector de Meta:** usá `ads_library_search`, solo para leer. Traducí las palabras elegidas como las escribiría una página de venta de ese país y combinalas con el nicho, el formato y estas palabras que delatan un pack digital:

- **Español:** guía en PDF, ebook, descarga inmediata, acceso inmediato, pack +300, bonos de regalo, plan de 21 días, reto de 30 días, recetario, plantillas, imprimible, método paso a paso, te llega al correo.
- **Portugués:** guia em PDF, e-book, acesso imediato, pack com +300, bônus exclusivos, plano de 21 dias, desafio de 30 dias, material para imprimir, receba no seu e-mail.
- **Inglés:** PDF guide, eBook, instant access, 300+ bundle, free bonuses, 21-day plan, 30-day challenge, printable, templates, step-by-step.
- **Otro idioma:** traducí como lo diría alguien de ese país.

**Sin el conector:** pedile que abra facebook.com/ads/library, elija el país, «Todos los anuncios» y busque esas palabras. Que te pegue, de cada anunciante, el nombre de la página, la fecha de «Empezó a circular», el texto del anuncio y el link de destino.

Si una combinación no trae nada, **cambiá una sola palanca** y volvé a buscar. Si cambiás todas a la vez, no sabés cuál abrió la puerta. Agrupá los anuncios por anunciante y aplicá los filtros.

## 3. Mirá la página de cada candidato

Abrila con WebFetch o en el navegador y llegá hasta donde se paga. Si no abre, marcala «a revisar en el navegador» y no adivines. Si la página parece otra cosa que el anuncio, puede estar escondiendo la página real: decilo y no la cuentes como confirmada. Anotá:
- la promesa, el precio, los bonus y la garantía;
- en qué plataforma cobra, si se puede ver.

**Descartá:** lo que puede ser físico, webinars y clases gratis, captación de datos, cursos caros de lanzamiento, ventas por video largo, suscripciones y marcas registradas. Ante la duda, afuera.

## 4. Las 5 reglas (no se negocian)

1. **Dos números juntos:** días pautando **y** anuncios prendidos. Uno solo no prueba nada.
2. **Tres anunciantes o más** vendiendo lo mismo desde hace semanas. Uno solo puede ser suerte.
3. **Vacío no es oportunidad:** la Biblioteca no muestra lo que fracasó.
4. **Modelá al original:** el de más días y más anuncios, no sus copias (que copian también sus errores).
5. **Entrá a la página real** antes de recomendar.

## 5. Las 6 preguntas

1. ¿Resuelve algo que la gente quiere hoy: un dolor, un deseo o un plan?
2. ¿Alguien ya lo vende con anuncios?
3. ¿Entra en un pack digital: número en la promesa, regalos y descarga inmediata?
4. ¿Le puede vender más de una cosa: complementos, segunda parte, versión avanzada?
5. ¿Lo puede hacer mejor: más específico, con más valor, mejor presentado?
6. ¿Funciona en más de un país?

## 6. Entregá

Arriba, la combinación de palancas que usaste. Después una tabla, ordenada del más fácil de mejorar al más difícil: anunciante, **link a su página en la Biblioteca**, **link al anuncio top**, anuncios activos, días pautando, anunciantes distintos con lo mismo, promesa, precio, bonus, y qué le mejorarías en una línea.

Debajo, tu recomendación en dos líneas. Escribí todo con lo que viste: lo que no pudiste comprobar va marcado «sin comprobar». Nunca inventes una cifra.

Guardá la tabla en el cerebro, en `productos-<nicho>-<fecha>.md`, y anotá en `HOT.md` cuál eligió.

Cerrá ofreciendo el paso siguiente: «¿Con cuál seguimos? Te la desarmo (escalón 2) y después armamos tu producto (escalón 3)». Si no salió nada bueno, ofrecé otra combinación cambiando una palanca.

## Lo que nunca hacés

- Copiar la página, los textos o las imágenes de otro. Se toma la idea del mercado y se hace mejor.
- Prender, editar o crear nada en Meta desde este comando.
- Comprarle algo a un competidor.
