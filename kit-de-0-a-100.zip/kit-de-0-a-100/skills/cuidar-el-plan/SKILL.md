---
name: cuidar-el-plan
description: Hace que el plan de Claude rinda más y revisa en qué se está yendo el uso. Usala cuando digan «estoy gastando mucho», «llegué al límite», «se me acaba el plan», «cómo gasto menos», o cuando el chat ya esté muy largo.
---

# Cuidar el plan

El plan tiene un tope de uso que se recarga solo. Todo lo que leés y escribís gasta de ese tope. Tu trabajo es que a la persona le alcance para trabajar todos los días.

## Cuando te lo piden
1. Mirá este chat y decile, en una tabla corta, las 3 cosas que más están gastando. Las más comunes:

| Lo que gasta | Qué proponés |
|---|---|
| El chat es muy largo | Corré `pasar-la-posta` y seguir en uno nuevo |
| Varios temas mezclados | Un chat por tema |
| Muchas capturas o archivos grandes | Pedir solo la parte que hace falta |
| Releer archivos que no cambiaron | No volver a leerlos |
| Respuestas largas | Contestar en tabla corta |
| Tareas pesadas a última hora | Dejarlas para cuando el tope esté recargado |

2. Proponé qué hacer ahora: casi siempre, guardar y pasar la posta.
3. Si llegó al límite: decile que no se rompió nada, que se recarga solo, y que al volver escriba «seguí desde la posta».

## Lo que hacés siempre, sin que te lo pidan
- Leé `HOT.md` y solo los archivos que la tarea necesita. No leas `GUIA.md` entera: buscá la parte que toca.
- No vuelvas a leer un archivo que no cambió desde la última vez.
- De un archivo grande, leé solo el tramo que hace falta.
- Respondé corto y en tablas. No repitas la pregunta ni lo que ya se ve.
- No pegues en el chat lo que ya guardaste en un archivo: decí dónde quedó.
- Juntá en un solo paso las consultas que no dependen una de la otra.
- De un panel o una página, traé solo los datos que se van a usar, no todo.
- Avisá antes de una tarea pesada (armar un producto, una tanda de anuncios, traducir): «esto consume bastante, ¿lo hacemos ahora?».
- Cuando el chat pase de una tarea grande o se ponga lento, ofrecé `pasar-la-posta`.

## Lo que no hacés para ahorrar
- Saltearte una comprobación. Mostrar la prueba no se negocia.
- Decidir con datos viejos por no volver a leer un número que sí pudo cambiar.
