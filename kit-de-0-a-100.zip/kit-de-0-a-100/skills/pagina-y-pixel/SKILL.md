---
name: pagina-y-pixel
description: "Escalón 6. Prepara la página de Facebook de la marca, guía para crear la cuenta publicitaria y conecta el píxel de Meta con la tienda, incluido el token. Usala cuando pidan «creá la página de Facebook», «necesito el píxel», «dónde saco el token», «conectá el píxel»."
---

# Página de Facebook y píxel

## Página de Facebook
1. Prepará: nombre, categoría, descripción corta, texto largo, y dos imágenes DISTINTAS (perfil y portada).
2. Escribí 4 publicaciones para que la página no esté vacía.
3. Guiala para crearla: un paso por mensaje, y esperá su «listo» antes del siguiente. Los clics los da ella.
4. Al final pedile el enlace de la página y anotalo en `HOT.md` del cerebro.

## Cuenta publicitaria
La crea ella, acá en el escalón 6, sin tarjeta todavía (la tarjeta va en el escalón 8). Guiala un paso por mensaje:
1. Entrar a business.facebook.com con su perfil de siempre.
2. Crear la cuenta publicitaria.
3. Moneda: dólares.
4. Zona horaria: la de donde vive.

- La moneda y la zona horaria no se cambian después: que las elija con cuidado. De ahí salen los «7 dólares» y las «00:00».
- Los nombres de los botones cambian seguido. No los digas de memoria: si se pierde, pedile una captura y guiala con lo que se ve.
- Avisale que Meta puede tardar en habilitar una cuenta nueva o pedirle que verifique sus datos. Se hace con sus datos reales, sin abrir otra cuenta.
- Con la cuenta creada, que te dé la llave de Meta Ads (paso 0.7 de la guía).

## Píxel
1. Creá el píxel (o guiala para crearlo en el Administrador de eventos de Meta).
2. Cargá el número del píxel en la tienda.
3. El token lo saca y lo pega ella. Explicale así:
   - Administrador de eventos → su píxel → Configuración → API de conversiones → «Generar token de acceso».
   - Copiar el texto largo que empieza con «EA».
   - Pegarlo en la tienda, en el campo del token de ese píxel, y guardar.
4. Si no encuentra un botón, pedile una captura de pantalla y decile dónde está.

## Comprobación
1. Abrí la landing y el checkout y verificá que el píxel registra la visita. Si la tienda tiene un diagnóstico, corrélo y mostrá el resultado.
2. Con el token ya pegado, pedile una compra de prueba y verificá que en el Administrador de eventos aparece como Compra. Si no aparece, no se sigue: se revisa el token.

## Reglas
- Nunca escribas ni pidas que te pase el token por el chat si la plataforma permite pegarlo directo.
- Un píxel por país o marca; cada uno con su propio token.

## Pasa al escalón 7 cuando
El píxel registra la visita en la landing y en el checkout, y una compra de prueba aparece como Compra en el Administrador de eventos.
