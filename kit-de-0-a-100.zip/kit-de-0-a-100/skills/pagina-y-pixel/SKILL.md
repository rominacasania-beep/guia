---
name: pagina-y-pixel
description: Escalón 6. Prepara la página de Facebook de la marca y conecta el píxel de Meta con la tienda, incluido el token. Usala cuando pidan «creá la página de Facebook», «necesito el píxel», «dónde saco el token», «conectá el píxel».
---

# Página de Facebook y píxel

## Página de Facebook
1. Prepará: nombre, categoría, descripción corta, texto largo, y dos imágenes DISTINTAS (perfil y portada).
2. Escribí 4 publicaciones para que la página no esté vacía.
3. Guiala para crearla: un paso por mensaje, y esperá su «listo» antes del siguiente. Los clics los da ella.
4. Al final pedile el enlace de la página y anotalo en `cerebro/HOT.md`.

## Píxel
1. Creá el píxel (o guiala para crearlo en el Administrador de eventos de Meta).
2. Cargá el número del píxel en la tienda.
3. El token lo saca y lo pega ella. Explicale así:
   - Administrador de eventos → su píxel → Configuración → API de conversiones → «Generar token de acceso».
   - Copiar el texto largo que empieza con «EA».
   - Pegarlo en la tienda, en el campo del token de ese píxel, y guardar.
4. Si no encuentra un botón, pedile una captura de pantalla y decile dónde está.

## Comprobación
Abrí la landing y el checkout y verificá que el píxel registra la visita. Si la tienda tiene un diagnóstico, corrélo y mostrá el resultado.

## Reglas
- Nunca escribas ni pidas que te pase el token por el chat si la plataforma permite pegarlo directo.
- Un píxel por país o marca; cada uno con su propio token.

## Pasa al escalón 7 cuando
El píxel registra la visita en la landing y en el checkout.
