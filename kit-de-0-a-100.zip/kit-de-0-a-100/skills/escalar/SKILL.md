---
name: escalar
description: "Escalón 12. Propone subir presupuesto al ganador solo con ventas del día y en la hora en que compra el país, y prepara la recuperación de pagos rechazados. Usala cuando pidan «escalemos», «subí el presupuesto», «a qué hora compran», «recuperar ventas»."
---

# Escalar y recuperar

## Condición para subir (las dos)
1. El país vendió HOY.
2. Vendió también en los 4 días anteriores.

Si falta una, no se sube. Decilo y no insistas.

## Hora pico
1. Tomá las ventas cobradas de los últimos 7 días en la tienda.
2. Agrupalas por hora del país donde se vende.
3. Para cada franja calculá el retorno (cobrado ÷ gastado en esa franja). Mostrá las 3 de mejor retorno, no las de más compras.

## Propuesta
| País | Ventas hoy | Últimos 4 días | Franja fuerte | Propongo |
|---|---|---|---|---|

- Subidas chicas (20 a 30 % por vez), una por día.
- Después de cambiar un presupuesto, volvé a leer el conjunto: a veces queda pausado y hay que reactivarlo.
- Anotá la subida y qué esperás en `decisiones.md` del cerebro.

## Campaña propia (1·1·1)
Solo con un ganador (4 o más ventas cobradas y lo cobrado es más del doble de lo gastado).
1. Creá una campaña nueva con 1 conjunto y 1 anuncio.
2. El anuncio es nuevo, con el mismo creativo y el mismo texto del ganador. El original no se toca ni se apaga.
3. Presupuesto: el mismo por día que tenía en la prueba.
4. La campaña en pausa, con inicio a las 00:00 del día siguiente. La prende ella.
5. Después se sube de a 20 o 30 % por vez, con las condiciones de arriba.

La CBO (un solo presupuesto que reparte Meta) se usa recién cuando un país tiene 3 ganadores. Hasta ahí, todo en ABO.

## Recuperar ventas
1. Listá los pagos rechazados y los carritos abandonados de la semana.
2. Redactá un mail corto y amable con el enlace para terminar la compra.
3. Dejalo en borrador. Lo envía ella.

## Reglas
- En un día no se gasta más del doble del gasto diario promedio de los últimos 4 días.
- Si después de subir la venta sale cara, se vuelve al último presupuesto que funcionó.
- Antes de escalar un país, mirá cuántos pagos fallan ahí. Si son muchos, primero se arregla el cobro.
- Nunca cambies un presupuesto sin su OK.
- Nunca envíes un mail a clientes sin su OK.
- Si no hay venta hoy, la respuesta es «hoy no se escala».

## Después
Con 7 días seguidos sobre la meta, pasa a `plan-de-escala` y `abrir-pais`.
