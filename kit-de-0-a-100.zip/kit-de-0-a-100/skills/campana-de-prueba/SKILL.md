---
name: campana-de-prueba
description: Escalón 8. Arma en Meta la campaña de prueba en pausa (5 conjuntos chicos, un anuncio por conjunto, salida a las 00:00) para que la persona la revise y la prenda. Usala cuando pidan «subí los anuncios», «armá la campaña», «creá la campaña de prueba».
---

# Campaña de prueba

## Antes: tienen que estar los escalones 4 a 7
| Escalón | Qué compruebo |
|---|---|
| 4 | Hizo una compra de prueba y le llegó el producto |
| 5 | Leyó la landing en el celular y el botón lleva al checkout |
| 6 | El píxel registra la visita |
| 7 | Hay 5 anuncios revisados |

Además, la tarjeta cargada por ella en la cuenta publicitaria. Si falta algo, frená y decí qué falta.

## Configuración
| Parte | Valor |
|---|---|
| Objetivo | Ventas, evento de compra, con su píxel |
| Estructura | 5 conjuntos, 1 anuncio en cada uno |
| Presupuesto | Igual en cada conjunto: 5 a 7 dólares por día. Si la cuenta está en otra moneda, el equivalente |
| Público | País + idioma. Sin edad, sin género, sin intereses |
| Inicio | Mañana a las 00:00, hora de la cuenta publicitaria |
| Nombres | Letra, número y fecha de salida: A1 15-11, A2 15-11… |
| Enlace | A la landing, con etiquetas de seguimiento (UTM) |
| Botón | Ver más |
| Estado | Todo en pausa |

## Pasos, si hay conexión con Meta Ads
1. Subí las imágenes.
2. Creá campaña, conjuntos y anuncios en pausa.
3. Volvé a leer lo creado y mostrá un resumen en tabla. Comprobá que nada quedó activo.
4. Pedile que entre al Administrador de anuncios, revise y prenda ella, hoy mismo.

## Si no hay conexión con Meta Ads
Guiala para armarla a mano en el Administrador de anuncios: un paso por mensaje, con los valores de la tabla, y esperá su «listo» antes del siguiente. Si se pierde, pedile una captura.

## Si la prende después de las 00:00
Ya no sale a medianoche. Cambiá el inicio de los conjuntos a las 00:00 del día siguiente y actualizá la fecha en los nombres antes de que la prenda.

## Reglas
- Una sola campaña de prueba por producto. Cada tanda nueva entra como conjuntos nuevos en esa misma campaña.
- Los nombres de campañas, conjuntos y anuncios no llevan palabras de salud, plata, religión ni política.
- Las etiquetas de seguimiento van en el campo «Parámetros de URL». El enlace queda limpio.
- Un anuncio publicado no se edita: cambiar texto, enlace o botón es crear uno nuevo. Por eso se revisa todo antes.
- Nunca actives vos la campaña.
- Si un conjunto no tiene hora de inicio, corregilo antes: sin hora, sale en el momento.
- Anotá la campaña en `decisiones.md`.

## Pasa al escalón 9 cuando
La campaña está prendida por ella y los anuncios pasaron la revisión de Meta.
