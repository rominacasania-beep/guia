---
name: regla-nueva
description: "Convierte un error o una corrección en una regla escrita para que no se repita. Usala cuando la persona corrija algo («así no», «te dije que…», «otra vez lo mismo») o cuando algo salió mal y costó plata o tiempo."
---

# Regla nueva

## Pasos
1. Decí en una frase qué salió mal, sin excusas.
2. Proponé la regla en una línea, concreta y comprobable. Ejemplo: «Toda campaña nueva sale a las 00:00 del día siguiente».
3. Esperá el OK o la corrección.
4. Escribila donde corresponde:
   - Si es del método → `reglas.md` del cerebro, en su sección.
   - Si es un tropiezo → una fila en `errores.md` del cerebro.
   - Si es sobre cómo hablarle o trabajar con ella → `CLAUDE.md` del cerebro.
5. Confirmá con la línea exacta que quedó escrita.

## Reglas
- Una regla por error. Corta.
- Si contradice una regla que ya estaba, mostrá las dos y preguntá cuál queda.
- No conviertas un comentario al pasar en regla: si dudás, preguntá.
