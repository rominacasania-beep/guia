---
name: renovar
description: "Escalón 10. Cada 48 horas saca una tanda nueva: versiones del anuncio que mejor va cambiando una sola cosa, más un ángulo nuevo. Usala cuando pidan «renová los anuncios», «versiones nuevas del ganador», «tanda nueva»."
---

# Renovar

## Qué es una renovación
El mismo anuncio que funciona, con UN solo cambio. No es un anuncio nuevo.

| Si es imagen | Si es video |
|---|---|
| Otro gancho en la primera línea | Otros 3 segundos iniciales |
| Otro titular | Otro orden de tomas |
| Otra primera imagen | Otra música o subtítulos |

## Cada tanda (cada 48 horas al empezar; todos los días cuando ya hay ganador)
1. Elegí el anuncio que mejor va según la tienda.
2. Hacé 2 renovaciones, cada una con un cambio distinto.
3. Sumá 1 anuncio con un ángulo nuevo que todavía no se probó.
4. Variá el estilo visual: una parecida al original, una de otra familia, una arriesgada.
5. Entregá texto, titular y pedido de imagen de cada una.
6. Cuando estén las imágenes, subilas en conjuntos nuevos, en pausa, con salida a las 00:00 y la fecha en el nombre.

## Reglas
- No toques el anuncio original que está vendiendo.
- Anotá qué cambió en cada renovación, para saber qué funcionó.
- Una carpeta por tanda, con la fecha.

## Pasa al escalón 11 cuando
Ya salieron la segunda y la tercera tanda y `leer-y-cortar` marcó al menos un ganador. Si después de tres tandas no hay ninguno, volvé al escalón 1 con otro producto.
