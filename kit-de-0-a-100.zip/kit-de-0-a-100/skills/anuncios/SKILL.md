---
name: anuncios
description: Escalón 7. Escribe una tanda de 5 anuncios para Meta, cada uno con un ángulo distinto, con texto, titular y pedido de imagen usando el producto real. Usala cuando pidan «haceme anuncios», «una tanda», «creativos», «ideas de anuncios».
---

# Tanda de anuncios

## Los 5 ángulos
1. **Precio:** lo accesible que es.
2. **Negocio o utilidad:** para qué le sirve en concreto.
3. **Deseo:** cómo quiere sentirse.
4. **Capacidad:** «vos también podés, es fácil».
5. **Identidad:** «esto es para alguien como vos».

Si ya hay una lista de dolores de la clienta, usá un dolor por anuncio.

## Para cada anuncio entregá
- Texto principal (3 a 6 líneas, la primera es el gancho).
- Titular (hasta 6 palabras).
- Pedido de imagen listo para pegar en el generador: qué se ve, texto exacto en pantalla, formato cuadrado o vertical, y la instrucción «usá la tapa adjunta tal cual, sin redibujarla».

## Reglas
- Cada anuncio nace de algo que ya funciona: uno que lleva tiempo en la Biblioteca o un ganador propio. Anotá de cuál.
- A los 3 segundos tiene que quedar claro qué es, para quién es y qué gana. Si no, reescribí el arranque.
- Un solo idioma por anuncio: revisá voz, subtítulos, textos en pantalla e imágenes del producto.
- No uses fotos ni videos de otras personas bajados de redes. Solo material propio o de bancos con licencia.
- La imagen muestra el producto real. Pedile que adjunte la tapa y páginas reales como referencia.
- Sin promesas de resultado, sin «antes y después», sin hablarle a la persona de sus problemas de salud o plata de forma directa.
- Sin chats, reseñas ni comentarios inventados.
- Botón del anuncio: «Ver más».

## Revisión antes de dar por buenos
Cuando ella genere las imágenes, miralas una por una a tamaño real: letras deformadas, palabras mal escritas, tapa cambiada. La que falle, se rehace.

## Pasa al escalón 8 cuando
Hay 5 anuncios revisados, con la tapa real, guardados en una carpeta con la fecha.
