# Bitácora

Lo que va pasando, lo más nuevo arriba. Lo escribe Claude con la skill `guardar`.
