# Los números, en simple

## Qué significa 100 por día
Ganancia = lo cobrado − lo gastado en anuncios − las comisiones.

Ejemplo para hacer la cuenta (cambiá los valores por los tuyos):

| Dato | Ejemplo |
|---|---|
| Precio del producto | 20 |
| Ventas por día | 7 |
| Cobrado por día | 140 |
| Gastado en anuncios | 35 |

## Punto de empate
Es lo máximo que puedo pagar por una venta sin perder plata: lo que me queda de cada venta después de las comisiones. Si una venta me cuesta más que eso en anuncios, pierdo.

## Regla de corte
Si un anuncio gastó la mitad del precio del producto y no vendió, se apaga.

## Retorno
Retorno = cobrado ÷ gastado. Retorno 2 quiere decir que por cada 1 que puse volvieron 2.

## Lo que cuenta
Siempre lo cobrado en la tienda. El panel de anuncios a veces cuenta ventas que no se cobraron.

## Para empezar necesito
- El plan pago de Claude.
- Reserva para unos 4 días de anuncios de prueba (5 conjuntos chicos por día).
- Plata que pueda perder mientras aprendo.
