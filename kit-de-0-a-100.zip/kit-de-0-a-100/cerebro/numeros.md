# Los números, en simple

## Qué significa 100 por día
Ganancia = lo cobrado − lo gastado en anuncios − las comisiones.

Ejemplo para hacer la cuenta (cambiá los valores por los tuyos):

| Dato | Ejemplo |
|---|---|
| Precio del producto | 27 |
| Ventas por día | 8 |
| Cobrado por día | 216 |
| Comisiones de la tienda y del cobro (acá, cerca del 10 %) | 22 |
| Gastado en anuncios | 90 |
| Ganancia del día | 104 |

La comisión real depende de tu tienda y de tu medio de cobro: mirala en tu panel y cambiá ese número.

## Punto de empate
Es lo máximo que puedo pagar por una venta sin perder plata: lo que me queda de cada venta después de las comisiones. Si una venta me cuesta más que eso en anuncios, pierdo.

## Regla de corte
Si un anuncio gastó la mitad del precio del producto y no vendió, se apaga.

## Retorno
Retorno = cobrado ÷ gastado. Retorno 2 quiere decir que por cada 1 que puse volvieron 2.

## Lo que cuenta
Siempre lo cobrado en la tienda. El panel de anuncios a veces cuenta ventas que no se cobraron.

## Para empezar necesito
- El plan pago de Claude.
- Reserva para unos 4 días de anuncios de prueba (5 conjuntos chicos por día).
- Plata que pueda perder mientras aprendo.
