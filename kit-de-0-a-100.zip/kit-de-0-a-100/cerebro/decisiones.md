# Libro de decisiones

Cada vez que se apaga, se sube o se lanza algo, Claude anota una fila. Al otro día se completa «qué pasó».

| Fecha | Qué se decidió | Por qué | Qué esperaba | Qué pasó |
|---|---|---|---|---|
