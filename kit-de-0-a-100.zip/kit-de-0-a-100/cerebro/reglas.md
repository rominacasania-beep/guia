# Las reglas del método

## Elegir producto
- Se elige lo que ya se vende, no lo que me gusta.
- Una oferta vale la pena cuando la anuncian al menos 3 personas distintas y hay anuncios con varias semanas corriendo.
- Se modela la estructura. Textos, imágenes, marcas y testimonios ajenos no se copian nunca.

## Antes de vender
- El producto está listo cuando lo leí entero.
- La tienda está lista cuando hice una compra de prueba y me llegó el producto.
- La landing se revisa en el celular.
- Sin testimonios inventados ni promesas de resultado.

## Anuncios
- 5 anuncios por tanda, cada uno con un ángulo distinto.
- La imagen muestra mi producto real, nunca uno inventado.
- Un anuncio por conjunto. Presupuesto chico e igual para todos.
- Público abierto: país e idioma. Sin filtrar edad ni género.
- Toda campaña nueva arranca a las 00:00 del día siguiente (hora de la cuenta publicitaria), nunca a mitad del día.
- El nombre de cada conjunto lleva la fecha de salida.
- Todo enlace de anuncio lleva sus etiquetas de seguimiento (UTM).

## Leer y cortar
- Se mira lo cobrado en la tienda.
- Un anuncio que gastó la mitad del precio del producto sin vender, se apaga.
- Nada se decide con una sola venta.
- Los primeros 3 días no se toca nada más que esa regla.

## Ganador
Un anuncio es ganador cuando tiene 4 o más ventas cobradas y lo cobrado es más del doble de lo gastado.

## Renovar
- Cada 48 horas sale una tanda nueva.
- Una renovación es el anuncio ganador con UN solo cambio: gancho, titular o primera imagen.

## Escalar
- Solo se escala un país que vendió HOY y que viene vendiendo los 4 días anteriores.
- Se sube en la hora en que ese país compra.
- Un día sin ventas no se escala, aunque ayer haya ido bien.

## Abrir países
- Primero la Biblioteca de Anuncios: el producto tiene que estar vendiéndose en otros idiomas. Si no, no se lanza.
- Antes de traducir se investiga cómo habla la gente de allá.
- La traducción se revisa dos veces para que no suene a traducción.
- Un país que a los 4 días gastó y no vendió se apaga y se abre el siguiente.

## Siempre
- Nada se prende, publica ni paga sin mi OK.
- Contraseñas, tarjetas y claves las escribo yo.
