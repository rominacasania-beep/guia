# Mi tablero

**Meta:** 100 dólares de ganancia por día · **Hoy:** sin medir todavía

## Sobre mí
- Nombre:
- País donde vivo:
- País donde vendo:
- Tiempo por día:
- Presupuesto de anuncios por día (en dólares):
- ¿Ya tengo producto?:
- Arranqué el:

## Escalón actual: 0 · Instalación

## Mi producto
- Nombre:
- Precio:
- Enlace de la tienda:
- Mi tienda (nombre en la plataforma):
- Mi cuenta de anuncios:

## Esta semana
- [ ] (lo completa Claude en el primer «buen día»)

## Números (solo de la tienda, nunca del panel de anuncios)
| Día | Gastado en anuncios | Cobrado | Ganancia | Ventas |
|---|---|---|---|---|

## Hilos abiertos
- (nada todavía)

Regla: máximo 40 líneas. Lo viejo pasa a `log.md`.
