# Errores que ya se pagaron

Los tropiezos más comunes del camino. Claude los revisa antes de cada escalón.

| Escalón | Error | Qué hacer |
|---|---|---|
| 1 | Elegir lo que me gusta | Elegir lo que ya anuncian varias personas |
| 2 | Copiar textos o imágenes | Tomar solo el orden de la página |
| 3 | Dar por bueno un PDF sin leerlo | Leerlo entero antes de seguir |
| 4 | Vender sin compra de prueba | Comprar yo primero |
| 5 | Revisar solo en la computadora | Abrir la landing en el celular |
| 6 | Saltear el token del píxel | Pegarlo y comprobar que registra |
| 7 | Imagen con un producto que no es el mío | Usar siempre la tapa real |
| 7 | Reusar el audio o los textos de otro anuncio | Revisar cada pieza entera y comprobar el idioma |
| 7 | Mostrar en el anuncio algo que el producto no trae | Abrir el PDF y comprobarlo |
| 8 | Prender a mitad del día | Salida a las 00:00 |
| 8 | Editar un anuncio que ya está publicado | Crear uno nuevo |
| 9 | Apagar todo por nervios | Aplicar solo la regla de corte |
| 10 | Cambiar todo a la vez | Un solo cambio por renovación |
| 11 | Ofertas extra sin ganador | Primero el ganador |
| 12 | Escalar un día sin ventas | Solo con venta de hoy |
| País nuevo | Traducir sin investigar | Biblioteca primero, después cómo hablan |
| País nuevo | La letra no tiene ese alfabeto | Revisar la tipografía antes de armar los PDF |
| País nuevo | Imagen con palabras mal escritas | Mirar cada imagen a tamaño real |

Los errores nuevos los suma la skill `regla-nueva`.
